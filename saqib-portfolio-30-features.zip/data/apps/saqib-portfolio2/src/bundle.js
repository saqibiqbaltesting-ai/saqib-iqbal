var ye,w,Rt,eo,Q,Pt,Bt,Dt,Ot,Ge,We,Ve,to,be={},ve=[],ao=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,re=Array.isArray;function G(e,a){for(var o in a)e[o]=a[o];return e}function Ye(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ie(e,a,o){var n,r,i,c={};for(i in a)i=="key"?n=a[i]:i=="ref"?r=a[i]:c[i]=a[i];if(arguments.length>2&&(c.children=arguments.length>3?ye.call(arguments,2):o),typeof e=="function"&&e.defaultProps!=null)for(i in e.defaultProps)c[i]===void 0&&(c[i]=e.defaultProps[i]);return ge(e,c,n,r,null)}function ge(e,a,o,n,r){var i={type:e,props:a,key:o,ref:n,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:r??++Rt,__i:-1,__u:0};return r==null&&w.vnode!=null&&w.vnode(i),i}function R(e){return e.children}function H(e,a){this.props=e,this.context=a}function K(e,a){if(a==null)return e.__?K(e.__,e.__i+1):null;for(var o;a<e.__k.length;a++)if((o=e.__k[a])!=null&&o.__e!=null)return o.__e;return typeof e.type=="function"?K(e):null}function oo(e){if(e.__P&&e.__d){var a=e.__v,o=a.__e,n=[],r=[],i=G({},a);i.__v=a.__v+1,w.vnode&&w.vnode(i),Qe(e.__P,i,a,e.__n,e.__P.namespaceURI,32&a.__u?[o]:null,n,o??K(a),!!(32&a.__u),r),i.__v=a.__v,i.__.__k[i.__i]=i,Wt(n,i,r),a.__e=a.__=null,i.__e!=o&&Ft(i)}}function Ft(e){if((e=e.__)!=null&&e.__c!=null)return e.__e=e.__c.base=null,e.__k.some(function(a){if(a!=null&&a.__e!=null)return e.__e=e.__c.base=a.__e}),Ft(e)}function Nt(e){(!e.__d&&(e.__d=!0)&&Q.push(e)&&!_e.__r++||Pt!=w.debounceRendering)&&((Pt=w.debounceRendering)||Bt)(_e)}function _e(){for(var e,a=1;Q.length;)Q.length>a&&Q.sort(Dt),e=Q.shift(),a=Q.length,oo(e);_e.__r=0}function Ht(e,a,o,n,r,i,c,d,g,p,h){var l,y,_,T,S,M,b,f=n&&n.__k||ve,z=a.length;for(g=no(o,a,f,g,z),l=0;l<z;l++)(_=o.__k[l])!=null&&(y=_.__i!=-1&&f[_.__i]||be,_.__i=l,M=Qe(e,_,y,r,i,c,d,g,p,h),T=_.__e,_.ref&&y.ref!=_.ref&&(y.ref&&Je(y.ref,null,_),h.push(_.ref,_.__c||T,_)),S==null&&T!=null&&(S=T),(b=!!(4&_.__u))||y.__k===_.__k?g=Ut(_,g,e,b):typeof _.type=="function"&&M!==void 0?g=M:T&&(g=T.nextSibling),_.__u&=-7);return o.__e=S,g}function no(e,a,o,n,r){var i,c,d,g,p,h=o.length,l=h,y=0;for(e.__k=new Array(r),i=0;i<r;i++)(c=a[i])!=null&&typeof c!="boolean"&&typeof c!="function"?(typeof c=="string"||typeof c=="number"||typeof c=="bigint"||c.constructor==String?c=e.__k[i]=ge(null,c,null,null,null):re(c)?c=e.__k[i]=ge(R,{children:c},null,null,null):c.constructor===void 0&&c.__b>0?c=e.__k[i]=ge(c.type,c.props,c.key,c.ref?c.ref:null,c.__v):e.__k[i]=c,g=i+y,c.__=e,c.__b=e.__b+1,d=null,(p=c.__i=ro(c,o,g,l))!=-1&&(l--,(d=o[p])&&(d.__u|=2)),d==null||d.__v==null?(p==-1&&(r>h?y--:r<h&&y++),typeof c.type!="function"&&(c.__u|=4)):p!=g&&(p==g-1?y--:p==g+1?y++:(p>g?y--:y++,c.__u|=4))):e.__k[i]=null;if(l)for(i=0;i<h;i++)(d=o[i])!=null&&!(2&d.__u)&&(d.__e==n&&(n=K(d)),$t(d,d));return n}function Ut(e,a,o,n){var r,i;if(typeof e.type=="function"){for(r=e.__k,i=0;r&&i<r.length;i++)r[i]&&(r[i].__=e,a=Ut(r[i],a,o,n));return a}e.__e!=a&&(n&&(a&&e.type&&!a.parentNode&&(a=K(e)),o.insertBefore(e.__e,a||null)),a=e.__e);do a=a&&a.nextSibling;while(a!=null&&a.nodeType==8);return a}function se(e,a){return a=a||[],e==null||typeof e=="boolean"||(re(e)?e.some(function(o){se(o,a)}):a.push(e)),a}function ro(e,a,o,n){var r,i,c,d=e.key,g=e.type,p=a[o],h=p!=null&&(2&p.__u)==0;if(p===null&&d==null||h&&d==p.key&&g==p.type)return o;if(n>(h?1:0)){for(r=o-1,i=o+1;r>=0||i<a.length;)if((p=a[c=r>=0?r--:i++])!=null&&!(2&p.__u)&&d==p.key&&g==p.type)return c}return-1}function At(e,a,o){a[0]=="-"?e.setProperty(a,o??""):e[a]=o==null?"":typeof o!="number"||ao.test(a)?o:o+"px"}function fe(e,a,o,n,r){var i,c;e:if(a=="style")if(typeof o=="string")e.style.cssText=o;else{if(typeof n=="string"&&(e.style.cssText=n=""),n)for(a in n)o&&a in o||At(e.style,a,"");if(o)for(a in o)n&&o[a]==n[a]||At(e.style,a,o[a])}else if(a[0]=="o"&&a[1]=="n")i=a!=(a=a.replace(Ot,"$1")),c=a.toLowerCase(),a=c in e||a=="onFocusOut"||a=="onFocusIn"?c.slice(2):a.slice(2),e.l||(e.l={}),e.l[a+i]=o,o?n?o.u=n.u:(o.u=Ge,e.addEventListener(a,i?Ve:We,i)):e.removeEventListener(a,i?Ve:We,i);else{if(r=="http://www.w3.org/2000/svg")a=a.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(a!="width"&&a!="height"&&a!="href"&&a!="list"&&a!="form"&&a!="tabIndex"&&a!="download"&&a!="rowSpan"&&a!="colSpan"&&a!="role"&&a!="popover"&&a in e)try{e[a]=o??"";break e}catch{}typeof o=="function"||(o==null||o===!1&&a[4]!="-"?e.removeAttribute(a):e.setAttribute(a,a=="popover"&&o==1?"":o))}}function qt(e){return function(a){if(this.l){var o=this.l[a.type+e];if(a.t==null)a.t=Ge++;else if(a.t<o.u)return;return o(w.event?w.event(a):a)}}}function Qe(e,a,o,n,r,i,c,d,g,p){var h,l,y,_,T,S,M,b,f,z,L,N,A,B,$,q=a.type;if(a.constructor!==void 0)return null;128&o.__u&&(g=!!(32&o.__u),i=[d=a.__e=o.__e]),(h=w.__b)&&h(a);e:if(typeof q=="function")try{if(b=a.props,f="prototype"in q&&q.prototype.render,z=(h=q.contextType)&&n[h.__c],L=h?z?z.props.value:h.__:n,o.__c?M=(l=a.__c=o.__c).__=l.__E:(f?a.__c=l=new q(b,L):(a.__c=l=new H(b,L),l.constructor=q,l.render=so),z&&z.sub(l),l.state||(l.state={}),l.__n=n,y=l.__d=!0,l.__h=[],l._sb=[]),f&&l.__s==null&&(l.__s=l.state),f&&q.getDerivedStateFromProps!=null&&(l.__s==l.state&&(l.__s=G({},l.__s)),G(l.__s,q.getDerivedStateFromProps(b,l.__s))),_=l.props,T=l.state,l.__v=a,y)f&&q.getDerivedStateFromProps==null&&l.componentWillMount!=null&&l.componentWillMount(),f&&l.componentDidMount!=null&&l.__h.push(l.componentDidMount);else{if(f&&q.getDerivedStateFromProps==null&&b!==_&&l.componentWillReceiveProps!=null&&l.componentWillReceiveProps(b,L),a.__v==o.__v||!l.__e&&l.shouldComponentUpdate!=null&&l.shouldComponentUpdate(b,l.__s,L)===!1){a.__v!=o.__v&&(l.props=b,l.state=l.__s,l.__d=!1),a.__e=o.__e,a.__k=o.__k,a.__k.some(function(V){V&&(V.__=a)}),ve.push.apply(l.__h,l._sb),l._sb=[],l.__h.length&&c.push(l);break e}l.componentWillUpdate!=null&&l.componentWillUpdate(b,l.__s,L),f&&l.componentDidUpdate!=null&&l.__h.push(function(){l.componentDidUpdate(_,T,S)})}if(l.context=L,l.props=b,l.__P=e,l.__e=!1,N=w.__r,A=0,f)l.state=l.__s,l.__d=!1,N&&N(a),h=l.render(l.props,l.state,l.context),ve.push.apply(l.__h,l._sb),l._sb=[];else do l.__d=!1,N&&N(a),h=l.render(l.props,l.state,l.context),l.state=l.__s;while(l.__d&&++A<25);l.state=l.__s,l.getChildContext!=null&&(n=G(G({},n),l.getChildContext())),f&&!y&&l.getSnapshotBeforeUpdate!=null&&(S=l.getSnapshotBeforeUpdate(_,T)),B=h!=null&&h.type===R&&h.key==null?Vt(h.props.children):h,d=Ht(e,re(B)?B:[B],a,o,n,r,i,c,d,g,p),l.base=a.__e,a.__u&=-161,l.__h.length&&c.push(l),M&&(l.__E=l.__=null)}catch(V){if(a.__v=null,g||i!=null)if(V.then){for(a.__u|=g?160:128;d&&d.nodeType==8&&d.nextSibling;)d=d.nextSibling;i[i.indexOf(d)]=null,a.__e=d}else{for($=i.length;$--;)Ye(i[$]);$e(a)}else a.__e=o.__e,a.__k=o.__k,V.then||$e(a);w.__e(V,a,o)}else i==null&&a.__v==o.__v?(a.__k=o.__k,a.__e=o.__e):d=a.__e=io(o.__e,a,o,n,r,i,c,g,p);return(h=w.diffed)&&h(a),128&a.__u?void 0:d}function $e(e){e&&(e.__c&&(e.__c.__e=!0),e.__k&&e.__k.some($e))}function Wt(e,a,o){for(var n=0;n<o.length;n++)Je(o[n],o[++n],o[++n]);w.__c&&w.__c(a,e),e.some(function(r){try{e=r.__h,r.__h=[],e.some(function(i){i.call(r)})}catch(i){w.__e(i,r.__v)}})}function Vt(e){return typeof e!="object"||e==null||e.__b>0?e:re(e)?e.map(Vt):G({},e)}function io(e,a,o,n,r,i,c,d,g){var p,h,l,y,_,T,S,M=o.props||be,b=a.props,f=a.type;if(f=="svg"?r="http://www.w3.org/2000/svg":f=="math"?r="http://www.w3.org/1998/Math/MathML":r||(r="http://www.w3.org/1999/xhtml"),i!=null){for(p=0;p<i.length;p++)if((_=i[p])&&"setAttribute"in _==!!f&&(f?_.localName==f:_.nodeType==3)){e=_,i[p]=null;break}}if(e==null){if(f==null)return document.createTextNode(b);e=document.createElementNS(r,f,b.is&&b),d&&(w.__m&&w.__m(a,i),d=!1),i=null}if(f==null)M===b||d&&e.data==b||(e.data=b);else{if(i=i&&ye.call(e.childNodes),!d&&i!=null)for(M={},p=0;p<e.attributes.length;p++)M[(_=e.attributes[p]).name]=_.value;for(p in M)_=M[p],p=="dangerouslySetInnerHTML"?l=_:p=="children"||p in b||p=="value"&&"defaultValue"in b||p=="checked"&&"defaultChecked"in b||fe(e,p,null,_,r);for(p in b)_=b[p],p=="children"?y=_:p=="dangerouslySetInnerHTML"?h=_:p=="value"?T=_:p=="checked"?S=_:d&&typeof _!="function"||M[p]===_||fe(e,p,_,M[p],r);if(h)d||l&&(h.__html==l.__html||h.__html==e.innerHTML)||(e.innerHTML=h.__html),a.__k=[];else if(l&&(e.innerHTML=""),Ht(a.type=="template"?e.content:e,re(y)?y:[y],a,o,n,f=="foreignObject"?"http://www.w3.org/1999/xhtml":r,i,c,i?i[0]:o.__k&&K(o,0),d,g),i!=null)for(p=i.length;p--;)Ye(i[p]);d||(p="value",f=="progress"&&T==null?e.removeAttribute("value"):T!=null&&(T!==e[p]||f=="progress"&&!T||f=="option"&&T!=M[p])&&fe(e,p,T,M[p],r),p="checked",S!=null&&S!=e[p]&&fe(e,p,S,M[p],r))}return e}function Je(e,a,o){try{if(typeof e=="function"){var n=typeof e.__u=="function";n&&e.__u(),n&&a==null||(e.__u=e(a))}else e.current=a}catch(r){w.__e(r,o)}}function $t(e,a,o){var n,r;if(w.unmount&&w.unmount(e),(n=e.ref)&&(n.current&&n.current!=e.__e||Je(n,null,a)),(n=e.__c)!=null){if(n.componentWillUnmount)try{n.componentWillUnmount()}catch(i){w.__e(i,a)}n.base=n.__P=null}if(n=e.__k)for(r=0;r<n.length;r++)n[r]&&$t(n[r],a,o||typeof e.type!="function");o||Ye(e.__e),e.__c=e.__=e.__e=void 0}function so(e,a,o){return this.constructor(e,o)}function Ke(e,a,o){var n,r,i,c;a==document&&(a=document.documentElement),w.__&&w.__(e,a),r=(n=typeof o=="function")?null:o&&o.__k||a.__k,i=[],c=[],Qe(a,e=(!n&&o||a).__k=ie(R,null,[e]),r||be,be,a.namespaceURI,!n&&o?[o]:r?null:a.firstChild?ye.call(a.childNodes):null,i,!n&&o?o:r?r.__e:a.firstChild,n,c),Wt(i,e,c)}ye=ve.slice,w={__e:function(e,a,o,n){for(var r,i,c;a=a.__;)if((r=a.__c)&&!r.__)try{if((i=r.constructor)&&i.getDerivedStateFromError!=null&&(r.setState(i.getDerivedStateFromError(e)),c=r.__d),r.componentDidCatch!=null&&(r.componentDidCatch(e,n||{}),c=r.__d),c)return r.__E=r}catch(d){e=d}throw e}},Rt=0,eo=function(e){return e!=null&&e.constructor===void 0},H.prototype.setState=function(e,a){var o;o=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=G({},this.state),typeof e=="function"&&(e=e(G({},o),this.props)),e&&G(o,e),e!=null&&this.__v&&(a&&this._sb.push(a),Nt(this))},H.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Nt(this))},H.prototype.render=R,Q=[],Bt=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Dt=function(e,a){return e.__v.__b-a.__v.__b},_e.__r=0,Ot=/(PointerCapture)$|Capture$/i,Ge=0,We=qt(!1),Ve=qt(!0),to=0;var le,I,Xe,Gt,ke=0,ta=[],E=w,Yt=E.__b,Qt=E.__r,Jt=E.diffed,Kt=E.__c,Xt=E.unmount,Zt=E.__;function et(e,a){E.__h&&E.__h(I,e,ke||a),ke=0;var o=I.__H||(I.__H={__:[],__h:[]});return e>=o.__.length&&o.__.push({}),o.__[e]}function x(e){return ke=1,aa(na,e)}function aa(e,a,o){var n=et(le++,2);if(n.t=e,!n.__c&&(n.__=[o?o(a):na(void 0,a),function(d){var g=n.__N?n.__N[0]:n.__[0],p=n.t(g,d);g!==p&&(n.__N=[p,n.__[1]],n.__c.setState({}))}],n.__c=I,!I.__f)){var r=function(d,g,p){if(!n.__c.__H)return!0;var h=n.__c.__H.__.filter(function(y){return y.__c});if(h.every(function(y){return!y.__N}))return!i||i.call(this,d,g,p);var l=n.__c.props!==d;return h.some(function(y){if(y.__N){var _=y.__[0];y.__=y.__N,y.__N=void 0,_!==y.__[0]&&(l=!0)}}),i&&i.call(this,d,g,p)||l};I.__f=!0;var i=I.shouldComponentUpdate,c=I.componentWillUpdate;I.componentWillUpdate=function(d,g,p){if(this.__e){var h=i;i=void 0,r(d,g,p),i=h}c&&c.call(this,d,g,p)},I.shouldComponentUpdate=r}return n.__N||n.__}function P(e,a){var o=et(le++,3);!E.__s&&oa(o.__H,a)&&(o.__=e,o.u=a,I.__H.__h.push(o))}function O(e){return ke=5,we(function(){return{current:e}},[])}function we(e,a){var o=et(le++,7);return oa(o.__H,a)&&(o.__=e(),o.__H=a,o.__h=e),o.__}function lo(){for(var e;e=ta.shift();){var a=e.__H;if(e.__P&&a)try{a.__h.some(xe),a.__h.some(Ze),a.__h=[]}catch(o){a.__h=[],E.__e(o,e.__v)}}}E.__b=function(e){I=null,Yt&&Yt(e)},E.__=function(e,a){e&&a.__k&&a.__k.__m&&(e.__m=a.__k.__m),Zt&&Zt(e,a)},E.__r=function(e){Qt&&Qt(e),le=0;var a=(I=e.__c).__H;a&&(Xe===I?(a.__h=[],I.__h=[],a.__.some(function(o){o.__N&&(o.__=o.__N),o.u=o.__N=void 0})):(a.__h.some(xe),a.__h.some(Ze),a.__h=[],le=0)),Xe=I},E.diffed=function(e){Jt&&Jt(e);var a=e.__c;a&&a.__H&&(a.__H.__h.length&&(ta.push(a)!==1&&Gt===E.requestAnimationFrame||((Gt=E.requestAnimationFrame)||co)(lo)),a.__H.__.some(function(o){o.u&&(o.__H=o.u),o.u=void 0})),Xe=I=null},E.__c=function(e,a){a.some(function(o){try{o.__h.some(xe),o.__h=o.__h.filter(function(n){return!n.__||Ze(n)})}catch(n){a.some(function(r){r.__h&&(r.__h=[])}),a=[],E.__e(n,o.__v)}}),Kt&&Kt(e,a)},E.unmount=function(e){Xt&&Xt(e);var a,o=e.__c;o&&o.__H&&(o.__H.__.some(function(n){try{xe(n)}catch(r){a=r}}),o.__H=void 0,a&&E.__e(a,o.__v))};var ea=typeof requestAnimationFrame=="function";function co(e){var a,o=function(){clearTimeout(n),ea&&cancelAnimationFrame(a),setTimeout(e)},n=setTimeout(o,35);ea&&(a=requestAnimationFrame(o))}function xe(e){var a=I,o=e.__c;typeof o=="function"&&(e.__c=void 0,o()),I=a}function Ze(e){var a=I;e.__c=e.__(),I=a}function oa(e,a){return!e||e.length!==a.length||a.some(function(o,n){return o!==e[n]})}function na(e,a){return typeof a=="function"?a(e):a}function ho(e,a){for(var o in a)e[o]=a[o];return e}function ra(e,a){for(var o in e)if(o!=="__source"&&!(o in a))return!0;for(var n in a)if(n!=="__source"&&e[n]!==a[n])return!0;return!1}function ia(e,a){this.props=e,this.context=a}(ia.prototype=new H).isPureReactComponent=!0,ia.prototype.shouldComponentUpdate=function(e,a){return ra(this.props,e)||ra(this.state,a)};var sa=w.__b;w.__b=function(e){e.type&&e.type.__f&&e.ref&&(e.props.ref=e.ref,e.ref=null),sa&&sa(e)};var Ho=typeof Symbol<"u"&&Symbol.for&&Symbol.for("react.forward_ref")||3911;var mo=w.__e;w.__e=function(e,a,o,n){if(e.then){for(var r,i=a;i=i.__;)if((r=i.__c)&&r.__c)return a.__e==null&&(a.__e=o.__e,a.__k=o.__k),r.__c(e,a)}mo(e,a,o,n)};var la=w.unmount;function ma(e,a,o){return e&&(e.__c&&e.__c.__H&&(e.__c.__H.__.forEach(function(n){typeof n.__c=="function"&&n.__c()}),e.__c.__H=null),(e=ho({},e)).__c!=null&&(e.__c.__P===o&&(e.__c.__P=a),e.__c.__e=!0,e.__c=null),e.__k=e.__k&&e.__k.map(function(n){return ma(n,a,o)})),e}function fa(e,a,o){return e&&o&&(e.__v=null,e.__k=e.__k&&e.__k.map(function(n){return fa(n,a,o)}),e.__c&&e.__c.__P===a&&(e.__e&&o.appendChild(e.__e),e.__c.__e=!0,e.__c.__P=o)),e}function tt(){this.__u=0,this.o=null,this.__b=null}function ga(e){if(!e.__)return null;var a=e.__.__c;return a&&a.__a&&a.__a(e)}function Se(){this.i=null,this.l=null}w.unmount=function(e){var a=e.__c;a&&(a.__z=!0),a&&a.__R&&a.__R(),a&&32&e.__u&&(e.type=null),la&&la(e)},(tt.prototype=new H).__c=function(e,a){var o=a.__c,n=this;n.o==null&&(n.o=[]),n.o.push(o);var r=ga(n.__v),i=!1,c=function(){i||n.__z||(i=!0,o.__R=null,r?r(g):g())};o.__R=c;var d=o.__P;o.__P=null;var g=function(){if(!--n.__u){if(n.state.__a){var p=n.state.__a;n.__v.__k[0]=fa(p,p.__c.__P,p.__c.__O)}var h;for(n.setState({__a:n.__b=null});h=n.o.pop();)h.__P=d,h.forceUpdate()}};n.__u++||32&a.__u||n.setState({__a:n.__b=n.__v.__k[0]}),e.then(c,c)},tt.prototype.componentWillUnmount=function(){this.o=[]},tt.prototype.render=function(e,a){if(this.__b){if(this.__v.__k){var o=document.createElement("div"),n=this.__v.__k[0].__c;this.__v.__k[0]=ma(this.__b,o,n.__O=n.__P)}this.__b=null}var r=a.__a&&ie(R,null,e.fallback);return r&&(r.__u&=-33),[ie(R,null,a.__a?null:e.children),r]};var ca=function(e,a,o){if(++o[1]===o[0]&&e.l.delete(a),e.props.revealOrder&&(e.props.revealOrder[0]!=="t"||!e.l.size))for(o=e.i;o;){for(;o.length>3;)o.pop()();if(o[1]<o[0])break;e.i=o=o[2]}};(Se.prototype=new H).__a=function(e){var a=this,o=ga(a.__v),n=a.l.get(e);return n[0]++,function(r){var i=function(){a.props.revealOrder?(n.push(r),ca(a,e,n)):r()};o?o(i):i()}},Se.prototype.render=function(e){this.i=null,this.l=new Map;var a=se(e.children);e.revealOrder&&e.revealOrder[0]==="b"&&a.reverse();for(var o=a.length;o--;)this.l.set(a[o],this.i=[1,0,this.i]);return e.children},Se.prototype.componentDidUpdate=Se.prototype.componentDidMount=function(){var e=this;this.l.forEach(function(a,o){ca(e,o,a)})};var fo=typeof Symbol<"u"&&Symbol.for&&Symbol.for("react.element")||60103,go=/^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,bo=/^on(Ani|Tra|Tou|BeforeInp|Compo)/,vo=/[A-Z0-9]/g,_o=typeof document<"u",yo=function(e){return(typeof Symbol<"u"&&typeof Symbol()=="symbol"?/fil|che|rad/:/fil|che|ra/).test(e)};H.prototype.isReactComponent={},["componentWillMount","componentWillReceiveProps","componentWillUpdate"].forEach(function(e){Object.defineProperty(H.prototype,e,{configurable:!0,get:function(){return this["UNSAFE_"+e]},set:function(a){Object.defineProperty(this,e,{configurable:!0,writable:!0,value:a})}})});var da=w.event;function xo(){}function ko(){return this.cancelBubble}function wo(){return this.defaultPrevented}w.event=function(e){return da&&(e=da(e)),e.persist=xo,e.isPropagationStopped=ko,e.isDefaultPrevented=wo,e.nativeEvent=e};var ba,So={enumerable:!1,configurable:!0,get:function(){return this.class}},pa=w.vnode;w.vnode=function(e){typeof e.type=="string"&&function(a){var o=a.props,n=a.type,r={},i=n.indexOf("-")===-1;for(var c in o){var d=o[c];if(!(c==="value"&&"defaultValue"in o&&d==null||_o&&c==="children"&&n==="noscript"||c==="class"||c==="className")){var g=c.toLowerCase();c==="defaultValue"&&"value"in o&&o.value==null?c="value":c==="download"&&d===!0?d="":g==="translate"&&d==="no"?d=!1:g[0]==="o"&&g[1]==="n"?g==="ondoubleclick"?c="ondblclick":g!=="onchange"||n!=="input"&&n!=="textarea"||yo(o.type)?g==="onfocus"?c="onfocusin":g==="onblur"?c="onfocusout":bo.test(c)&&(c=g):g=c="oninput":i&&go.test(c)?c=c.replace(vo,"-$&").toLowerCase():d===null&&(d=void 0),g==="oninput"&&r[c=g]&&(c="oninputCapture"),r[c]=d}}n=="select"&&r.multiple&&Array.isArray(r.value)&&(r.value=se(o.children).forEach(function(p){p.props.selected=r.value.indexOf(p.props.value)!=-1})),n=="select"&&r.defaultValue!=null&&(r.value=se(o.children).forEach(function(p){p.props.selected=r.multiple?r.defaultValue.indexOf(p.props.value)!=-1:r.defaultValue==p.props.value})),o.class&&!o.className?(r.class=o.class,Object.defineProperty(r,"className",So)):o.className&&(r.class=r.className=o.className),a.props=r}(e),e.$$typeof=fo,pa&&pa(e)};var ua=w.__r;w.__r=function(e){ua&&ua(e),ba=e.__c};var ha=w.diffed;w.diffed=function(e){ha&&ha(e);var a=e.props,o=e.__e;o!=null&&e.type==="textarea"&&"value"in a&&a.value!==o.value&&(o.value=a.value==null?"":a.value),ba=null};var Co=0,Go=Array.isArray;function t(e,a,o,n,r,i){a||(a={});var c,d,g=a;if("ref"in g)for(d in g={},a)d=="ref"?c=a[d]:g[d]=a[d];var p={type:e,props:g,key:o,ref:c,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--Co,__i:-1,__u:0,__source:r,__self:i};if(typeof e=="function"&&(c=e.defaultProps))for(d in c)g[d]===void 0&&(g[d]=c[d]);return w.vnode&&w.vnode(p),p}function va(){let e=O(null);return P(()=>{let a=e.current;if(!a)return;let o=a.getContext("2d");if(!o)return;let n=window.matchMedia("(prefers-reduced-motion: reduce)").matches,r=Math.min(window.devicePixelRatio||1,2),i=0,c=0,d=0,g=1.2,p=()=>({x:(Math.random()-.5)*2.4,y:(Math.random()-.5)*2.4,z:Math.random()*1.8+.35,vx:(Math.random()-.5)*4e-4,vy:(Math.random()-.5)*4e-4,vz:(Math.random()-.5)*2e-4}),h=[],l={wx:0,wy:0,active:!1},y=()=>{i=a.clientWidth,c=a.clientHeight,a.width=i*r,a.height=c*r,o.setTransform(r,0,0,r,0,0);let b=Math.min(90,Math.floor(i/8));h=Array.from({length:b},p)},_=()=>({wx:(l.wx-i/2)/(i/2),wy:(l.wy-c/2)/(i/2)}),T=()=>{o.clearRect(0,0,i,c);let b=_();for(let f of h){if(l.active){let $=b.wx-f.x,q=b.wy-f.y,ae=2e-5/($*$+q*q+.05);f.vx+=$*ae,f.vy+=q*ae}f.vx+=-f.x*2e-6,f.vy+=-f.y*2e-6,f.x+=f.vx,f.y+=f.vy,f.z+=f.vz,(f.z<.25||f.z>2.2)&&(f.vz*=-1);let z=g/f.z,L=i/2+f.x*z*(i/2),N=c/2+f.y*z*(i/2);if(L<-20||L>i+20||N<-20||N>c+20){Object.assign(f,p());continue}let A=Math.max(.6,1.6*z),B=Math.min(.75,.15+z*.4);o.beginPath(),o.arc(L,N,A,0,Math.PI*2),o.fillStyle=`rgba(233, 128, 160, ${B})`,o.fill()}d=requestAnimationFrame(T)},S=b=>{let f=a.getBoundingClientRect();l.wx=b.clientX-f.left,l.wy=b.clientY-f.top,l.active=!0},M=()=>{l.active=!1};return y(),n?(l.active=!1,T(),cancelAnimationFrame(d)):d=requestAnimationFrame(T),window.addEventListener("resize",y),window.addEventListener("pointermove",S),window.addEventListener("pointerleave",M),()=>{cancelAnimationFrame(d),window.removeEventListener("resize",y),window.removeEventListener("pointermove",S),window.removeEventListener("pointerleave",M)}},[]),t("canvas",{ref:e,class:"particles","aria-hidden":"true"})}function _a({count:e=16}){let a=we(()=>Array.from({length:e},(o,n)=>({id:n,left:Math.random()*100,delay:-Math.random()*18,duration:11+Math.random()*12,size:10+Math.random()*12,drift:(Math.random()-.5)*120,hue:340+Math.random()*20})),[e]);return t("div",{class:"petals","aria-hidden":"true",children:a.map(o=>t("span",{class:"petal",style:{left:`${o.left}%`,width:`${o.size}px`,height:`${o.size*1.35}px`,animationDuration:`${o.duration}s`,animationDelay:`${o.delay}s`,background:`radial-gradient(ellipse at 30% 30%, hsla(${o.hue}, 70%, 78%, 0.9), hsla(${o.hue}, 65%, 55%, 0.75))`,"--drift":`${o.drift}px`}},o.id))})}function ya({lang:e,rtl:a,onSwitchLang:o,onAuth:n}){let[r,i]=x("login"),[c,d]=x({name:"",email:"",password:""}),[g,p]=x(!1),[h,l]=x(""),[y,_]=x(""),T=O(!1),S=(b,f)=>e==="en"?b:f,M=b=>{if(b.preventDefault(),T.current)return;let f=c.name.trim(),z=c.email.trim(),L=c.password;if(r==="signup"&&!f){l(S("Please write your name.","\u0628\u0631\u0627\u06C1 \u06A9\u0631\u0645 \u0627\u067E\u0646\u0627 \u0646\u0627\u0645 \u0644\u06A9\u06BE\u06CC\u06BA\u06D4"));return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(z)){l(S("Email is not correct \u2014 like name@gmail.com","\u0627\u06CC\u0645\u06CC\u0644 \u062F\u0631\u0633\u062A \u0646\u06C1\u06CC\u06BA \u2014 \u0645\u062B\u0644\u0627\u064B name@gmail.com"));return}if(L.length<6){l(S("Password must be at least 6 characters.","\u067E\u0627\u0633 \u0648\u0631\u0688 \u06A9\u0645 \u0627\u0632 \u06A9\u0645 6 \u062D\u0631\u0648\u0641 \u06A9\u0627 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2\u06D4"));return}T.current=!0;let V=window.vellum&&window.vellum.fetch?window.vellum.fetch("/v1/x/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:r,name:f,email:z,password:L})}):fetch("/v1/x/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:r,name:f,email:z,password:L})});V.then(async A=>{if(!A||!A.ok){let Q=null;try{Q=await A.json()}catch(Q){}if(r==="login")l(Q&&Q.error==="bad credentials"?S("Wrong email or password.","\u0627\u06CC \u0645\u06CC\u0644 \u06CC\u0627 \u067E\u0627\u0633 \u0648\u0631\u0688 \u063A\u0644\u062A \u06C1\u06D2\u06D4"):S("Account not found \u2014 please sign up first.","\u0627\u06A9\u0627\u0624\u0646\u0679 \u0646\u06C1\u06CC\u06BA \u0645\u0644\u0627 \u2014 \u067E\u06C1\u0644\u06D2 \u0633\u0627\u0626\u0646 \u0622\u067E \u06A9\u0631\u06CC\u06BA\u06D4"));else if(Q&&Q.error==="exists")l(S("Email already registered \u2014 log in instead.","\u0627\u06CC \u0645\u06CC\u0644 \u067E\u06C1\u0644\u06D2 \u0633\u06D2 \u0645\u0648\u062C\u0648\u062F \u06C1\u06D2 \u2014 \u0644\u0627\u06AF \u0627\u0650\u0646 \u06A9\u0631\u06CC\u06BA\u06D4"));else l(S("Could not create account \u2014 try again.","\u0627\u06A9\u0627\u0624\u0646\u0679 \u0646\u06C1\u06CC\u06BA \u0628\u0646\u0627 \u2014 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4"));T.current=!1;return}let B=await A.json().catch(()=>({}));if(!B||!B.token){l(S("Could not create account \u2014 try again.","\u0627\u06A9\u0627\u0624\u0646\u0679 \u0646\u06C1\u06CC\u06BA \u0628\u0646\u0627 \u2014 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4"));T.current=!1;return}try{localStorage.setItem("portfolio-auth-token",B.token)}catch{}let N={name:B.user&&B.user.name||f||z.split("@")[0],email:z};try{localStorage.setItem("portfolio-auth-local",JSON.stringify(N))}catch{}n(N)}).catch(()=>{l(S("No connection \u2014 try again.","\u06A9\u0646\u06A9\u0634\u0646 \u0646\u06C1\u06CC\u06BA \u2014 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4"));T.current=!1})};return t("div",{class:"gate",dir:a?"rtl":"ltr",children:[t("div",{class:"gate-glow","aria-hidden":"true"}),t("button",{class:"lang-toggle",onClick:o,"aria-label":"Switch language",children:e==="en"?"\u0627\u0631\u062F\u0648":"English"}),t("div",{class:"gate-wrap",children:[t("div",{class:"gate-card",children:[t("div",{class:"gate-emblem","aria-hidden":"true",children:"S"}),t("span",{class:"gate-kicker",children:S("PRIVATE PORTFOLIO","\u067E\u0631\u0627\u0626\u06CC\u0648\u06CC\u0679 \u067E\u0648\u0631\u0679\u0641\u0648\u0644\u06CC\u0648")}),t("h1",{class:"gate-title",children:["Saqib ",t("em",{children:"Iqbal"})]}),t("p",{class:"gate-sub",children:S("Sign up to enter the website.","\u0648\u06CC\u0628 \u0633\u0627\u0626\u0679 \u0645\u06CC\u06BA \u062F\u0627\u062E\u0644 \u06C1\u0648\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2 \u0633\u0627\u0626\u0646 \u0627\u067E \u06A9\u0631\u06CC\u06BA\u06D4")}),t("form",{class:"gb-form gate-form",onSubmit:M,noValidate:!0,children:[r==="signup"&&t("input",{class:"gb-input gate-input",value:c.name,onChange:b=>d(f=>({...f,name:b.target.value})),placeholder:S("Your name","\u0622\u067E \u06A9\u0627 \u0646\u0627\u0645"),maxLength:40}),t("input",{class:"gb-input gate-input",type:"email",inputmode:"email",value:c.email,onChange:b=>d(f=>({...f,email:b.target.value})),placeholder:S("Email","\u0627\u06CC\u0645\u06CC\u0644")}),t("div",{class:"gate-pw-wrap",children:[t("input",{class:"gb-input gate-input",type:g?"text":"password",value:c.password,onChange:b=>d(f=>({...f,password:b.target.value})),placeholder:S("Password (min 6 characters)","\u067E\u0627\u0633 \u0648\u0631\u0688 (\u06A9\u0645 \u0627\u0632 \u06A9\u0645 6 \u062D\u0631\u0648\u0641)")}),t("button",{type:"button",class:"gate-pw-eye",onClick:()=>p(b=>!b),"aria-label":g?"Hide password":"Show password",children:g?"\u{1F648}":"\u{1F441}"})]}),t("button",{class:"gate-cta",type:"button",onClick:M,children:r==="signup"?S("Sign up","\u0633\u0627\u0626\u0646 \u0627\u067E"):S("Log in","\u0644\u0627\u06AF \u0627\u0646")}),h&&t("p",{class:"gb-note",children:h}),y&&t("p",{class:"gb-note",children:y})]}),t("button",{type:"button",class:"gb-switch gate-switch",onClick:()=>{i(b=>b==="signup"?"login":"signup"),l(""),_("")},children:r==="signup"?S("Already have an account? Log in","\u0627\u06A9\u0627\u0624\u0646\u0679 \u06C1\u06D2\u061F \u0644\u0627\u06AF \u0627\u0646 \u06A9\u0631\u06CC\u06BA"):S("New here? Create an account","\u0646\u0626\u06D2 \u06C1\u06CC\u06BA\u061F \u0627\u06A9\u0627\u0624\u0646\u0679 \u0628\u0646\u0627\u0626\u06CC\u06BA")})]}),t("p",{class:"gate-foot",children:["\xA9 ",new Date().getFullYear()," Saqib Iqbal \xB7 v26"]})]})]})}function xa({lang:e,rtl:a,onSwitchLang:o,storageAllowed:n,onDone:r}){let[i,c]=x({}),d=(h,l)=>e==="en"?h:l,g=[{key:"notif",icon:"\u{1F514}",title:d("Notifications","\u0646\u0648\u0679\u06CC\u0641\u06A9\u06CC\u0634\u0646\u0632"),why:d("For updates about new guestbook messages.","\u0646\u0626\u06D2 \u067E\u06CC\u063A\u0627\u0645\u0627\u062A \u06A9\u06CC \u062E\u0628\u0631 \u06A9\u06D2 \u0644\u06CC\u06D2\u06D4"),ask:async()=>{c(h=>({...h,notif:"ok"}))}},{key:"clip",icon:"\u{1F4CB}",title:d("Clipboard","\u06A9\u0644\u067E \u0628\u0648\u0631\u0688"),why:d("To copy share links with one tap.","\u0634\u06CC\u0626\u0631 \u0644\u0646\u06A9\u0633 \u06A9\u0627\u067E\u06CC \u06A9\u0631\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2\u06D4"),ask:async()=>{c(h=>({...h,clip:"ok"}))}},{key:"cam",icon:"\u{1F4F7}",title:d("Camera","\u06A9\u06CC\u0645\u0631\u0629"),why:d("Only if a future feature needs it.","\u0635\u0631\u0641 \u0645\u0633\u062A\u0642\u0628\u0644 \u06A9\u06CC \u0636\u0631\u0648\u0631\u062A \u06A9\u06D2 \u0644\u06CC\u06D2\u06D4"),ask:async()=>{c(h=>({...h,cam:"ok"}))}},{key:"mic",icon:"\u{1F3A4}",title:d("Microphone","\u0645\u0627\u0626\u06A9\u0631\u0648\u0641\u0648\u0646"),why:d("Only if a future feature needs it.","\u0635\u0631\u0641 \u0645\u0633\u062A\u0642\u0628\u0644 \u06A9\u06CC \u0636\u0631\u0648\u0631\u062A \u06A9\u06D2 \u0644\u06CC\u06D2\u06D4"),ask:async()=>{c(h=>({...h,mic:"ok"}))}}],p=h=>i[h]==="ok"?"\u2705":i[h]==="no"?"\u274C":"\u2014";return t("div",{class:"gate",dir:a?"rtl":"ltr",children:[t("div",{class:"gate-glow","aria-hidden":"true"}),t("button",{class:"lang-toggle",onClick:o,"aria-label":"Switch language",children:e==="en"?"\u0627\u0631\u062F\u0648":"English"}),t("div",{class:"gate-wrap",children:t("div",{class:"gate-card",children:[t("div",{class:"gate-emblem","aria-hidden":"true",children:"\u{1F6E1}\uFE0F"}),t("span",{class:"gate-kicker",children:d("WEBSITE PERMISSIONS","\u0648\u06CC\u0628 \u0633\u0627\u0626\u0679 \u06A9\u06CC \u0627\u062C\u0627\u0632\u062A\u06CC\u06BA")}),t("h1",{class:"gate-title",style:{fontSize:"clamp(22px, 6vw, 28px)"},children:d("Choose what to allow","\u0686\u0646\u06CC\u06BA \u06A9\u06CC\u0627 \u0627\u062C\u0627\u0632\u062A \u062F\u06CC\u0646\u06CC \u06C1\u06D2")}),t("p",{class:"gate-sub",children:n?d("Storage was allowed. Now pick the rest \u2014 your choice for each one.","\u0627\u0633\u0679\u0648\u0631\u06CC\u062C \u06A9\u06CC \u0627\u062C\u0627\u0632\u062A \u0645\u0644 \u06AF\u0626\u06CC\u06D4 \u0627\u0628 \u0628\u0627\u0642\u06CC \u0686\u0646\u06CC\u06BA \u2014 \u06C1\u0631 \u0627\u06CC\u06A9 \u06A9\u0627 \u0641\u06CC\u0635\u0644\u06C1 \u0622\u067E \u06A9\u0627\u06D4"):d("Storage was denied \u2014 the site still works. Now pick the rest.","\u0627\u0633\u0679\u0648\u0631\u06CC\u062C \u06A9\u06CC \u0627\u062C\u0627\u0632\u062A \u0646\u06C1\u06CC\u06BA \u0645\u0644\u06CC \u2014 \u0648\u06CC\u0628 \u0633\u0627\u0626\u0679 \u067E\u06BE\u0631 \u0628\u06BE\u06CC \u0686\u0644\u06D2 \u06AF\u06CC\u06D4 \u0627\u0628 \u0628\u0627\u0642\u06CC \u0686\u0646\u06CC\u06BA\u06D4")}),t("div",{class:"perm-list",children:g.map(h=>t("div",{class:"perm-row",children:[t("span",{class:"perm-icon",children:h.icon}),t("span",{class:"perm-text",children:[t("strong",{children:[h.title," ",t("em",{class:"perm-mark",children:p(h.key)})]}),t("small",{children:h.why})]}),t("span",{class:"perm-actions",children:[t("button",{type:"button",class:"perm-allow",onClick:()=>{h.ask()},children:d("Allow","\u0627\u062C\u0627\u0632\u062A")}),t("button",{type:"button",class:"perm-deny",onClick:()=>c(l=>({...l,[h.key]:"no"})),children:d("Deny","\u0645\u0646\u0639")})]})]},h.key))}),t("button",{class:"gate-cta",style:{marginTop:4},onClick:r,children:d("Continue to website","\u0648\u06CC\u0628 \u0633\u0627\u0626\u0679 \u067E\u0631 \u062C\u0627\u0631\u06CC \u0631\u06A9\u06BE\u06CC\u06BA")}),t("p",{class:"gb-note",children:d("You can change these anytime by resetting the site.","\u06CC\u06C1 \u0622\u067E \u06A9\u0633\u06CC \u0628\u06BE\u06CC \u0648\u0642\u062A \u0633\u0627\u0626\u0679 \u0631\u06CC \u0633\u06CC\u0679 \u06A9\u0631 \u06A9\u06D2 \u0628\u062F\u0644 \u0633\u06A9\u062A\u06D2 \u06C1\u06CC\u06BA\u06D4")})]})})]})}var X={},Ce=!1,ka=()=>{Ce=!0},j={getItem(e){if(Ce)return X[e]??null;try{return localStorage.getItem(e)}catch{return X[e]??null}},setItem(e,a){if(Ce){X[e]=a;return}try{localStorage.setItem(e,a)}catch{X[e]=a}},removeItem(e){if(Ce){delete X[e];return}try{localStorage.removeItem(e)}catch{delete X[e]}}},at="portfolio-storage-consent";function wa(e){(!isFinite(e)||e<0)&&(e=0);let a=Math.floor(e/60),o=Math.floor(e%60);return`${a}:${o.toString().padStart(2,"0")}`}function Sa(){let e=O(null),[a,o]=x(!1),[n,r]=x(50),[i,c]=x(""),[d,g]=x(!1),[p,h]=x(0),[l,y]=x(0);P(()=>{try{window.vellum.asset("assets/naat.mp3").then(c).catch(()=>g(!0))}catch{g(!0)}},[]),P(()=>{e.current&&(e.current.volume=n/100)},[n]);let _=()=>{let b=e.current;!b||!i||(a?(b.pause(),o(!1)):b.play().then(()=>o(!0)).catch(()=>g(!0)))},T=b=>{let f=e.current;f&&(f.currentTime=Math.min(Math.max(0,f.currentTime+b),f.duration||0))},S=b=>{let f=e.current;f&&l&&(f.currentTime=b/100*l)},M=()=>{let b=e.current;b&&isFinite(b.duration)&&y(b.duration)};return t("div",{class:"player-card",role:"region","aria-label":"Music player",children:[t("audio",{ref:e,src:i||void 0,loop:!0,preload:"none",onLoadedMetadata:M,onTimeUpdate:()=>h(e.current?.currentTime??0),onDurationChange:M}),t("button",{class:`player-play ${a?"playing":""}`,onClick:_,"aria-label":a?"Pause":"Play",children:a?t("svg",{viewBox:"0 0 24 24",width:"22",height:"22",fill:"currentColor","aria-hidden":"true",children:[t("rect",{x:"6",y:"5",width:"4",height:"14",rx:"1"}),t("rect",{x:"14",y:"5",width:"4",height:"14",rx:"1"})]}):t("svg",{viewBox:"0 0 24 24",width:"22",height:"22",fill:"currentColor","aria-hidden":"true",children:t("path",{d:"M8 5v14l11-7z"})})}),t("div",{class:"player-info",children:[t("p",{class:"player-title",children:"Music"}),d?t("p",{class:"player-error",children:"Audio load nahi hua."}):t("div",{class:"player-controls-wrap",children:[t("div",{class:"player-seek-row",children:[t("span",{class:"player-time",children:wa(p)}),t("input",{class:"player-seek",type:"range",min:0,max:100,step:.1,value:l?p/l*100:0,onInput:b=>S(Number(b.target.value)),"aria-label":"Seek"}),t("span",{class:"player-time",children:wa(l)})]}),t("div",{class:"player-controls",children:[t("button",{class:"player-skip",onClick:()=>T(-15),"aria-label":"15 seconds back",children:[t("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[t("path",{d:"M11 19l-7-7 7-7"}),t("path",{d:"M19 19l-7-7 7-7"})]}),t("span",{children:"15"})]}),t("button",{class:"player-skip",onClick:()=>T(15),"aria-label":"15 seconds forward",children:[t("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[t("path",{d:"M13 5l7 7-7 7"}),t("path",{d:"M5 5l7 7-7 7"})]}),t("span",{children:"15"})]}),t("svg",{viewBox:"0 0 24 24",width:"15",height:"15",fill:"currentColor","aria-hidden":"true",class:"player-vol-icon",children:t("path",{d:"M3 10v4h3l4 4V6L6 10H3zm13.5 2a4.5 4.5 0 0 0-2.5-4v8a4.5 4.5 0 0 0 2.5-4z"})}),t("input",{class:"player-vol",type:"range",min:0,max:100,value:n,onInput:b=>r(Number(b.target.value)),"aria-label":"Volume"}),t("span",{class:"player-vol-num",children:[n,"%"]})]})]})]})]})}var Ca=[{t:"Khamoshi bhi ek jawab hoti hai, samajh nahi aaya to qasoor hamara nahi.",c:"sad"},{t:"Dil ne tujh ko hi chuna hai, baqi sab bahana hai.",c:"love"},{t:"Teri hansi meri subah ki pehli dua lagti hai.",c:"romantic"},{t:"Main woh nahin jo bhool jaye, main woh hoon jo yaad rahe.",c:"attitude"},{t:"Udaas hoon to kya hua, andaz meri apni hai.",c:"sad"},{t:"Tere naam se shuru hoti hai meri har khushi.",c:"love"},{t:"Tere kandhe ka sahara chahiye, koi taj nahi.",c:"romantic"},{t:"Zamana dekhta raiga, main apna safar likhta rahunga.",c:"attitude"},{t:"Kuch log chup reh kar bhi sab se gehra zakham dete hain.",c:"sad"},{t:"Tu hai to har mushkil aasan lagti hai.",c:"love"},{t:"Tera haath thaam kar lambe safar bhi chhota lagta hai.",c:"romantic"},{t:"Apni peakh na karna, main alag level ka hoon.",c:"attitude"},{t:"Log badal gaye, par adatein purani rah gayin.",c:"sad"},{t:"Mohabbat mein sab kuch dena aata hai, maangna nahi.",c:"love"},{t:"Teri aankhon mein woh nami hai jo mere dil ko bhar deti hai.",c:"romantic"},{t:"Muqaddama mere hausle ka nahi, duniya ke zarb ka hai.",c:"attitude"},{t:"Dard chhupana seekh liya, par batana bhool gaya.",c:"sad"},{t:"Tere baghair bhi tujh se hi baatein karta hoon.",c:"love"},{t:"Pehli mulaqat mein hi lag gaya tha, yeh meri aakhri mulaqat hogi.",c:"romantic"},{t:"Sada jeene wale se zyada sada dil wale takatwar hote hain.",c:"attitude"},{t:"Tanhai bhi achhi lagti hai jab sab ajnabi hon.",c:"sad"},{t:"Tu duaa nahi, meri raza hai.",c:"love"},{t:"Tere naam ka sahara, zindagi bhar ka sauda.",c:"romantic"},{t:"Main raja hoon apni duniya ka, sab jo bole bole.",c:"attitude"},{t:"Khushiyan batwai thin, gham sab ne akele diye.",c:"sad"},{t:"Ishq mein aqwam ne dhokay diye, phir bhi yaqeen kam na hua.",c:"love"},{t:"Tere hone se raat bhi chand jaisi lagti hai.",c:"romantic"},{t:"Muqaddama meri khamoshi ka hai, jawab dena baad mein.",c:"attitude"},{t:"Har raat kuch na kuch seh kar soti hoon, yeh aadat si ho gayi.",c:"sad"},{t:"Tere pyaar ne mera har zakhma bhar diya.",c:"love"},{t:"Tere paas rehna hi meri manzil hai.",c:"romantic"},{t:"Apni duniya ka badshah hoon, sab ko shafaf chahta hoon.",c:"attitude"},{t:"Log mazaq urate hain, aur hum muskurat dete hain.",c:"sad"},{t:"Tera pyaar hi mera sab se bara sila hai.",c:"love"},{t:"Tere saath har mausam bahaar lagta hai.",c:"romantic"},{t:"Chuppi meri taqat hai, toofan meri tehzeeb.",c:"attitude"},{t:"Rona aata hai magar aankhein khali hain.",c:"sad"},{t:"Tere liye duniya se ladne ko taiyar hoon.",c:"love"},{t:"Teri dhadkan sunne ko main har saans mein hoon.",c:"romantic"},{t:"Duniya ke dastoor se door, apne tareeqe se chalunga.",c:"attitude"},{t:"Rishton ne dhoka diya, to tanhai se dosti kar li.",c:"sad"},{t:"Tu meri woh dua hai jo kabhi maangi nahi thi.",c:"love"},{t:"Tere honto ki hansi meri zindagi ka maqsad hai.",c:"romantic"},{t:"Khamosh logon ke samandar andar hota hai.",c:"attitude"},{t:"Chand ko dekha to teri yaad aa gayi.",c:"sad"},{t:"Mere dil mein sirf tu rehta hai, baqi sab mehman hain.",c:"love"},{t:"Teri ek muskurahat meri duniya badal deti hai.",c:"romantic"},{t:"Jin se darte the log, un se main mohabbat karta hoon.",c:"attitude"},{t:"Apne aap se baat karne laga hoon, hal puchne ke liye.",c:"sad"},{t:"Tu hai to main hoon, tu nahi to kuch bhi nahi.",c:"love"},{t:"Tere chehre ka noor meri zindagi ka suroor hai.",c:"romantic"},{t:"Shauk se jeeta hoon, zid se jiya nahi karta.",c:"attitude"},{t:"Log samajhte hain main khush hoon, main sirf theek hoon.",c:"sad"},{t:"Teri wafa ke aage meri har koshish choti hai.",c:"love"},{t:"Tere naam ka suraj, mere dil ki dhoop hai.",c:"romantic"},{t:"Jhuke nahi to jeet ke barabar hai.",c:"attitude"},{t:"Sab ke hote hue bhi akela rehna seekh liya.",c:"sad"},{t:"Mere pyaar mein tere bina koi hissa nahi.",c:"love"},{t:"Teri saanson se meri saansein chalti hain.",c:"romantic"},{t:"Apne hausle se aasmaan gaadhta hoon.",c:"attitude"},{t:"Dukh itna hai ke muskurahat bhi jaali lagti hai.",c:"sad"},{t:"Tera ek ishara meri zindagi ka faisla hai.",c:"love"},{t:"Tere sang bitai lamhe meri sab se keemti daulat hain.",c:"romantic"},{t:"Zamane ko dikhaunga, hauslon ka alam.",c:"attitude"},{t:"Dil ne kaha tha yaqeen karo, dil hi galat tha.",c:"sad"},{t:"Tere bina meri har khushi adhoori hai.",c:"love"},{t:"Teri baaton mein woh jadoo hai jo sab kuch bhula de.",c:"romantic"},{t:"Main shah nahi, main faisla khud ka hoon.",c:"attitude"},{t:"Ghum mein doobi hui hansi, kisi ko samajh nahi aayi.",c:"sad"},{t:"Tere pyaar ne mera har dhoka bhula diya.",c:"love"},{t:"Tera milna hi meri duniya ki sab se khoobsurat naimat hai.",c:"romantic"},{t:"Apne hauslon se pahar bhi chalte hain.",c:"attitude"},{t:"Har muskurahat ke peeche ek kahani chhupi hoti hai.",c:"sad"},{t:"Tu meri ibaadat ka phal hai.",c:"love"},{t:"Tere naam ki mehndi mere dil pe lag gayi.",c:"romantic"},{t:"Jahan jaata hoon, wahan apna raaj chalata hoon.",c:"attitude"},{t:"Dard andar hi andar ghut-ta hai.",c:"sad"},{t:"Tera saath ho to zehar bhi amrit lagta hai.",c:"love"},{t:"Teri ek jhalak ke liye main umr bhar intezaar kar sakta hoon.",c:"romantic"},{t:"Khamoshi mera hathyar hai, toofan mera tevar.",c:"attitude"},{t:"Kuch log dil dukhane aate hain, aur chhod dete hain.",c:"sad"},{t:"Tere bina jeena adhura hai, tere saath mukammal.",c:"love"},{t:"Teri yaadon ka sahara meri raaton ka sahara hai.",c:"romantic"},{t:"Mannat kabhi maangni nahi pari, tu mil gaya.",c:"romantic"},{t:"Raat bhar jagta hoon, savere muskurata hoon.",c:"sad"},{t:"Mera dil tere bina beats nahi deta.",c:"love"},{t:"Tere kandhe se sar rakh kar sone ka maza hi kuch aur hai.",c:"romantic"},{t:"Do duni ka aadmi hoon, duniya se kya shikwa.",c:"attitude"},{t:"Muskurahat meri dhong hai, andar toofan hai.",c:"sad"},{t:"Tere pyaar mein maine apni duniya basa li.",c:"love"},{t:"Tera gussa bhi mujhe pyara lagta hai.",c:"romantic"},{t:"Sach aur saath, mera apna dastoor hai.",c:"attitude"},{t:"Tanhai mein hi meri asli duniya basti hai.",c:"sad"},{t:"Tere naam ki tehni meri sab se badi daulat.",c:"love"},{t:"Tere bina saari duniya bematlab lagti hai.",c:"romantic"},{t:"Main apne tareeqe se jeeta hoon, sab ki tarah nahi.",c:"attitude"},{t:"Log kaate hain, main chal utra.",c:"sad"},{t:"Teri mohabbat meri sab se badi kamyabi hai.",c:"love"},{t:"Tera chehra dekh kar andheri raat bhi ujli lagti hai.",c:"romantic"},{t:"Muqaddama mere hauslon ka hai, waqt dekh lega.",c:"attitude"},{t:"Ghum mein doobne se behtar hai doob kar bhi jeetna.",c:"sad"},{t:"Tere naam se meri har dua shuru hoti hai.",c:"love"},{t:"Tere saath bitai shaam meri sab se keemti raat hai.",c:"romantic"},{t:"Apne tareeqe se jee raha hoon, sab ki marzi se nahi.",c:"attitude"},{t:"Sab ne puchha kaise ho, kisi ne sach nahi puchha.",c:"sad"},{t:"Teri mohabbat meri ibaadat hai.",c:"love"},{t:"Tera milna meri duniya ki sab se badi naimat hai.",c:"romantic"},{t:"Apne hausle se aasmaan ko bhi chhua hai.",c:"attitude"},{t:"Har raat kuch na kuch tuta hai andar.",c:"sad"},{t:"Tere bina meri saansein bhi adhoori hain.",c:"love"},{t:"Tera naam meri har saans mein basta hai.",c:"romantic"},{t:"Zamana dekh lega, kiska hausla zyada hai.",c:"attitude"},{t:"Muskan ke peeche dard chhupana aasan nahi.",c:"sad"},{t:"Tere pyaar mein maine sab kuch paya hai.",c:"love"},{t:"Teri hansi meri duniya ki sab se pyaari aawaz hai.",c:"romantic"},{t:"Apni tehzeeb se sab ko shafaf rakhta hoon.",c:"attitude"},{t:"Kisi ko nahi bataya to kitna chhupaya.",c:"sad"},{t:"Tu meri har dua ka jawab hai.",c:"love"},{t:"Tera saath meri sab se badi taqat hai.",c:"romantic"},{t:"Main apne tareeqe se chalunga, sab ki marzi se nahi.",c:"attitude"},{t:"Dil ka dard koi nahi samajhta, bas khamoshi utha lete hain.",c:"sad"},{t:"Tere bina meri duniya mein roshni nahi.",c:"love"},{t:"Teri ek muskurahat meri saari thakan mita deti hai.",c:"romantic"},{t:"Main apni zindagi ka sultan hoon, kisi ka naukar nahi.",c:"attitude"},{t:"Raat bhar aankh nahi lagi, savere muskuraya.",c:"sad"},{t:"Tere pyaar mein maine apna sab kuch luta diya.",c:"love"},{t:"Tere kandhe se sar rakh kar lambe safar chhota lagta hai.",c:"romantic"},{t:"Apni duniya mein main badshah hoon, sab ko shafaf chahta hoon.",c:"attitude"},{t:"Ghum ne mujhe majboor kiya, maine muskurana chuna.",c:"sad"},{t:"Tera milna meri zindagi ka sab se pyara tohfa hai.",c:"romantic"},{t:"Tere naam ki tehni meri sab se badi daulat hai.",c:"love"}];var Ta=[{t:"Raat jitni gehri ho, subah utni haseen hoti hai.",c:"sad"},{t:"Tere bina ki shaam, bina suraj ke andheri hai.",c:"love"},{t:"Tera naam meri har dua ki pehli line hai.",c:"romantic"},{t:"Muqaddama meri khamoshi ka hai, jawab waqt dega.",c:"attitude"},{t:"Log badalte hain, humare adat purani reh gayi.",c:"sad"},{t:"Teri hansi meri subah ki pehli dawa hai.",c:"romantic"},{t:"Do duni ka aadmi hoon, duniya se kya gila.",c:"attitude"},{t:"Apne dil ki sunta hoon, duniya ki nahi.",c:"sad"},{t:"Tu meri woh dua hai jo maangi nahi thi, bas mil gayi.",c:"love"},{t:"Tere saath bitai raat meri sab se haseen yaad hai.",c:"romantic"},{t:"Jhukne se darta hoon, sirf apne parwardigar se.",c:"attitude"},{t:"Kuch log chhootte hain to zindagi bhar ka dard le jate hain.",c:"sad"},{t:"Tere naam se meri har kahani shuru hoti hai.",c:"love"},{t:"Tere bina ki duniya mein koi rang nahi.",c:"romantic"},{t:"Main apne hauslon se pahar bhi chala deta hoon.",c:"attitude"},{t:"Dard bataya to hasi aayi, chhupaya to samajh aayi.",c:"sad"},{t:"Tere pyaar ne meri zindagi ka matlab badal diya.",c:"love"},{t:"Tera chehra meri sab se pyaari tasveer hai.",c:"romantic"},{t:"Zamana kya samjhega, jo apne dil ka sultan hai.",c:"attitude"},{t:"Sab ko muskurata hoon, magar andar se toota hoon.",c:"sad"},{t:"Tere saath har safar jannat lagta hai.",c:"love"},{t:"Tere kandhe se sar rakhna meri duniya ki dawa hai.",c:"romantic"},{t:"Apni zid se peechhe nahi hatunga, jo hona hai hoga.",c:"attitude"},{t:"Khush rehne ka bahana dhoonda, tanhai se dosti kar li.",c:"sad"},{t:"Tere bina meri har khushi adhoori kahani hai.",c:"love"},{t:"Tera milna meri zindagi ki sab se badi naimat hai.",c:"romantic"},{t:"Sab ke samne chup, apne samne toofan.",c:"attitude"},{t:"Jo dard diya woh bhool nahi sakta, jo sahara diya woh yaad rakhta hoon.",c:"sad"},{t:"Mera dil tere naam ke siwa kisi ka nahi sunta.",c:"love"},{t:"Teri ek jhalak ke liye meri umr qurban hai.",c:"romantic"},{t:"Apni marzi ka badshah, sab ki marzi ka ghulam nahi.",c:"attitude"},{t:"Umeed ne dhoka diya to tanhai ne sahara diya.",c:"sad"},{t:"Tere pyaar ki raah mein sab kuch qurban hai.",c:"love"},{t:"Teri baaton mein woh nasha hai jo dawa mein nahi.",c:"romantic"},{t:"Muqaddama mera hausla hai, nateeja waqt dekhega.",c:"attitude"},{t:"Andheri raat mein bhi muskurata hoon, aadat si ho gayi.",c:"sad"},{t:"Tera naam likha hai meri kismat ki kitab mein.",c:"romantic"},{t:"Main apne tareeqe se chalta hoon, sab ki marzi se nahi.",c:"attitude"},{t:"Ghum chhupana aasan hai, samjhana mushkil.",c:"sad"},{t:"Teri muskurahat meri duniya ka sab se pyara tohfa hai.",c:"romantic"},{t:"Apne hausle ka muqaddama zamane se lena hai.",c:"attitude"},{t:"Kuch log dil se nikal jate hain, yaadon mein reh jate hain.",c:"sad"},{t:"Mera pyaar tere liye hai, baqi sab faltu hai.",c:"love"},{t:"Tera saath mil jaye to zindagi jannat lagti hai.",c:"romantic"},{t:"Sultan ban ke jiyunga, kahin ka ban ke nahi.",c:"attitude"},{t:"Raat bhar aankh nahi lagi, savere bhi muskuraya.",c:"sad"},{t:"Teri saanson se meri zindagi chalti hai.",c:"romantic"},{t:"Do duni ka aadmi hoon, kisi ka mohtaj nahi.",c:"attitude"},{t:"Log badal gaye, mera dil wahi ka wahi hai.",c:"sad"},{t:"Tere pyaar mein maine apni duniya basa li hai.",c:"love"},{t:"Apni tehzeeb meri pehchan hai, badal nahi sakta.",c:"attitude"},{t:"Har muskurahat ke peeche ek toota hua dil hota hai.",c:"sad"},{t:"Tu meri ibaadat ka sila hai, meri dua ka jawab.",c:"love"},{t:"Khamoshi meri taqat hai, toofan mera tevar.",c:"attitude"},{t:"Jo dard diya woh yaad hai, jo sahara diya woh yaad hai.",c:"sad"},{t:"Tere bina meri zindagi adhoori kahani hai.",c:"love"},{t:"Zamane ko dikhaunga hauslon ka alam.",c:"attitude"},{t:"Tera pyaar meri zindagi ki sab se badi kamyabi hai.",c:"love"},{t:"Tere sang har mausam bahaar lagta hai.",c:"romantic"},{t:"Main apni duniya ka badshah hoon, sab ko shafaf chahta hoon.",c:"attitude"},{t:"Tere naam ki tehni meri sab se keemti cheez hai.",c:"romantic"},{t:"Kuch log chhootte hain, aur kuch zakhm de jate hain.",c:"sad"},{t:"Tera pyaar hi meri sab se badi daulat hai.",c:"love"},{t:"Tera milna meri zindagi ka sab se pyara lamha hai.",c:"romantic"},{t:"Dard andar hi andar ghut-ta rehta hai.",c:"sad"},{t:"Main apne hausle se aasmaan gaadhta hoon.",c:"attitude"},{t:"Dil ki baat dil mein hi rehne do, sunne wale kam hain.",c:"sad"},{t:"Woh muskura kar chala gaya, aur main aansu chhupa kar.",c:"sad"},{t:"Kuch dard aise hote hain jo lafzon mein aa hi nahi sakte.",c:"sad"},{t:"Raat bhar jaaga hoon, khayalon ko neend nahi aayi.",c:"sad"},{t:"Sab to hai zindagi mein, bas woh sukoon nahi.",c:"sad"},{t:"Tanhaai se dosti aasan hai, logon se nibhana mushkil.",c:"sad"},{t:"Meri khamoshi ko kamzoori na samajhna, hisaab poora hai.",c:"sad"},{t:"Aansu bhi aaj kal sookh gaye hain, dard kam nahi hua.",c:"sad"},{t:"Kuch waqt aisa bhi aata hai, koi poochta hi nahi.",c:"sad"},{t:"Main khud se hi shikayat kar raha hoon, sunne wala koi nahi.",c:"sad"},{t:"Tere bina baith kar aksar tujhe sochta hoon.",c:"love"},{t:"Meri saari duaon mein tera hi naam hai.",c:"love"},{t:"Dil ne tujhe chaaha, aur chahta hi rahega.",c:"love"},{t:"Tere naam se hi meri subah roshan hoti hai.",c:"love"},{t:"Main tera hoon, ye sach sab ko batana chahta hoon.",c:"love"},{t:"Tere siva kis ko apna kehta, ye sochke chup ho jata hoon.",c:"love"},{t:"Dil ka haal sunana nahi aata, ishq karna aata hai.",c:"love"},{t:"Aankhon mein teri yaad aur dil mein tera naam hai.",c:"love"},{t:"Tujhe dekhta hoon to sara jahan bhool jata hoon.",c:"love"},{t:"Meri muhabbat ko tum kabhi kam na samjhna.",c:"love"}];function Z(e,a){try{let o=window.vellum;return o&&typeof o.fetch=="function"?o.fetch(e,a):typeof window.fetch=="function"?window.fetch(e,a):Promise.reject(new Error("no fetch bridge"))}catch(o){return Promise.reject(o)}}var Me=[...Ca,...Ta],To=24*60*60*1e3,Mo=Math.floor(Date.now()/To),Ma=Me[Mo%Me.length],ot={en:{sad:"Sad \u{1F622}",love:"Love \u{1F917}",romantic:"Romantic \u{1F495}",attitude:"Attitude \u{1F451}",qotd:"03 \u2014 Quote of the day"},ur:{sad:"\u0627\u062F\u0627\u0633 \u{1F622}",love:"\u0645\u062D\u0628\u062A \u{1F917}",romantic:"\u0631\u0648\u0645\u0627\u0646\u0648\u06CC \u{1F495}",attitude:"\u0627\u062A\u0679\u06CC\u0679\u06CC\u0648\u0688 \u{1F451}",qotd:"\u06F0\u06F3 \u2014 \u0622\u062C \u06A9\u0627 \u0642\u0648\u0644"}};function Te({value:e,suffix:a="",label:o}){let[n,r]=x(0),i=O(null),c=O(!1);return P(()=>{let d=i.current;if(!d)return;let g=window.matchMedia("(prefers-reduced-motion: reduce)").matches,p=new IntersectionObserver(h=>{if(!h[0].isIntersecting||c.current)return;if(c.current=!0,g){r(e);return}let l=performance.now(),y=1600,_=T=>{let S=Math.min(1,(T-l)/y);r(Math.round(e*(1-Math.pow(1-S,3)))),S<1&&requestAnimationFrame(_)};requestAnimationFrame(_)},{threshold:.4});return p.observe(d),()=>p.disconnect()},[e]),t("div",{class:"stat",ref:i,children:[t("span",{class:"stat-num",children:[n.toLocaleString(),a]}),t("span",{class:"stat-label",children:o})]})}var nt=[{id:"classic",family:"Classic",preview:"Aa",stack:'Georgia, "Times New Roman", serif'},{id:"modern",family:"Modern",preview:"Aa",stack:'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif'},{id:"elegant",family:"Elegant",preview:"Aa",stack:'"Palatino Linotype", "Book Antiqua", Palatino, "Bookman Old Style", serif'},{id:"mono",family:"Mono",preview:"Aa",stack:'ui-monospace, "SF Mono", Menlo, Consolas, monospace'},{id:"playfair",family:"Playfair Display",preview:"Aa",stack:'"Playfair Display", Georgia, serif'},{id:"lobster",family:"Lobster",preview:"Aa",stack:'"Lobster", cursive'},{id:"pacifico",family:"Pacifico",preview:"Aa",stack:'"Pacifico", cursive'},{id:"dancing",family:"Dancing Script",preview:"Aa",stack:'"Dancing Script", cursive'},{id:"bebas",family:"Bebas Neue",preview:"Aa",stack:'"Bebas Neue", Impact, sans-serif'},{id:"cinzel",family:"Cinzel",preview:"Aa",stack:'"Cinzel", Georgia, serif'},{id:"poppins",family:"Poppins",preview:"Aa",stack:'"Poppins", system-ui, sans-serif'},{id:"quicksand",family:"Quicksand",preview:"Aa",stack:'"Quicksand", system-ui, sans-serif'},{id:"merriweather",family:"Merriweather",preview:"Aa",stack:'"Merriweather", Georgia, serif'},{id:"orbitron",family:"Orbitron",preview:"Aa",stack:'"Orbitron", system-ui, sans-serif'},{id:"greatvibes",family:"Great Vibes",preview:"Aa",stack:'"Great Vibes", cursive'},{id:"caveat",family:"Caveat",preview:"Aa",stack:'"Caveat", cursive'}],zo={en:{kicker:"Top Student",heroSub:"Silent mind \u{1F5A4} \u2014 king \u{1F451} of my own world \u{1F30D}.",contactBtn:"Contact me",achievementsBtn:"Achievements",bio:"01 \u2014 Bio",meLines:["My name is Saqib, and I'm the king \u{1F451} of my own world \u{1F30D}.","My age is 17, and I'm studying in first year ICS.","My father's name is Muhammad Iqbal.","In 9th class I scored 1080/1200, and in 10th I scored 483/545.","I'm a Hafiz-e-Quran Pak \u{1F4D6} \u2014 the pride of my life.","I have 3 brothers and 1 sister \u2014 my strength, my family.","My favourite colour is black \u{1F5A4} \u2014 it matches my silence.","I love nature \u{1F33F}, and yes, my mood often stays quiet and sad \u2014 that's just me.","On the pitch, I'm dangerous \u2014 bowling and batting, both \u{1F3CF}."],factK:["Full name","Father's name","Age","Class","Siblings","Favourite colour"],factV:["Saqib Iqbal","Muhammad Iqbal","17","First Year \u2014 ICS","3 brothers \xB7 1 sister","Black \u{1F5A4}"],quote:"\u201CWalk alone, stay silent, rule your own world \u{1F30D} \u2014 the rest is noise.\u201D",ach:"02 \u2014 Achievements",statLabels:["Years old","Matric result (10th)","10th class marks","9th class marks"],tags:["Hafiz-e-Quran Pak \u{1F4D6}","Cricket \u2014 bowling & batting \u{1F3CF}","Good looking \u2728","Nature lover \u{1F33F}"],gallery:"05 \u2014 Gallery",memories:"My memories \u{1FAC0}",myPics:"My Pictures",myVids:"My Videos",picsSub:"14 items \u00B7 3 categories",vidsSub:"2 items \xB7 categorized",quiz:"07 \u2014 Quiz",qa:"08 \u2014 Q&A",contact:"09 \u2014 Contact",letsConnect:"Let's connect.",contactSub:"Open to opportunities, collaborations and learning experiences.",hideContact:"Hide contact",copyEmail:"Copy email",copied:"Copied \u2713",emailLabel:"Email",crafted:"Crafted with care",visitors:"Visitors",share:"Share",cv:"Download CV",cvSec:"07 \u2014 CV",cvNote:"A one-page CV with education, results, skills and contact.",galTop:"Gallery",home:"\u2190 Home",cats:["All Photos","Favourites","Night & Nature","Portraits","With Friends"],empty:"Nothing in this category.",galNote:"Photos & videos organized in categories \u2014 not on the main page.",galEmptyPhotos:"Nothing in this category.",galEmptyVideos:"Videos are on the way \u2014 coming soon.",photo:"photo",video:"video",gb:"06 \u2014 Guestbook",gbSub:"Leave a message for Saqib \u2014 it will appear on this page.",gbName:"Your name",gbMsg:"Your message",gbSend:"Send",gbSending:"Sending...",gbEmpty:"Be the first to leave a message.",gbThanks:"Thank you! Your message is on the wall.",gbError:"Couldn't send \u2014 try again.",authLogin:"Log in",authSignup:"Sign up",authEmail:"Email",authPass:"Password (min 6 characters)",authName:"Your name",authToSignup:"New here? Create an account",authToLogin:"Already have an account? Log in",authWelcome:"Welcome",authLogout:"Log out",authSocialNote:"Google / TikTok / Facebook login activates after the site goes live \u2014 use email for now.",authBad:"Check your details and try again."},ur:{kicker:"\u0645\u0645\u062A\u0627\u0632 \u0637\u0627\u0644\u0628 \u0639\u0644\u0645",heroSub:"\u062E\u0627\u0645\u0648\u0634 \u0630\u06C1\u0646 \u{1F5A4} \u2014 \u0627\u067E\u0646\u06CC \u062F\u0646\u06CC\u0627 \u{1F30D} \u06A9\u0627 \u0628\u0627\u062F\u0634\u0627\u06C1 \u{1F451}\u06D4",contactBtn:"\u0631\u0627\u0628\u0637\u06C1 \u06A9\u0631\u06CC\u06BA",achievementsBtn:"\u06A9\u0627\u0645\u06CC\u0627\u0628\u06CC\u0627\u06BA",bio:"\u06F0\u06F1 \u2014 \u062A\u0639\u0627\u0631\u0641",meLines:["\u0645\u06CC\u0631\u0627 \u0646\u0627\u0645 \u0633\u0627\u0642\u0628 \u06C1\u06D2\u060C \u0627\u0648\u0631 \u0645\u06CC\u06BA \u0627\u067E\u0646\u06CC \u062F\u0646\u06CC\u0627 \u{1F30D} \u06A9\u0627 \u0628\u0627\u062F\u0634\u0627\u06C1 \u{1F451} \u06C1\u0648\u06BA\u06D4","\u0645\u06CC\u0631\u06CC \u0639\u0645\u0631 17 \u0633\u0627\u0644 \u06C1\u06D2\u060C \u0627\u0648\u0631 \u0645\u06CC\u06BA \u0641\u0631\u0633\u0679 \u0627\u0626\u06CC\u0626\u0631 \u0622\u0626\u06CC \u0633\u06CC \u0627\u06CC\u0633 \u0645\u06CC\u06BA \u067E\u0691\u06BE \u0631\u06C1\u0627 \u06C1\u0648\u06BA\u06D4","\u0645\u06CC\u0631\u06D2 \u0648\u0627\u0644\u062F \u06A9\u0627 \u0646\u0627\u0645 \u0645\u062D\u0645\u062F \u0627\u0642\u0628\u0627\u0644 \u06C1\u06D2\u06D4","\u0646\u0648\u06CC\u06BA \u062C\u0645\u0627\u0639\u062A \u0645\u06CC\u06BA \u0645\u06CC\u06BA \u0646\u06D2 1080/1200 \u0627\u0648\u0631 \u062F\u0633\u0648\u06CC\u06BA \u0645\u06CC\u06BA 483/545 \u0646\u0645\u0628\u0631 \u062D\u0627\u0635\u0644 \u06A9\u06CC\u06D2\u06D4","\u0645\u06CC\u06BA \u062D\u0627\u0641\u0638\u0650 \u0642\u0631\u0622\u0646 \u067E\u0627\u06A9 \u{1F4D6} \u06C1\u0648\u06BA \u2014 \u0645\u06CC\u0631\u06CC \u0632\u0646\u062F\u06AF\u06CC \u06A9\u0627 \u0641\u062E\u0631\u06D4","\u0645\u06CC\u0631\u06D2 3 \u0628\u06BE\u0627\u0626\u06CC \u0627\u0648\u0631 1 \u0628\u06C1\u0646 \u06C1\u06CC\u06BA \u2014 \u0645\u06CC\u0631\u06CC \u0637\u0627\u0642\u062A\u060C \u0645\u06CC\u0631\u0627 \u062E\u0627\u0646\u062F\u0627\u0646\u06D4","\u0645\u06CC\u0631\u0627 \u067E\u0633\u0646\u062F\u06CC\u062F\u06C1 \u0631\u0646\u06AF \u06A9\u0627\u0644\u0627 \u{1F5A4} \u06C1\u06D2 \u2014 \u062C\u0648 \u0645\u06CC\u0631\u06CC \u062E\u0627\u0645\u0648\u0634\u06CC \u0633\u06D2 \u0645\u0644\u062A\u0627 \u06C1\u06D2\u06D4","\u0645\u062C\u06BE\u06D2 \u0641\u0637\u0631\u062A \u{1F33F} \u0633\u06D2 \u0645\u062D\u0628\u062A \u06C1\u06D2\u060C \u0627\u0648\u0631 \u0645\u06CC\u0631\u0627 \u0645\u0648\u0688 \u0627\u06A9\u062B\u0631 \u062E\u0627\u0645\u0648\u0634 \u0627\u0648\u0631 \u0627\u062F\u0627\u0633 \u0631\u06C1\u062A\u0627 \u06C1\u06D2 \u2014 \u0628\u0633 \u06CC\u06C1\u06CC \u0645\u06CC\u06BA \u06C1\u0648\u06BA\u06D4","\u0645\u06CC\u062F\u0627\u0646 \u0645\u06CC\u06BA \u0645\u06CC\u06BA \u062E\u0637\u0631\u0646\u0627\u06A9 \u06C1\u0648\u06BA \u2014 \u0628\u0648\u0644\u0646\u06AF \u0627\u0648\u0631 \u0628\u06CC\u0679\u0646\u06AF\u060C \u062F\u0648\u0646\u0648\u06BA \u{1F3CF}\u06D4"],factK:["\u067E\u0648\u0631\u0627 \u0646\u0627\u0645","\u0648\u0627\u0644\u062F \u06A9\u0627 \u0646\u0627\u0645","\u0639\u0645\u0631","\u062C\u0645\u0627\u0639\u062A","\u0628\u06C1\u0646 \u0628\u06BE\u0627\u0626\u06CC","\u067E\u0633\u0646\u062F\u06CC\u062F\u06C1 \u0631\u0646\u06AF"],factV:["\u0633\u0627\u0642\u0628 \u0627\u0642\u0628\u0627\u0644","\u0645\u062D\u0645\u062F \u0627\u0642\u0628\u0627\u0644","17","\u0641\u0631\u0633\u0679 \u0627\u0626\u06CC\u0626\u0631 \u2014 \u0622\u0626\u06CC \u0633\u06CC \u0627\u06CC\u0633","3 \u0628\u06BE\u0627\u0626\u06CC \xB7 1 \u0628\u06C1\u0646","\u06A9\u0627\u0644\u0627 \u{1F5A4}"],quote:"\u201C\u062A\u0646\u06C1\u0627 \u0686\u0644\u0648\u060C \u062E\u0627\u0645\u0648\u0634 \u0631\u06C1\u0648\u060C \u0627\u067E\u0646\u06CC \u062F\u0646\u06CC\u0627 \u{1F30D} \u067E\u0631 \u062D\u06A9\u0648\u0645\u062A \u06A9\u0631\u0648 \u2014 \u0628\u0627\u0642\u06CC \u0633\u0628 \u0634\u0648\u0631 \u06C1\u06D2\u06D4\u201D",ach:"\u06F0\u06F2 \u2014 \u06A9\u0627\u0645\u06CC\u0627\u0628\u06CC\u0627\u06BA",statLabels:["\u0633\u0627\u0644 \u06A9\u0627","\u0645\u06CC\u0679\u0631\u06A9 \u0646\u062A\u06CC\u062C\u06C1 (\u062F\u0633\u0648\u06CC\u06BA)","\u062F\u0633\u0648\u06CC\u06BA \u062C\u0645\u0627\u0639\u062A \u0646\u0645\u0628\u0631","\u0646\u0648\u06CC\u06BA \u062C\u0645\u0627\u0639\u062A \u0646\u0645\u0628\u0631"],tags:["\u062D\u0627\u0641\u0638\u0650 \u0642\u0631\u0622\u0646 \u067E\u0627\u06A9 \u{1F4D6}","\u06A9\u0631\u06A9\u0679 \u2014 \u0628\u0648\u0644\u0646\u06AF \u0627\u0648\u0631 \u0628\u06CC\u0679\u0646\u06AF \u{1F3CF}","\u062E\u0648\u0634 \u0634\u06A9\u0644 \u2728","\u0641\u0637\u0631\u062A \u0633\u06D2 \u0645\u062D\u0628\u062A \u{1F33F}"],gallery:"\u06F0\u06F5 \u2014 \u06AF\u06CC\u0644\u0631\u06CC",memories:"\u0645\u06CC\u0631\u06CC \u06CC\u0627\u062F\u06AF\u06CC\u0631\u06CC\u06BA \u{1FAC0}",myPics:"\u0645\u06CC\u0631\u06CC \u062A\u0635\u0627\u0648\u06CC\u0631",myVids:"\u0645\u06CC\u0631\u06CC \u0648\u06CC\u0688\u06CC\u0648\u0632",picsSub:"14 \u062A\u0635\u0627\u0648\u06CC\u0631 \u00B7 3 \u0627\u0642\u0633\u0627\u0645",vidsSub:"2 \u0648\u06CC\u0688\u06CC\u0648\u0632 \xB7 \u0627\u0642\u0633\u0627\u0645 \u06A9\u06D2 \u0633\u0627\u062A\u06BE",quiz:"\u06F0\u06F7 \u2014 \u06A9\u0648\u0626\u0632",qa:"\u06F0\u06F8 \u2014 \u0633\u0648\u0627\u0644 \u062C\u0648\u0627\u0628",contact:"\u06F0\u06F9 \u2014 \u0631\u0627\u0628\u0637\u06C1",letsConnect:"\u0622\u0626\u06CC\u06D2 \u062C\u064F\u0691\u06CC\u06BA\u06D4",contactSub:"\u0645\u0648\u0642\u0639\u0648\u06BA\u060C \u062A\u0639\u0627\u0648\u0646 \u0627\u0648\u0631 \u0633\u06CC\u06A9\u06BE\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2 \u06A9\u06BE\u0644\u0627 \u06C1\u0648\u06BA\u06D4",hideContact:"\u0686\u06BE\u067E\u0627\u0626\u06CC\u06BA",copyEmail:"\u0627\u06CC \u0645\u06CC\u0644 \u06A9\u0627\u067E\u06CC \u06A9\u0631\u06CC\u06BA",copied:"\u06A9\u0627\u067E\u06CC \u06C1\u0648 \u06AF\u06CC\u0627 \u2713",emailLabel:"\u0627\u06CC \u0645\u06CC\u0644",crafted:"\u0645\u062D\u0628\u062A \u0633\u06D2 \u0628\u0646\u0627\u06CC\u0627 \u06AF\u06CC\u0627",visitors:"\u0648\u0632\u0679\u0631\u0632",share:"\u0634\u06CC\u0626\u0631 \u06A9\u0631\u06CC\u06BA",cv:"\u0633\u06CC \u0648\u06CC \u0688\u0627\u0624\u0646 \u0644\u0648\u0688 \u06A9\u0631\u06CC\u06BA",cvSec:"\u06F0\u06F7 \u2014 \u0633\u06CC \u0648\u06CC",cvNote:"\u0627\u06CC\u06A9 \u0635\u0641\u062D\u06D2 \u067E\u0631 \u0633\u06CC \u0648\u06CC: \u062A\u0639\u0644\u06CC\u0645\u060C \u0646\u062A\u0627\u0626\u062C\u060C \u0645\u06C1\u0627\u0631\u062A\u06CC\u06BA \u0627\u0648\u0631 \u0631\u0627\u0628\u0637\u06C1\u06D4",galTop:"\u06AF\u06CC\u0644\u0631\u06CC",home:"\u2190 \u06C1\u0648\u0645",cats:["\u062A\u0645\u0627\u0645 \u062A\u0635\u0627\u0648\u06CC\u0631","\u067E\u0633\u0646\u062F\u06CC\u062F\u06C1","\u0631\u0627\u062A \u0627\u0648\u0631 \u0641\u0637\u0631\u062A","\u067E\u0648\u0631\u0679\u0631\u06CC\u0679","\u062F\u0648\u0633\u062A\u0648\u06BA \u06A9\u06D2 \u0633\u0627\u062A\u06BE"],empty:"\u0627\u0633 \u0642\u0633\u0645 \u0645\u06CC\u06BA \u06A9\u0686\u06BE \u0646\u06C1\u06CC\u06BA \u06C1\u06D2\u06D4",galNote:"\u062A\u0635\u0627\u0648\u06CC\u0631 \u0627\u0648\u0631 \u0648\u06CC\u0688\u06CC\u0648\u0632 \u0627\u0642\u0633\u0627\u0645 \u0645\u06CC\u06BA \u0645\u0646\u0638\u0645 \u06C1\u06CC\u06BA \u2014 \u0645\u06CC\u0646 \u0635\u0641\u062D\u06D2 \u067E\u0631 \u0646\u06C1\u06CC\u06BA\u06D4",galEmptyPhotos:"\u0627\u0633 \u0642\u0633\u0645 \u0645\u06CC\u06BA \u06A9\u0686\u06BE \u0646\u06C1\u06CC\u06BA \u06C1\u06D2\u06D4",galEmptyVideos:"\u0648\u06CC\u0688\u06CC\u0648\u0632 \u062C\u0644\u062F \u0622 \u0631\u06C1\u06CC \u06C1\u06CC\u06BA \u2014 \u0627\u0646\u0634\u0627\u0621\u0627\u0644\u0644\u06C1\u06D4",photo:"\u062A\u0635\u0648\u06CC\u0631",video:"\u0648\u06CC\u0688\u06CC\u0648",gb:"\u06F0\u06F6 \u2014 \u0645\u06C1\u0645\u0627\u0646 \u06A9\u062A\u0627\u0628",gbSub:"\u0633\u0627\u0642\u0628 \u06A9\u06D2 \u0644\u06CC\u06D2 \u0627\u06CC\u06A9 \u067E\u06CC\u063A\u0627\u0645 \u0686\u06BE\u0648\u0691\u06CC\u06BA \u2014 \u06CC\u06C1 \u0627\u0633\u06CC \u0635\u0641\u062D\u06D2 \u067E\u0631 \u0646\u0638\u0631 \u0622\u0626\u06D2 \u06AF\u0627\u06D4",gbName:"\u0622\u067E \u06A9\u0627 \u0646\u0627\u0645",gbMsg:"\u0622\u067E \u06A9\u0627 \u067E\u06CC\u063A\u0627\u0645",gbSend:"\u0628\u06BE\u06CC\u062C\u06CC\u06BA",gbSending:"\u0628\u06BE\u06CC\u062C\u0627 \u062C\u0627 \u0631\u06C1\u0627 \u06C1\u06D2...",gbEmpty:"\u067E\u06C1\u0644\u0627 \u067E\u06CC\u063A\u0627\u0645 \u0622\u067E \u0628\u06BE\u06CC\u062C\u06CC\u06BA\u06D4",gbThanks:"\u0634\u06A9\u0631\u06CC\u06C1! \u0622\u067E \u06A9\u0627 \u067E\u06CC\u063A\u0627\u0645 \u062F\u06CC\u0648\u0627\u0631 \u067E\u0631 \u0644\u06AF \u06AF\u06CC\u0627\u06D4",gbError:"\u0628\u06BE\u06CC\u062C\u0627 \u0646\u06C1\u06CC\u06BA \u062C\u0627 \u0633\u06A9\u0627 \u2014 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4",authLogin:"\u0644\u0627\u06AF \u0627\u0646",authSignup:"\u0633\u0627\u0626\u0646 \u0627\u067E",authEmail:"\u0627\u06CC\u0645\u06CC\u0644",authPass:"\u067E\u0627\u0633 \u0648\u0631\u0688 (\u06A9\u0645 \u0627\u0632 \u06A9\u0645 6 \u062D\u0631\u0648\u0641)",authName:"\u0622\u067E \u06A9\u0627 \u0646\u0627\u0645",authToSignup:"\u0646\u0626\u06D2 \u06C1\u06CC\u06BA\u061F \u0627\u06A9\u0627\u0624\u0646\u0679 \u0628\u0646\u0627\u0626\u06CC\u06BA",authToLogin:"\u0627\u06A9\u0627\u0624\u0646\u0679 \u06C1\u06D2\u061F \u0644\u0627\u06AF \u0627\u0646 \u06A9\u0631\u06CC\u06BA",authWelcome:"\u062E\u0648\u0634 \u0622\u0645\u062F\u06CC\u062F",authLogout:"\u0644\u0627\u06AF \u0622\u0624\u0679",authSocialNote:"\u06AF\u0648\u06AF\u0644 / \u0679\u06A9 \u0679\u0627\u06A9 / \u0641\u06CC\u0633 \u0628\u06A9 \u0644\u0627\u06AF \u0627\u0646 \u0633\u0627\u0626\u0679 \u0644\u0627\u0626\u06CC\u0648 \u06C1\u0648\u0646\u06D2 \u06A9\u06D2 \u0628\u0639\u062F \u0641\u0639\u0627\u0644 \u06C1\u0648\u06AF\u0627 \u2014 \u0641\u06CC \u0627\u0644\u062D\u0627\u0644 \u0627\u06CC\u0645\u06CC\u0644 \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u0631\u06CC\u06BA\u06D4",authBad:"\u0627\u067E\u0646\u06CC \u062A\u0641\u0635\u06CC\u0644\u0627\u062A \u0686\u06CC\u06A9 \u06A9\u0631 \u06A9\u06D2 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4"}},ee=["all","favs","night","portrait","friends"],te=[{id:40,src:"assets/photos/1000943915.jpg",cat:"portrait"},{id:41,src:"assets/photos/1000943911.jpg",cat:"portrait"},{id:42,src:"assets/photos/1000943912.jpg",cat:"portrait"},{id:3,src:"assets/photos/1000943976.jpg",cat:"portrait"},{id:13,src:"assets/photos/1000943914.jpg",cat:"portrait"},{id:100,src:"assets/photos/1000943966.jpg",cat:"portrait"},{id:23,src:"assets/photos/1000943947.jpg",cat:"friends"},{id:26,src:"assets/photos/1000943913.jpg",cat:"portrait"},{id:28,src:"assets/photos/1000943952.jpg",cat:"portrait"},{id:29,src:"assets/photos/1000943951.jpg",cat:"portrait"},{id:30,src:"assets/photos/1000943954.jpg",cat:"portrait"},{id:31,src:"assets/photos/1000943944.jpg",cat:"night"},{id:32,src:"assets/photos/1000943946.jpg",cat:"night"},{id:39,src:"assets/photos/1000943977.jpg",cat:"portrait"}],ce=[];function za(){let[e,a]=x(()=>(()=>{try{return j.getItem("portfolio-lang")}catch{return null}})()||"en"),[o,n]=x("home"),[r,i]=x("photos"),[c,d]=x("all"),[g,p]=x(!1),[h,l]=x({}),[y,_]=x(null),[T,S]=x({}),[M,b]=x(()=>{try{return JSON.parse(j.getItem("portfolio-photo-reacts")||"{}")}catch{return{}}});P(()=>{let s=!1;return Z("/v1/x/photo-reactions").then(m=>m.ok?m.json():Promise.reject(m.status)).then(m=>{s||S(m??{})}).catch(()=>{}),()=>{s=!0}},[]);let f=(s,m)=>{let k=M[s]===m;b(C=>{let u={...C};return k?delete u[s]:u[s]=m,j.setItem("portfolio-photo-reacts",JSON.stringify(u)),u}),S(C=>({...C,[s]:{love:0,fire:0,wow:0,...C[s]??{},[m]:Math.max(0,(C[s]?.[m]??0)+(k?-1:1))}})),gbSafeFetch("/v1/x/photo-reactions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({src:s,reaction:m,undo:k})}).catch(()=>{})},[z,L]=x(1),[N,A]=x({x:0,y:0}),[B,$]=x(()=>{try{return JSON.parse(j.getItem("portfolio-photo-favs")||"{}")}catch{return{}}}),q=s=>{$(m=>{let k={...m};return k[s]?delete k[s]:k[s]=!0,j.setItem("portfolio-photo-favs",JSON.stringify(k)),k})},[V,ae]=x(!1),[rt,it]=x(0),je=O(0),D=(r==="photos"?te:ce).filter(s=>c==="all"||(c==="favs"?!!B[s.src]:s.cat===c)),oe=O(null),Y=O(null),F=O(null),st=s=>{L(1),A({x:0,y:0}),lt(!1),dt(!1),ae(!1),_(s)},Le=s=>{let m=Math.min(4,Math.max(1,s));L(m),m<=1.01&&A({x:0,y:0})},La=s=>{if(s.touches.length===2){let m=Math.hypot(s.touches[0].clientX-s.touches[1].clientX,s.touches[0].clientY-s.touches[1].clientY);oe.current={d:m,z},Y.current=null}else s.touches.length===1&&z>1.01&&(Y.current={x:N.x,y:N.y,px:s.touches[0].clientX,py:s.touches[0].clientY});s.touches.length===1&&z<=1.01&&(F.current={x:s.touches[0].clientX,y:s.touches[0].clientY,dx:0})},Ia=s=>{if(s.touches.length===2&&oe.current){let m=Math.hypot(s.touches[0].clientX-s.touches[1].clientX,s.touches[0].clientY-s.touches[1].clientY);Le(oe.current.z*(m/oe.current.d))}else if(s.touches.length===1&&Y.current){let m=s.touches[0];A({x:Y.current.x+(m.clientX-Y.current.px),y:Y.current.y+(m.clientY-Y.current.py)})}s.touches.length===1&&F.current&&z<=1.01&&(F.current.dx=s.touches[0].clientX-F.current.x)},Ea=s=>{if(F.current&&z<=1.01){let m=(s.changedTouches[0]?.clientY??F.current.y)-F.current.y;if(Math.abs(F.current.dx)>55&&Math.abs(F.current.dx)>Math.abs(m)){let k=F.current.dx<0?1:-1,C=r==="photos"?te.length:ce.length;C>1&&_(u=>u===null?u:(u+k+C)%C)}else if(m>80&&Math.abs(F.current.dx)<55)_(null),L(1),A({x:0,y:0});else if(Math.abs(F.current.dx)<12&&Math.abs(m)<12){let k=Date.now(),C=D[y??-1]?.src;C&&k-je.current<320?(je.current=0,M[C]!=="love"&&f(C,"love"),it(u=>u+1)):je.current=k}}F.current=null,oe.current=null,Y.current=null,z<=1.01&&A({x:0,y:0})},[de,lt]=x(!1),[ct,dt]=x(!1),[Ie,pt]=x(null);P(()=>{if(!de||y===null)return;let s=setInterval(()=>{_(m=>m===null?m:(m+1)%D.length)},3e3);return()=>clearInterval(s)},[de,y!==null]);let Pa=async s=>{try{let m=await(await fetch(h[s])).blob(),k=new File([m],s.split("/").pop()||"photo.jpg",{type:m.type}),C=navigator;if(C.canShare&&C.canShare({files:[k]})){await C.share({files:[k],title:"Saqib Iqbal \u2014 Portfolio Photo"});return}}catch{}Tt()};P(()=>{let s=!1;return(async()=>{let m=await Promise.all([...te,...ce].map(async k=>{try{return[k.src,await window.vellum.asset(k.src)]}catch{return[k.src,""]}}));s||l(Object.fromEntries(m.filter(([,k])=>k)))})(),()=>{s=!0}},[]);let[ut,ht]=x(!1),[Ee,mt]=x(null),[Pe,ft]=x(""),[Ne,gt]=x(""),[Ae,bt]=x(!1),[vt,qe]=x(""),[U,ne]=x(null),[Na,_t]=x(!1),[yt,xt]=x(()=>j.getItem(at)==="granted"?"ok":"ask"),[Aa,qa]=x(()=>j.getItem("portfolio-perms-setup")==="done"),Ra=()=>{j.setItem(at,"granted"),xt("ok")},Ba=()=>{ka(),xt("no")};P(()=>{let s=null;try{s=j.getItem("portfolio-auth-token")}catch{s=null}if(!s){try{let u=j.getItem("portfolio-auth-local");u&&ne(JSON.parse(u))}catch{}_t(!0);return}let m=!1,k=new Promise(u=>setTimeout(()=>u(null),2500)),C=gbSafeFetch("/v1/x/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"me",token:s})}).then(u=>u.ok?u.json():Promise.reject(u.status)).then(u=>({name:u.name,email:u.email})).catch(()=>{try{j.removeItem("portfolio-auth-token")}catch{}return null});return Promise.race([C,k]).then(u=>{if(!m){if(u)ne(u);_t(!0)}}),()=>{m=!0}},[]);let Da=async()=>{let s=null;try{s=j.getItem("portfolio-auth-token")}catch{s=null}s&&Z("/v1/x/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"logout",token:s})}).catch(()=>{});try{j.removeItem("portfolio-auth-token")}catch{}try{j.removeItem("portfolio-auth-local")}catch{}ne(null)},[kt,wt]=x(null),[pe,Oa]=x(()=>{try{return j.getItem("portfolio-theme")==="light"?"light":"dark"}catch{return"dark"}}),[St,ue]=x(!1),[he,Fa]=x(()=>{try{return j.getItem("portfolio-font")||"classic"}catch{return"classic"}}),[Re,me]=x(!1),[Ct,Be]=x(""),v=zo[e],J=e==="ur",De="fizanali6267@gmail.com",Ha="+92 313 4182952",Oe=()=>{let s=e==="en"?"ur":"en";a(s),j.setItem("portfolio-lang",s)};P(()=>{document.documentElement.classList.toggle("theme-light",pe==="light")},[pe]),P(()=>{let s=document.documentElement;nt.forEach(m=>s.classList.remove("font-"+m.id)),s.classList.add("font-"+he)},[he]),P(()=>{let s=!1;return(async()=>{let m=await Promise.all(nt.filter(C=>C.file).map(async C=>{try{let u=await window.vellum.asset(C.file);return`@font-face { font-family: '${C.family}'; src: url('${u}'); font-display: swap; }`}catch{return""}}));if(s)return;let k=document.createElement("style");k.id="bundled-fonts",k.textContent=m.filter(Boolean).join(`
`),document.head.appendChild(k)})(),()=>{s=!0}},[]);let Ua=s=>{Fa(s),j.setItem("portfolio-font",s)},Wa=()=>{let s=pe==="dark"?"light":"dark";Oa(s),j.setItem("portfolio-theme",s)},Va=async()=>{try{await navigator.clipboard.writeText(De),p(!0),setTimeout(()=>p(!1),2e3)}catch{p(!1)}},Tt=()=>{let s=`Saqib Iqbal \u2014 Portfolio ${window.location.href}`;window.open(`https://wa.me/?text=${encodeURIComponent(s)}`,"_blank")},$a=async()=>{try{let s=await window.vellum.asset("assets/cv-saqib-iqbal.pdf"),m=document.createElement("a");m.href=s,m.download="Saqib-Iqbal-CV.pdf",document.body.appendChild(m),m.click(),m.remove()}catch{}},Fe=s=>{i(s),d("all"),n("gallery"),window.scrollTo({top:0})},Mt=()=>{Z("/v1/x/guestbook").then(s=>s.ok?s.json():Promise.reject(s.status)).then(mt).catch(()=>mt([]))};P(()=>{o==="home"&&Mt()},[o]),P(()=>{if(o!=="home")return;(sessionStorage.getItem("portfolio-visited")?Z("/v1/x/visitors").then(k=>k.ok?k.json():Promise.reject(k.status)):Z("/v1/x/visitors",{method:"POST"}).then(k=>{if(k.ok)sessionStorage.setItem("portfolio-visited","1");else return Promise.reject(k.status);return k.json()})).then(k=>wt(k.count)).catch(()=>wt(null))},[o]);let Ga=async s=>{if(s.preventDefault(),!(!Pe.trim()||!Ne.trim()||Ae)){bt(!0);try{if(!(await Z("/v1/x/guestbook",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:Pe,message:Ne})})).ok)throw new Error;ft(""),gt(""),qe(v.gbThanks),Mt()}catch{qe(v.gbError)}finally{bt(!1),setTimeout(()=>qe(""),4e3)}}};P(()=>{if(o!=="home")return;let s=document.querySelectorAll(".section"),m=new IntersectionObserver(C=>{for(let u of C)u.isIntersecting&&u.target.classList.add("in-view")},{threshold:.08});s.forEach(C=>m.observe(C));let k=setTimeout(()=>{Array.from(s).some(u=>u.classList.contains("in-view"))||(s.forEach(u=>u.classList.add("in-view")),m.disconnect())},2500);return()=>{clearTimeout(k),m.disconnect()}},[o]);let Ya=t("div",{class:"social-row",children:[t("a",{class:"wa-top",href:"https://wa.me/923134182952",target:"_blank",rel:"noopener","aria-label":"Chat on WhatsApp Business at +92 313 4182952",children:t("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"#2fb967","aria-hidden":"true",children:t("path",{d:"M12 2a10 10 0 0 0-8.5 15.3L2 22l4.8-1.4A10 10 0 1 0 12 2zm0 18.2c-1.6 0-3.1-.4-4.4-1.2l-.3-.2-2.9.8.8-2.8-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.6-6.1c-.3-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1-.2.3-.6.8-.8 1-.1.2-.3.2-.5.1-.3-.1-1.1-.4-2.1-1.3-.8-.7-1.3-1.6-1.5-1.8-.1-.3 0-.4.1-.5l.4-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5 0-.1-.6-1.4-.8-1.9-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.2s.9 2.5 1.1 2.7c.1.2 1.8 2.8 4.4 3.9.6.3 1.1.4 1.5.6.6.2 1.2.2 1.6.1.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.6-.3z"})})}),t("a",{class:"wa-top",href:"https://www.instagram.com/saqi_boffical",target:"_blank",rel:"noopener","aria-label":"Instagram: saqi_boffical",children:t("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"none",stroke:"#e97b9c","stroke-width":"1.8","aria-hidden":"true",children:[t("rect",{x:"3",y:"3",width:"18",height:"18",rx:"5"}),t("circle",{cx:"12",cy:"12",r:"4"}),t("circle",{cx:"17.2",cy:"6.8",r:"1.1",fill:"#e97b9c",stroke:"none"})]})}),t("a",{class:"wa-top",href:"https://www.tiktok.com/@saqibiqbaloffical1",target:"_blank",rel:"noopener","aria-label":"TikTok: saqibiqbaloffical1",children:t("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"currentColor","aria-hidden":"true",children:t("path",{d:"M16.6 3c.3 1.7 1.5 3 3.4 3.2v2.6c-1.3.1-2.5-.3-3.4-1v5.7c0 3.6-2.4 5.9-5.6 5.9A5.4 5.4 0 0 1 5.5 14c0-3.2 2.4-5.5 5.6-5.4.3 0 .7.1 1 .2v2.7c-.3-.1-.7-.2-1-.2-1.6 0-2.9 1.2-2.9 2.8 0 1.6 1.3 2.8 2.9 2.8 1.7 0 2.9-1.2 2.9-3V3h2.6z"})})})]}),zt=t("button",{class:"lang-toggle",onClick:Oe,"aria-label":"Switch language",children:e==="en"?"\u0627\u0631\u062F\u0648":"English"}),jt=t("button",{class:"theme-toggle",onClick:Wa,"aria-label":"Toggle light or dark theme",children:pe==="dark"?t("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[t("circle",{cx:"12",cy:"12",r:"4"}),t("path",{d:"M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"})]}):t("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:t("path",{d:"M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"})})}),Qa=[{id:"bio",label:v.bio},{id:"achievements",label:v.ach},{id:"quote",label:ot[e].qotd},{id:"music",label:e==="en"?"04 \u2014 Music":"\u06F0\u06F4 \u2014 \u0645\u0648\u0633\u06CC\u0642\u06CC"},{id:"gallery",label:v.gallery},{id:"guestbook",label:v.gb},{id:"quiz",label:v.quiz||"07 \u2014 Quiz"},{id:"qa",label:v.qa||"08 \u2014 Q&A"},{id:"contact",label:v.contact}],Ja=s=>{if(ue(!1),s==="gallery"){Fe("photos");return}n("home"),setTimeout(()=>document.getElementById(s)?.scrollIntoView({behavior:"smooth"}),60)},Lt=nt.filter(s=>s.family.toLowerCase().includes(Ct.trim().toLowerCase())),Ka=t(R,{children:[t("button",{class:"nav-toggle font-toggle"+(Re?" open":""),onClick:()=>me(s=>!s),"aria-label":"Change font",children:t("span",{style:{fontFamily:'"Georgia", serif',fontSize:15,letterSpacing:"0.02em"},children:"Aa"})}),Re&&t("div",{class:"font-panel",role:"dialog","aria-label":"Font picker",children:[t("div",{class:"font-panel-head",children:[t("span",{class:"nav-title",children:e==="en"?"Font style":"\u0641\u0648\u0646\u0679"}),t("button",{class:"nav-close","aria-label":"Close font picker",onClick:()=>{me(!1),Be("")},children:t("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round","aria-hidden":"true",children:t("path",{d:"M6 6l12 12M18 6L6 18"})})})]}),t("input",{class:"font-search",type:"text",inputmode:"text",placeholder:e==="en"?"Search font\u2026":"\u0641\u0648\u0646\u0679 \u062A\u0644\u0627\u0634 \u06A9\u0631\u06CC\u06BA\u2026",value:Ct,onInput:s=>Be(s.target.value)}),t("div",{class:"font-list",children:[Lt.map(s=>t("button",{class:"font-row-item"+(he===s.id?" active":""),onClick:()=>{Ua(s.id),me(!1),Be("")},children:[t("span",{class:"font-row-preview",style:{fontFamily:s.stack},children:s.family}),he===s.id&&t("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2.4",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:t("path",{d:"M20 6L9 17l-5-5"})})]},s.id)),Lt.length===0&&t("div",{class:"font-empty",children:e==="en"?"No font found":"\u06A9\u0648\u0626\u06CC \u0641\u0648\u0646\u0679 \u0646\u06C1\u06CC\u06BA \u0645\u0644\u0627"})]}),t("div",{class:"nav-foot",children:t("span",{class:"nav-foot-label",children:"SAQIB IQBAL"})})]})]}),Xa=t(R,{children:[t("button",{class:"nav-toggle",onClick:()=>ue(s=>!s),"aria-label":"Open menu",children:t("svg",{viewBox:"0 0 24 24",width:"18",height:"18",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round","aria-hidden":"true",children:t("path",{d:"M4 7h16M4 12h16M4 17h16"})})}),(St||Re)&&t("button",{class:"nav-backdrop","aria-label":"Close menu",onClick:()=>{ue(!1),me(!1)}}),St&&t("div",{class:"nav-menu",role:"menu",children:[t("div",{class:"nav-head",children:[t("span",{class:"nav-title",children:e==="en"?"Menu":"\u0645\u06CC\u0646\u06CC\u0648"}),t("button",{class:"nav-close","aria-label":"Close menu",onClick:()=>ue(!1),children:t("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round","aria-hidden":"true",children:t("path",{d:"M6 6l12 12M18 6L6 18"})})})]}),t("div",{class:"nav-items",children:Qa.map((s,m)=>{let k=s.label.split(" \u2014 "),C=k.length>1?k[0]:"",u=k.length>1?k.slice(1).join(" \u2014 "):s.label;return t("button",{class:"nav-item",role:"menuitem",style:{"--i":m},onClick:()=>Ja(s.id),children:[C&&t("span",{class:"nav-num",children:C}),t("span",{class:"nav-txt",children:u})]},s.id)})}),t("div",{class:"nav-foot",children:t("span",{class:"nav-foot-label",children:"SAQIB IQBAL"})})]})]}),It=t(R,{children:[t(va,{}),t(_a,{})]}),Za=!0,Et=!0;if(!Et&&yt==="ask")return t("div",{class:"gate consent",dir:J?"rtl":"ltr",children:[t("div",{class:"gate-glow","aria-hidden":"true"}),t("div",{class:"gate-wrap",children:t("div",{class:"gate-card",children:[t("div",{class:"gate-emblem","aria-hidden":"true",children:"\u{1F512}"}),t("span",{class:"gate-kicker",children:e==="en"?"PERMISSION":"\u0627\u062C\u0627\u0632\u062A"}),t("h1",{class:"gate-title",style:{fontSize:"clamp(22px, 6vw, 28px)"},children:e==="en"?"Storage access":"\u0627\u0633\u0679\u0648\u0631\u06CC\u062C \u06A9\u06CC \u0627\u062C\u0627\u0632\u062A"}),t("p",{class:"gate-sub",children:e==="en"?"This website saves your login, favourites and settings in your browser. Allow it?":"\u06CC\u06C1 \u0648\u06CC\u0628 \u0633\u0627\u0626\u0679 \u0622\u067E \u06A9\u0627 \u0644\u0627\u06AF \u0627\u0646\u060C \u067E\u0633\u0646\u062F\u06CC\u062F\u06C1 \u0627\u0648\u0631 \u0633\u06CC\u0679\u0646\u06AF\u0632 \u0622\u067E \u06A9\u06D2 \u0628\u0631\u0627\u0624\u0632\u0631 \u0645\u06CC\u06BA \u0645\u062D\u0641\u0648\u0638 \u06A9\u0631\u062A\u06CC \u06C1\u06D2\u06D4 \u0627\u062C\u0627\u0632\u062A \u062F\u06CC\u06BA\u061F"}),t("div",{style:{display:"grid",gap:10,marginTop:6},children:[t("button",{class:"gate-cta",onClick:Ra,children:e==="en"?"Allow \u2014 remember me":"\u0627\u062C\u0627\u0632\u062A \u062F\u06CC\u06BA \u2014 \u06CC\u0627\u062F \u0631\u06A9\u06BE\u06CC\u06BA"}),t("button",{class:"gate-social-btn",style:{minHeight:46},onClick:Ba,children:e==="en"?"Deny \u2014 website still works":"\u0627\u062C\u0627\u0632\u062A \u0646\u06C1\u06CC\u06BA \u2014 \u0648\u06CC\u0628 \u0633\u0627\u0626\u0679 \u067E\u06BE\u0631 \u0628\u06BE\u06CC \u0686\u0644\u06D2 \u06AF\u06CC"})]}),e==="en"?t("p",{class:"gb-note",children:"If you deny, login and favourites reset on every visit \u2014 your choice, both are safe."}):t("p",{class:"gb-note",children:"\u0627\u06AF\u0631 \u0627\u062C\u0627\u0632\u062A \u0646\u06C1 \u062F\u06CC\u06BA \u062A\u0648 \u0644\u0627\u06AF \u0627\u0646 \u0627\u0648\u0631 \u067E\u0633\u0646\u062F\u06CC\u062F\u06C1 \u06C1\u0631 \u0648\u0632\u0679 \u067E\u0631 \u0631\u06CC \u0633\u06CC\u0679 \u06C1\u0648\u06BA \u06AF\u06D2 \u2014 \u0622\u067E \u06A9\u06CC \u0645\u0631\u0636\u06CC\u060C \u062F\u0648\u0646\u0648\u06BA \u0645\u062D\u0641\u0648\u0638 \u06C1\u06CC\u06BA\u06D4"})]})})]});if(!Et&&!Aa)return t(xa,{lang:e,rtl:J,onSwitchLang:Oe,storageAllowed:yt==="ok",onDone:()=>{j.setItem("portfolio-perms-setup","done"),qa(!0)}});if(!Na)return t("div",{class:"gate",dir:J?"rtl":"ltr",children:t("div",{class:"gate-card",children:[t("span",{class:"gate-kicker",children:"SAQIB IQBAL"}),t("p",{class:"gate-sub",children:e==="en"?"Loading...":"\u0644\u0648\u0688 \u06C1\u0648 \u0631\u06C1\u0627 \u06C1\u06D2..."})]})});if(o==="gallery"){let s=y!==null&&y<D.length?y:null,m=s!==null?D[s]:null,k=m?t("div",{class:"lb-bar",onClick:u=>u.stopPropagation(),children:[t("span",{class:"lb-cat",children:v.cats[ee.indexOf(m.cat)]}),t("div",{class:"lb-reacts",children:[["love","\u2764\uFE0F"],["fire","\u{1F525}"],["wow","\u{1F929}"]].map(([u,W])=>t("button",{class:"lb-react"+(M[m.src]===u?" active":""),onClick:()=>f(m.src,u),"aria-label":"React "+u,children:[t("span",{class:"lb-react-emoji",children:W}),t("span",{children:T[m.src]?.[u]??0})]},u))}),t("div",{class:"lb-tools",children:[t("button",{class:"lb-tool lb-fav"+(B[m.src]?" active":""),"aria-label":"Favourite",onClick:()=>q(m.src),children:t("svg",{viewBox:"0 0 24 24",width:"17",height:"17","aria-hidden":"true",children:t("path",{d:"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",fill:"currentColor",stroke:"none"})})}),t("button",{class:"lb-tool"+(V?" active":""),"aria-label":"Brighten photo",onClick:()=>ae(u=>!u),children:t("svg",{viewBox:"0 0 24 24",width:"17",height:"17",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round","aria-hidden":"true",children:[t("circle",{cx:"12",cy:"12",r:"4"}),t("path",{d:"M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"})]})}),t("button",{class:"lb-tool","aria-label":"Random photo",onClick:()=>{let u=s??0;if(D.length>1)do u=Math.floor(Math.random()*D.length);while(u===s);L(1),A({x:0,y:0}),_(u)},children:t("svg",{viewBox:"0 0 24 24",width:"17",height:"17",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[t("path",{d:"M16 3h5v5"}),t("path",{d:"M4 20L21 3"}),t("path",{d:"M21 16v5h-5"}),t("path",{d:"M15 15l6 6"}),t("path",{d:"M4 4l5 5"})]})}),t("button",{class:"lb-tool","aria-label":"Share photo",onClick:()=>Pa(m.src),children:t("svg",{viewBox:"0 0 24 24",width:"17",height:"17",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[t("circle",{cx:"18",cy:"5",r:"3"}),t("circle",{cx:"6",cy:"12",r:"3"}),t("circle",{cx:"18",cy:"19",r:"3"}),t("path",{d:"M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"})]})}),t("a",{class:"lb-tool",href:h[m.src],download:m.src.split("/").pop()||"photo.jpg","aria-label":"Download photo",children:t("svg",{viewBox:"0 0 24 24",width:"17",height:"17",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[t("path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"}),t("path",{d:"M7 10l5 5 5-5"}),t("path",{d:"M12 15V3"})]})}),t("button",{class:"lb-tool"+(de?" active":""),"aria-label":"Slideshow",onClick:()=>lt(u=>!u),children:de?t("svg",{viewBox:"0 0 24 24",width:"17",height:"17",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round","aria-hidden":"true",children:t("path",{d:"M10 5v14M16 5v14"})}):t("svg",{viewBox:"0 0 24 24",width:"17",height:"17",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:t("path",{d:"M7 4l13 8-13 8V4z"})})}),t("button",{class:"lb-tool"+(ct?" active":""),"aria-label":"Photo info",onClick:()=>dt(u=>!u),children:t("svg",{viewBox:"0 0 24 24",width:"17",height:"17",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round","aria-hidden":"true",children:[t("circle",{cx:"12",cy:"12",r:"9"}),t("path",{d:"M12 8h.01"}),t("path",{d:"M12 12v4"})]})})]}),ct&&t("div",{class:"lb-info",children:[m.src.split("/").pop()," \xB7 ",v.cats[ee.indexOf(m.cat)],Ie?` \xB7 ${Ie.w}\xD7${Ie.h}`:""]}),t("span",{class:"nav-foot-label",children:[s+1," / ",D.length]})]}):null,C=m?t("div",{class:"lightbox",role:"dialog","aria-label":"Photo viewer",onClick:()=>{_(null),L(1),A({x:0,y:0})},onTouchStart:La,onTouchMove:Ia,onTouchEnd:Ea,onDblClick:u=>{u.stopPropagation(),M[m.src]!=="love"&&f(m.src,"love"),it(W=>W+1)},children:[t("button",{class:"lb-zoombtn lb-zoomin","aria-label":"Zoom in",onClick:u=>{u.stopPropagation(),Le(z*1.5)},children:t("svg",{viewBox:"0 0 24 24",width:"18",height:"18",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round","aria-hidden":"true",children:t("path",{d:"M12 5v14M5 12h14"})})}),t("button",{class:"lb-zoombtn lb-zoomout","aria-label":"Zoom out",onClick:u=>{u.stopPropagation(),Le(z/1.5)},children:t("svg",{viewBox:"0 0 24 24",width:"18",height:"18",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round","aria-hidden":"true",children:t("path",{d:"M5 12h14"})})}),t("button",{class:"lb-close","aria-label":"Close",onClick:()=>{_(null),L(1),A({x:0,y:0})},children:t("svg",{viewBox:"0 0 24 24",width:"18",height:"18",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round","aria-hidden":"true",children:t("path",{d:"M6 6l12 12M18 6L6 18"})})}),D.length>1&&t(R,{children:[t("button",{class:"lb-arrow lb-prev","aria-label":"Previous photo",onClick:u=>{u.stopPropagation(),_((s-1+D.length)%D.length)},children:t("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:t("path",{d:"M15 18l-6-6 6-6"})})}),t("button",{class:"lb-arrow lb-next","aria-label":"Next photo",onClick:u=>{u.stopPropagation(),_((s+1)%D.length)},children:t("svg",{viewBox:"0 0 24 24",width:"20",height:"20",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:t("path",{d:"M9 6l6 6-6 6"})})})]}),r==="videos"?h[m.src]?t("video",{class:"lb-vid"+(V?" bright":""),src:h[m.src],controls:!0,playsInline:!0,onLoadedMetadata:u=>pt({w:u.currentTarget.videoWidth,h:u.currentTarget.videoHeight}),onClick:u=>u.stopPropagation()}):null:h[m.src]?t("img",{class:"lb-img"+(z>1.01?" zoomed":"")+(V?" bright":""),style:{transform:`translate(${N.x}px, ${N.y}px) scale(${z})`},src:h[m.src],alt:"",draggable:!1,onLoad:u=>pt({w:u.currentTarget.naturalWidth,h:u.currentTarget.naturalHeight}),onClick:u=>u.stopPropagation()}):null,rt>0&&t("div",{class:"heart-burst","aria-hidden":"true",children:t("span",{children:"\u2764\uFE0F"})},rt),k]}):null;return t("div",{class:"page",dir:J?"rtl":"ltr",lang:e,children:[It,t("div",{class:"page-inner",children:[t("div",{class:"gal-topbar",children:[t("button",{class:"btn btn-ghost btn-back",onClick:()=>n("home"),children:v.home}),t("span",{class:"mono-label",children:v.galTop})]}),zt,jt,t("div",{class:"seg",role:"tablist","aria-label":"Media type",children:["photos","videos"].map(u=>t("button",{role:"tab","aria-selected":r===u,class:`seg-btn ${r===u?"active":""}`,onClick:()=>{i(u),d("all")},children:u==="photos"?v.myPics:v.myVids},u))}),t("div",{class:"chips",role:"group","aria-label":"Category filter",children:ee.map((u,W)=>{let He=u==="all"?(r==="photos"?te:ce).length:u==="favs"?te.filter(Ue=>B[Ue.src]).length:(r==="photos"?te:ce).filter(Ue=>Ue.cat===u).length;return t("button",{class:`chip ${c===u?"active":""}`,onClick:()=>d(u),children:[v.cats[W],t("span",{class:"chip-count",children:He})]},u)})}),D.length===0?t("div",{class:"v-empty-state",children:v.empty}):t("div",{class:`gallery ${r==="videos"?"videos":""}`,children:D.map((u,W)=>t("figure",{class:`tile ${r==="videos"?"tile-wide":""}`,style:{"--i":W},role:"button",tabIndex:0,onClick:()=>st(W),onKeyDown:He=>{He.key==="Enter"&&st(W)},"aria-label":`${v.cats[ee.indexOf(u.cat)]} \u2014 ${r==="photos"?v.photo:v.video} ${u.id}`,children:t("span",{class:`tile-inner ${r==="photos"?"tile-photo":"tile-video"}`,children:[B[u.src]&&t("span",{class:"tile-fav","aria-hidden":"true",children:"\u2B50"}),h[u.src]?r==="photos"?t("img",{class:"tile-img",src:h[u.src],loading:"lazy",alt:`${v.cats[ee.indexOf(u.cat)]} \u2014 ${v.photo} ${u.id}`}):t("video",{class:"tile-img",src:h[u.src],preload:"metadata",muted:!0,playsInline:!0}):t(R,{children:[r==="videos"&&t("svg",{viewBox:"0 0 24 24",width:"28",height:"28",fill:"none",stroke:"currentColor","stroke-width":"1.5","aria-hidden":"true",children:[t("circle",{cx:"12",cy:"12",r:"9"}),t("path",{d:"M10 9l5 3-5 3V9z",fill:"currentColor",stroke:"none"})]}),v.cats[ee.indexOf(u.cat)]," \xB7 ",u.id]})]})},u.id))}),D.length===0&&t("p",{class:"gal-empty",children:r==="videos"?v.galEmptyVideos:v.galEmptyPhotos}),t("p",{class:"footer-note",children:v.galNote})]}),C]})}return t("div",{class:"page",dir:J?"rtl":"ltr",lang:e,children:[It,zt,jt,Xa,Ka,Za&&!U&&t("div",{class:"gate-overlay",children:[t("style",{children:".page > :not(.gate-overlay){visibility:hidden!important}"}),t(ya,{lang:e,rtl:J,onSwitchLang:Oe,onAuth:ne})]}),t("header",{class:"hero",children:[t("div",{class:"hero-top animate-1",children:[t("span",{class:"mono-label",children:"VIP Portfolio \xB7 2026"}),Ya]}),t("p",{class:"hero-kicker animate-2",children:v.kicker}),t("h1",{class:"hero-name",children:[t("span",{class:"animate-2",children:"Saqib"}),t("span",{class:"animate-3 accent",children:"Iqbal"})]}),t("p",{class:"hero-sub animate-4",children:v.heroSub}),t("div",{class:"hero-actions animate-5",children:[t("button",{class:"btn btn-primary",onClick:()=>{ht(!0),document.getElementById("contact")?.scrollIntoView({behavior:"smooth"})},children:v.contactBtn}),t("a",{class:"btn btn-ghost",href:"#achievements",children:v.achievementsBtn})]})]}),t("section",{class:"section",id:"bio","aria-label":"Bio",children:[t("div",{class:"section-header",children:t("span",{class:"mono-label",children:v.bio})}),t("div",{class:"me-lines",children:v.meLines.map((s,m)=>t("p",{children:s},m))}),t("div",{class:"facts",children:v.factK.map((s,m)=>t("div",{class:"fact",children:[t("span",{class:"fact-k",children:s}),t("span",{class:"fact-v",children:v.factV[m]})]},s))}),t("p",{class:"bio-quote",children:v.quote})]}),t("section",{class:"section",id:"achievements","aria-label":"Achievements",children:[t("div",{class:"section-header",children:t("span",{class:"mono-label",children:v.ach})}),t("div",{class:"stats",children:[t(Te,{value:17,suffix:"",label:v.statLabels[0]}),t(Te,{value:90,suffix:"%",label:v.statLabels[1]}),t(Te,{value:1080,suffix:"/1200",label:v.statLabels[2]}),t(Te,{value:483,suffix:"/545",label:v.statLabels[3]})]}),t("div",{class:"tag-group",children:v.tags.map(s=>t("span",{class:"tag",children:s},s))})]}),t("section",{class:"section",id:"quote","aria-label":"Quote of the day",children:[t("div",{class:"section-header",children:t("span",{class:"mono-label",children:ot[e].qotd})}),t("figure",{class:"qotd",children:[t("span",{class:"qotd-cat",children:ot[e][Ma.c]}),t("blockquote",{children:Ma.t}),t("figcaption",{children:"\u2014 Saqib"})]}),t("p",{class:"stat-note",children:e==="en"?`A new quote every day \u2014 ${Me.length} quotes in rotation.`:`Har roz nayi quote \u2014 ${Me.length} quotes ka chakkar.`})]}),t("section",{class:"section",id:"music","aria-label":"Music player",children:[t("div",{class:"section-header",children:t("span",{class:"mono-label",children:e==="en"?"04 \u2014 Music":"\u06F0\u06F4 \u2014 \u0645\u0648\u0633\u06CC\u0642\u06CC"})}),t(Sa,{})]}),t("section",{class:"section",id:"gallery","aria-label":"Gallery",children:[t("div",{class:"section-header",children:t("span",{class:"mono-label",children:v.gallery})}),t("p",{class:"contact-sub",children:v.memories}),t("div",{class:"gal-cards",children:[t("button",{class:"gal-card",onClick:()=>Fe("photos"),children:[t("span",{class:"gal-card-title",children:v.myPics}),t("span",{class:"gal-card-sub",children:v.picsSub})]}),t("button",{class:"gal-card",onClick:()=>Fe("videos"),children:[t("span",{class:"gal-card-title",children:v.myVids}),t("span",{class:"gal-card-sub",children:v.vidsSub})]})]})]}),t("section",{class:"section",id:"guestbook","aria-label":"Guestbook",children:[t("div",{class:"section-header",children:t("span",{class:"mono-label",children:v.gb})}),t("p",{class:"contact-sub",children:v.gbSub}),t("form",{class:"gb-form",onSubmit:Ga,children:[t("input",{class:"gb-input",value:Pe,onChange:s=>ft(s.target.value),placeholder:v.gbName,maxLength:40,required:!0}),t("textarea",{class:"gb-input gb-textarea",value:Ne,onChange:s=>gt(s.target.value),placeholder:v.gbMsg,maxLength:300,rows:3,required:!0}),t("button",{class:"btn btn-primary",type:"submit",disabled:Ae,children:Ae?v.gbSending:v.gbSend}),vt&&t("p",{class:"gb-note",children:vt})]}),Ee===null?t("p",{class:"stat-note",children:"..."}):Ee.length===0?t("div",{class:"v-empty-state",children:v.gbEmpty}):t("div",{class:"gb-list",children:[...Ee].reverse().slice(0,30).map(s=>t("div",{class:"gb-item",children:[t("div",{class:"gb-head",children:[t("strong",{children:s.name}),t("span",{class:"mono-label",children:new Date(s.createdAt).toLocaleDateString()})]}),t("p",{children:s.message})]},s.id))})]}),t("footer",{class:"section contact",id:"contact","aria-label":"Contact details",children:[t("div",{class:"section-header",children:t("span",{class:"mono-label",children:v.contact})}),t("h2",{class:"contact-title",children:v.letsConnect}),t("p",{class:"contact-sub",children:v.contactSub}),t("button",{class:"btn btn-primary",onClick:()=>ht(s=>!s),children:ut?v.hideContact:v.contactBtn}),ut&&t("div",{class:"reveal",children:[t("div",{class:"contact-details"+(U?"":" cd-lock"),"aria-hidden":U?void 0:!0,children:[t("a",{class:"contact-row",href:"https://wa.me/923134182952",target:"_blank",rel:"noopener",children:[t("span",{class:"mono-label",children:"WhatsApp"}),t("span",{class:"contact-value wa-value",children:[t("svg",{viewBox:"0 0 24 24",width:"18",height:"18",fill:"#2fb967","aria-hidden":"true",children:t("path",{d:"M12 2a10 10 0 0 0-8.5 15.3L2 22l4.8-1.4A10 10 0 1 0 12 2zm0 18.2c-1.6 0-3.1-.4-4.4-1.2l-.3-.2-2.9.8.8-2.8-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.6-6.1c-.3-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1-.2.3-.6.8-.8 1-.1.2-.3.2-.5.1-.3-.1-1.1-.4-2.1-1.3-.8-.7-1.3-1.6-1.5-1.8-.1-.3 0-.4.1-.5l.4-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5 0-.1-.6-1.4-.8-1.9-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.2s.9 2.5 1.1 2.7c.1.2 1.8 2.8 4.4 3.9.6.3 1.1.4 1.5.6.6.2 1.2.2 1.6.1.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.6-.3z"})}),Ha]})]}),t("a",{class:"contact-row",href:`mailto:${De}`,children:[t("span",{class:"mono-label",children:v.emailLabel}),t("span",{class:"contact-value",children:De})]})]}),!U&&t("p",{class:"cd-hint",children:e==="en"?"Sign up to unlock WhatsApp number, email and quick actions.":"\u0648\u0627\u0679\u0633 \u0627\u06CC\u067E \u0646\u0645\u0628\u0631\u060C \u0627\u06CC \u0645\u06CC\u0644 \u0627\u0648\u0631 \u0628\u0679\u0646 \u062F\u06CC\u06A9\u06BE\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2 \u0633\u0627\u0626\u0646 \u0627\u067E \u06A9\u0631\u06CC\u06BA\u06D4"}),t("div",{class:"hero-actions",children:[t("a",{class:"btn btn-whatsapp"+(U?"":" cd-lock"),href:"https://wa.me/923134182952",target:"_blank",rel:"noopener","aria-hidden":U?void 0:!0,tabindex:U?void 0:-1,children:"WhatsApp"}),t("button",{class:"btn btn-ghost"+(U?"":" cd-lock"),onClick:Va,"aria-hidden":U?void 0:!0,tabindex:U?void 0:-1,children:g?v.copied:v.copyEmail}),t("button",{class:"btn btn-ghost",onClick:Tt,children:[v.share," \u2934"]})]})]}),kt!==null&&t("p",{class:"visitor-line",children:[t("svg",{viewBox:"0 0 24 24",width:"14",height:"14",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[t("path",{d:"M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"}),t("circle",{cx:"12",cy:"12",r:"3"})]}),t("span",{class:"mono-label",children:v.visitors}),t("span",{class:"visitor-num",children:kt})]}),U&&t("div",{class:"logout-row",children:t("button",{class:"gb-switch",onClick:Da,children:[v.authWelcome,", ",U.name," \xB7 ",v.authLogout]})}),t("p",{class:"footer-note",children:["\xA9 ",new Date().getFullYear()," Saqib Iqbal \xB7 ",v.crafted]})]})]})}var ze=class extends H{state={err:null};static getDerivedStateFromError(a){return{err:a}}componentDidCatch(a,o){console.error("Boundary:",a.message,o.componentStack?.slice(0,300))}render(){return this.state.err?t("div",{style:{minHeight:"100dvh",display:"grid",placeItems:"center",padding:"24px",background:"#0b0709"},children:t("div",{style:{maxWidth:460,display:"grid",gap:10,padding:"24px 20px",borderRadius:16,border:"1px solid rgba(233,123,156,.45)",color:"#f2d9e1",fontSize:14},children:[t("strong",{style:{color:"#d9a94e"},children:"Something broke \u2014 tell Saqiii this line:"}),t("code",{style:{wordBreak:"break-word",color:"#e97b9c"},children:this.state.err.message}),t("button",{style:{minHeight:44,borderRadius:10,border:"none",font:"inherit",fontWeight:600,cursor:"pointer",background:"linear-gradient(100deg,#e97b9c,#d9a94e)",color:"#fff"},onClick:()=>{this.setState({err:null});try{localStorage.clear()}catch{}location.reload()},children:"Reset & reload"})]})}):this.props.children}};function ja(e){let a=document.getElementById("crash-report");a||(a=document.createElement("div"),a.id="crash-report",a.style.cssText="position:fixed;inset:auto 12px 12px 12px;z-index:99999;background:#2a0d14;border:1px solid #e97b9c;border-radius:12px;padding:12px;color:#f2d9e1;font:13px/1.4 monospace;max-height:40dvh;overflow:auto",document.body.appendChild(a)),a.textContent="ERROR \u2192 "+e}window.addEventListener("error",e=>ja(e.message));window.addEventListener("unhandledrejection",e=>ja(String(e.reason).slice(0,200)));Ke(t(ze,{children:t(za,{})}),document.getElementById("app"));

;(function(){
if(document.getElementById("sq-chat-btn"))return;
function $(id){return document.getElementById(id)}
var st=document.createElement("style");st.textContent="#sq-chat-btn{position:fixed;bottom:18px;right:18px;z-index:11001;width:54px;height:54px;border-radius:50%;border:none;cursor:pointer;font-size:24px;background:linear-gradient(135deg,#e97b9c,#d9a94e);color:#fff;box-shadow:0 8px 24px #e97b9c66;transition:transform .2s}#sq-chat-btn:active{transform:scale(.92)}#sq-chat-panel{position:fixed;bottom:18px;right:18px;z-index:11002;width:min(92vw,340px);height:min(70vh,460px);display:none;flex-direction:column;border-radius:18px;overflow:hidden;border:1px solid rgba(233,123,156,.35);background:#0a0a0ee8;backdrop-filter:blur(10px);box-shadow:0 20px 60px #000c;font-family:inherit}#sq-chat-head{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:linear-gradient(100deg,#e97b9c22,#d9a94e18);color:#f2d9e1;font-size:13px;font-weight:600;letter-spacing:.04em}#sq-chat-x{border:none;background:transparent;color:#f2d9e1;font-size:18px;cursor:pointer;padding:2px 8px}#sq-chat-log{flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px}#sq-chat-log:empty::after{content:\"Saqib AI — ask me anything / aap sawal karein\";color:#ffffff66;font-size:12px;text-align:center;margin:auto}.sq-msg{max-width:85%;padding:8px 12px;border-radius:14px;font-size:13px;line-height:1.45;white-space:pre-wrap;word-break:break-word}.sq-msg.user{align-self:flex-end;background:linear-gradient(100deg,#e97b9c,#d9a94e);color:#fff;border-bottom-right-radius:4px}.sq-msg.ai{align-self:flex-start;background:#ffffff12;color:#eee;border-bottom-left-radius:4px}.sq-msg.err{align-self:center;background:#ff3b3b26;color:#ffb3b3;font-size:11px;border-radius:10px}#sq-chat-bar{display:flex;gap:8px;padding:10px;border-top:1px solid #ffffff18}#sq-chat-in{flex:1;border:1px solid rgba(233,123,156,.35);background:#ffffff0a;border-radius:12px;padding:9px 12px;color:#fff;font:inherit;font-size:13px;outline:none}#sq-chat-in:focus{border-color:#e97b9c}#sq-chat-send{border:none;border-radius:12px;width:42px;background:linear-gradient(100deg,#e97b9c,#d9a94e);color:#fff;font-size:16px;cursor:pointer}";document.head.appendChild(st);
var btn=document.createElement("button");btn.id="sq-chat-btn";btn.type="button";btn.setAttribute("aria-label","Chat with Saqib AI");btn.textContent="\uD83D\uDCAC";
var panel=document.createElement("div");panel.id="sq-chat-panel";
panel.innerHTML='<div id="sq-chat-head"><span>Saqib AI \u2022 online</span><button id="sq-chat-x" type="button">\u00D7</button></div><div id="sq-chat-log"></div><div id="sq-chat-bar"><input id="sq-chat-in" placeholder="Message / \u067E\u06CC\u063A\u0627\u0645..." autocomplete="off" maxlength="500"><button id="sq-chat-send" type="button">\u27A4</button></div>';
function mount(){document.body.appendChild(btn);document.body.appendChild(panel)}
if(document.body)mount();else document.addEventListener("DOMContentLoaded",mount);
var bound=false;
function bind(){
  if(bound)return;
  var log=$("sq-chat-log"),inp=$("sq-chat-in"),send=$("sq-chat-send");
  if(!log||!inp||!send){setTimeout(bind,300);return}
  bound=true;
  var hist=[];
  try{
    hist=JSON.parse(localStorage.getItem("sq-chat-hist")||"[]");
    if(hist.length)hist.forEach(function(h){addMsg(h.role==="ai"?"ai":"user",h.text)});
  }catch(e){hist=[]}
  function save(){try{localStorage.setItem("sq-chat-hist",JSON.stringify(hist.slice(-30)))}catch(e){}}
  function doSend(){
    var t=inp.value.trim();
    if(!t)return;
    inp.value="";
    addMsg("user",t);hist.push({role:"user",text:t});save();
    var th=addMsg("ai","\u2026");
    var tm=null;
    var done=false;
    function fail(w){if(done)return;done=true;clearTimeout(tm);if(th&&th.remove)th.remove();addMsg("err","Message send nahi hua \u2014 dobara try karein. ("+w+")");log.scrollTop=log.scrollHeight}
    setTimeout(function(){if(!done)fail("timeout 35s")},35000);
    var opts={method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:t,history:hist.slice(-7,-1)})};
    var F=(window.vellum&&window.vellum.fetch)?window.vellum.fetch.bind(window.vellum):fetch.bind(window);
    F("/v1/x/chat",opts).then(function(r){if(done)return null;return r.ok?r.json():Promise.reject(new Error("http "+r.status))})
    .then(function(d){if(done)return;done=true;clearTimeout(tm);th.textContent=(d&&d.reply)||"\u2026";hist.push({role:"ai",text:(d&&d.reply)||""});save();log.scrollTop=log.scrollHeight})
    .catch(function(e){if(!done)fail(e&&e.message?e.message:"network")});
  }
  send.addEventListener("click",function(e){e.preventDefault();doSend()});
  inp.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();doSend()}});
}
btn.addEventListener("click",function(){panel.style.display="flex";btn.style.display="none";bind();var i=$("sq-chat-in");if(i)i.focus()});
$("sq-chat-x").addEventListener("click",function(){panel.style.display="none";btn.style.display=""});
bind();
function addMsg(cls,txt){var log=$("sq-chat-log");if(!log)return null;var m=document.createElement("div");m.className="sq-msg "+cls;m.textContent=txt;log.appendChild(m);log.scrollTop=log.scrollHeight;return m}
})();

;(function(){
if(document.getElementById("sq-refresh-btn"))return;
var CSS='#sq-refresh-btn{position:fixed;left:14px;bottom:20px;z-index:11003;width:46px;height:46px;border-radius:50%;border:1px solid #f0c96a;background:rgba(18,8,28,.88);color:#f0c96a;font-size:21px;line-height:1;box-shadow:0 4px 16px rgba(0,0,0,.5);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .25s,box-shadow .25s;-webkit-backdrop-filter:blur(5px);backdrop-filter:blur(5px);-webkit-tap-highlight-color:transparent}#sq-refresh-btn:active{transform:scale(.88)}#sq-refresh-btn.sq-rf-busy{animation:sq-rf-spin .55s linear infinite;pointer-events:none}@keyframes sq-rf-spin{to{transform:rotate(360deg)}}body.sq-cool-out{opacity:0;transform:scale(.965) translateY(-8px);transition:opacity .5s ease,transform .5s ease;pointer-events:none}html.sq-cool-enter body{animation:sq-cool-in .9s ease both}@keyframes sq-cool-in{from{opacity:0;transform:translateY(16px) scale(.99)}to{opacity:1;transform:none}}';
var st=document.createElement("style");st.id="sq-refresh-style";st.textContent=CSS;document.head.appendChild(st);
var b=document.createElement("button");b.id="sq-refresh-btn";b.title="Refresh";b.innerHTML="\u27F3";
b.addEventListener("click",function(){
  if(b.classList.contains("sq-rf-busy"))return;
  b.classList.add("sq-rf-busy");
  try{sessionStorage.setItem("sq-cool-enter","1")}catch(e){}
  document.body.classList.add("sq-cool-out");
  setTimeout(function(){location.reload()},560);
});
function mount(){if(!document.body){setTimeout(mount,300);return}document.body.appendChild(b)}
if(document.body)mount();else document.addEventListener("DOMContentLoaded",mount);
try{
  if(sessionStorage.getItem("sq-cool-enter")){
    sessionStorage.removeItem("sq-cool-enter");
    document.documentElement.classList.add("sq-cool-enter");
    setTimeout(function(){document.documentElement.classList.remove("sq-cool-enter")},1500);
  }
}catch(e){}
})();

;(function(){
if(document.getElementById("sq-forgot-style"))return;
var CSS='#sq-forgot-link{background:none;border:none;color:#f0c96a;font-size:11.5px;cursor:pointer;padding:4px 0 0;margin:0 auto;display:block;text-decoration:underline;opacity:.85;font-family:inherit}#sq-forgot-ov{position:fixed;inset:0;z-index:11005;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}#sq-forgot-card{background:rgba(24,10,34,.97);border:1px solid #f0c96a;border-radius:14px;padding:22px 20px;width:min(88vw,320px);box-shadow:0 10px 40px rgba(0,0,0,.6);color:#fff;font-family:inherit}#sq-forgot-card h3{margin:0 0 4px;font-size:17px;color:#f0c96a}#sq-forgot-card p{margin:0 0 14px;font-size:12.5px;opacity:.75;line-height:1.5}#sq-forgot-card input{width:100%;box-sizing:border-box;padding:11px 12px;margin-bottom:10px;border-radius:9px;border:1px solid #ffffff33;background:#ffffff14;color:#fff;font-size:14px;outline:none;font-family:inherit}#sq-forgot-card input:focus{border-color:#f0c96a}#sq-forgot-card button{width:100%;padding:11px;border-radius:9px;border:none;cursor:pointer;font-size:14px;font-weight:600;font-family:inherit;margin-bottom:8px}.sq-fp-main{background:linear-gradient(135deg,#e91e8c,#f0c96a);color:#fff}.sq-fp-back{background:#ffffff1c;color:#fff}.sq-fp-msg{font-size:12.5px;min-height:16px;margin:-2px 0 8px;line-height:1.4}.sq-fp-msg.err{color:#ff6b81}.sq-fp-msg.ok{color:#7ddb8a}';
var st=document.createElement("style");st.id="sq-forgot-style";st.textContent=CSS;document.head.appendChild(st);
var F=function(u,o){o=o||{};return window.vellum&&window.vellum.fetch?window.vellum.fetch(u,o):fetch(u,o)};
function openPanel(){
  if(document.getElementById("sq-forgot-ov"))return;
  var ov=document.createElement("div");ov.id="sq-forgot-ov";
  ov.innerHTML='<div id="sq-forgot-card"><h3>Forgot password?<\/h3><p>Apna email aur naya password likho \u2014 foran reset ho jayega.<\/p><input id="sq-fp-email" type="email" placeholder="Email" autocomplete="email"><input id="sq-fp-pw" type="password" placeholder="New password (min 6)" > <input id="sq-fp-pw2" type="password" placeholder="Confirm new password"><div class="sq-fp-msg" id="sq-fp-msg"><\/div><button class="sq-fp-main" id="sq-fp-go">Reset password<\/button><button class="sq-fp-back" id="sq-fp-back">Back to login<\/button><\/div>';
  document.body.appendChild(ov);
  ov.querySelector("#sq-fp-back").addEventListener("click",function(){ov.remove()});
  ov.addEventListener("click",function(e){if(e.target===ov)ov.remove()});
  ov.querySelector("#sq-fp-go").addEventListener("click",function(){
    var email=ov.querySelector("#sq-fp-email").value.trim();
    var pw=ov.querySelector("#sq-fp-pw").value;
    var pw2=ov.querySelector("#sq-fp-pw2").value;
    var m=ov.querySelector("#sq-fp-msg");
    m.className="sq-fp-msg";
    if(!email||pw.length<6){m.className="sq-fp-msg err";m.textContent="Email likho aur password kam az kam 6 harf ka.";return}
    if(pw!==pw2){m.className="sq-fp-msg err";m.textContent="Dono passwords match nahi kar rahe.";return}
    var go=this;go.disabled=true;go.textContent="Resetting...";
    F("/v1/x/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"forgot",email:email,password:pw})}).then(function(r){
      if(r&&r.ok){ov.remove();var g=document.querySelector(".gate input[type=email]");if(g){var d=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value");d.set.call(g,email);g.dispatchEvent(new Event("input",{bubbles:true}))}alert("Password reset ho gaya \u2014 ab naye password se log in karo.");return}
      m.className="sq-fp-msg err";m.textContent=r&&r.status===404?"Account not found \u2014 pehle sign up karo.":"Reset nahi hua \u2014 dobara koshish karo.";
      go.disabled=false;go.textContent="Reset password";
    }).catch(function(){m.className="sq-fp-msg err";m.textContent="No connection \u2014 try again.";go.disabled=false;go.textContent="Reset password"});
  });
}
function scan(){
  var gate=document.querySelector(".gate");
  if(gate&&!gate.querySelector("#sq-forgot-link")){
    var l=document.createElement("button");l.type="button";l.id="sq-forgot-link";
    l.textContent="Forgot password? / \u067E\u0627\u0633 \u0648\u0631\u0688 \u0628\u06BE\u0648\u0644 \u06AF\u0626\u06D2\u061F";
    l.addEventListener("click",openPanel);
    var pw=gate.querySelector("input[type=password]");if(pw&&pw.parentNode){pw.parentNode.insertBefore(l,pw.nextSibling)}else{gate.appendChild(l)}
  }
}
var t=setInterval(scan,900);scan();
})();
;function gbSafeFetch(e,a){try{var v=window.vellum;return v&&typeof v.fetch=="function"?v.fetch(e,a):fetch(e,a)}catch(x){return fetch(e,a)}}
;(function(){
var OWNER="fizanali6267@gmail.com";
function myAuth(){var t="";try{t=localStorage.getItem("portfolio-auth-token")||""}catch(x){}var l=null;try{l=JSON.parse(localStorage.getItem("portfolio-auth-local")||"null")}catch(x){l=null}return{token:t,local:l}}
function myEmail(){try{return srvEmail||((myAuth().local||{}).email||"")}catch(x){return srvEmail||""}}
var srvEmail="";
function pullMe(){var a=myAuth();if(!a.token)return;if(!srvEmail)gbSafeFetch("/v1/x/guestbook",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"me",token:a.token})}).then(function(r){return r.ok?r.json():Promise.reject(0)}).then(function(j){if(j&&j.email){srvEmail=j.email;redecorate()}}).catch(function(){})}
var cache={data:[],at:0};
function findId(name,msg){return cache.data.find(function(e){return e.name===name&&e.message===msg})}
function refreshCache(){return gbSafeFetch("/v1/x/guestbook").then(function(r){return r.json()}).then(function(j){cache.data=j||[];cache.at=Date.now();return cache.data}).catch(function(){return cache.data})}
function barFor(entry){var me=myEmail();var own=(entry.email||"")===me&&me!=="";var isOwner=me===OWNER;
  var bar=document.createElement("div");bar.className="sq-gb-actions";bar.style.cssText="display:flex;gap:10px;margin-top:4px";
  function mk(t,act){var x=document.createElement("button");x.type="button";x.setAttribute("data-act",act);x.setAttribute("data-id",entry.id);x.textContent=t;x.style.cssText="background:none;border:none;color:#9a8f96;font:11.5px system-ui;padding:0;cursor:pointer";bar.appendChild(x)}
  if(myAuth().token)mk("Reply","reply");
  if(own)mk("Edit","edit");
  if(own||isOwner)mk("Delete","delete");
  return bar}
function row(entry,isReply){var d=document.createElement("div");d.className=isReply?"sq-gb-reply gb-item":"gb-item";if(isReply)d.style.cssText="margin:6px 0 0 14px;opacity:.92";
  var h=document.createElement("div");h.className="gb-head";
  var st=document.createElement("strong");st.textContent=entry.name+(entry.edited?" (edited)":"");
  var sp=document.createElement("span");sp.className="mono-label";var dt=new Date(entry.createdAt||Date.now());sp.textContent=(dt.getMonth()+1)+"/"+dt.getDate()+"/"+dt.getFullYear();
  h.appendChild(st);h.appendChild(sp);
  var pp=document.createElement("p");pp.textContent=entry.message;
  d.appendChild(h);d.appendChild(pp);
  if(!isReply)d.setAttribute("data-sq-decorated","1");
  d.appendChild(barFor(entry));
  var replies=document.createElement("div");replies.className="sq-replies";
  (entry.replies||[]).forEach(function(rp){replies.appendChild(row(rp,true))});
  d.appendChild(replies);
  return d}
function redecorate(){var its=document.querySelectorAll(".gb-item[data-sq-decorated]");
  for(var k=0;k<its.length;k++){var it=its[k];
    var e=cache.data.find(function(x){return x.id===it.getAttribute("data-sq-id")});if(!e)continue;
    var old=it.querySelector(".sq-gb-actions");if(old)old.remove();
    it.appendChild(barFor(e));
    var or=it.querySelector(".sq-replies");if(or)or.remove();
    var rp=document.createElement("div");rp.className="sq-replies";
    (e.replies||[]).forEach(function(x){rp.appendChild(row(x,true))});
    it.appendChild(rp);
  }}
function decorate(){var lists=document.querySelectorAll(".gb-list");
  for(var L=0;L<lists.length;L++){(function(list){
    if(list.__sqDecorating)return;list.__sqDecorating=true;
    refreshCache().then(function(data){cache.data=data;cache.at=Date.now();
      var items=list.querySelectorAll(".gb-item");
      for(var k=0;k<items.length;k++){var it=items[k];
        if(it.getAttribute("data-sq-decorated"))continue;
        if(it.closest(".sq-gb-actions")||it.closest(".sq-replies"))continue;
        it.setAttribute("data-sq-decorated","1");
        var nm=it.querySelector(".gb-head strong"),pp=it.querySelector("p");
        if(!nm||!pp)continue;
        var e=findId(nm.textContent,pp.textContent);
        if(!e)continue;
        it.setAttribute("data-sq-id",e.id);
        it.appendChild(barFor(e));
        var replies=document.createElement("div");replies.className="sq-replies";
        (e.replies||[]).forEach(function(rp){replies.appendChild(row(rp,true))});
        it.appendChild(replies);
      }
    }).finally(function(){list.__sqDecorating=false});
  })(lists[L])}}
try{new MutationObserver(function(){decorate()}).observe(document.body,{childList:true,subtree:true})}catch(x){}
pullMe();
function boxUnder(item,placeholder){var old=item.querySelector(".sq-gb-box");if(old){old.remove();return null}
  var box=document.createElement("div");box.className="sq-gb-box";box.style.cssText="display:flex;gap:6px;margin-top:6px";
  var inp=document.createElement("input");inp.placeholder=placeholder;inp.style.cssText="flex:1;background:#161014;border:1px solid #2a2128;border-radius:8px;color:#eee;font:13px system-ui;padding:7px 9px";
  var sb=document.createElement("button");sb.type="button";sb.textContent="\u27a4";sb.style.cssText="background:#2a2128;border:none;border-radius:8px;color:#e9b14e;font:14px system-ui;padding:0 10px;cursor:pointer";
  box.appendChild(inp);box.appendChild(sb);item.appendChild(box);inp.focus();
  return box}
function api(payload){return gbSafeFetch("/v1/x/guestbook",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)})}
function toast(item,text,bad){var t=document.createElement("div");t.textContent=text;t.style.cssText="color:"+(bad?"#ff6b6b":"#8fd6a0")+";font:12px system-ui;margin-top:5px";item.appendChild(t);setTimeout(function(){t.remove()},3000)}
function handle(f){var t=f.querySelector("textarea");if(!t)return false;var n=f.querySelector("input");var a=myAuth();var name=(a.local&&a.local.name)||((n&&n.value.trim())||"");var msg=t.value.trim();if(!name||!msg)return false;var btn=f.querySelector("button");if(btn)btn.disabled=true;
  api({name:name,message:msg,token:a.token}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(entry){t.value="";if(btn)btn.disabled=false;
    try{cache.data.unshift(entry);var nr=row(entry,false);var list=document.querySelector("#guestbook .gb-list");if(!list){var f0=document.querySelector("#guestbook .gb-form");if(f0){list=document.createElement("div");list.className="gb-list";f0.parentNode.insertBefore(list,f0.nextSibling)}}if(list){list.insertBefore(nr,list.firstChild)}
      var th=document.getElementById("sq-gb-thanks");if(!th){th=document.createElement("div");th.id="sq-gb-thanks";th.style.cssText="color:#8fd6a0;font:12.5px system-ui;margin-top:8px";f.parentNode.insertBefore(th,f.nextSibling)}
      th.textContent="\u2713 Message saved \u2014 it will appear here | \u067e\u06cc\u063a\u0627\u0645 \u0645\u062d\u0641\u0648\u0638 \u06c1\u0648 \u06af\u06cc\u0627";setTimeout(function(){if(th.parentNode)th.parentNode.removeChild(th)},4000)}catch(x){}
  }).catch(function(){if(btn)btn.disabled=false;var em=document.getElementById("sq-gb-err");if(!em){em=document.createElement("div");em.id="sq-gb-err";em.style.cssText="color:#ff6b6b;font:12px system-ui;margin-top:6px";f.parentNode.insertBefore(em,f.nextSibling)}em.textContent="Message could not be sent. Try again. / \u067e\u06cc\u063a\u0627\u0645 \u0646\u06c1\u06cc\u06ba \u06af\u06cc\u0627";setTimeout(function(){if(em.parentNode)em.parentNode.removeChild(em)},4000)});
  return true}
document.addEventListener("submit",function(e){var f=e.target;if(f&&f.classList&&f.classList.contains("gb-form")&&f.querySelector("textarea")){e.preventDefault();e.stopImmediatePropagation();handle(f)}},true);
document.addEventListener("click",function(e){
  var tg=e.target&&e.target.closest?e.target:null;if(!tg)return;
  var actBtn=tg.closest&&tg.closest("button[data-act]");
  if(!actBtn){var b2=tg.closest&&tg.closest("button");if(b2){var f=b2.closest("form");if(f&&f.classList.contains("gb-form")&&f.querySelector("textarea")&&b2.type!=="button"){e.preventDefault();e.stopImmediatePropagation();handle(f)}}return}
  e.preventDefault();e.stopImmediatePropagation();
  var act=actBtn.getAttribute("data-act"),id=actBtn.getAttribute("data-id");
  var item=actBtn.closest(".gb-item");var a=myAuth();
  if(act==="delete"){if(actBtn.getAttribute("data-armed")!=="1"){actBtn.setAttribute("data-armed","1");actBtn.textContent="Confirm?";actBtn.style.color="#ff6b6b";setTimeout(function(){if(actBtn.parentNode){actBtn.setAttribute("data-armed","0");actBtn.textContent="Delete";actBtn.style.color="#9a8f96"}},3000);return}
    api({action:"delete",id:id,token:a.token}).then(function(r){if(!r.ok)throw 0;var top=item.closest(".sq-gb-reply")?item.closest(".sq-gb-reply"):item;var pid=top.getAttribute("data-sq-id")||id;cache.data=cache.data.filter(function(x){return x.id!==pid&&x.parentId!==pid});top.remove()}).catch(function(){toast(item,"Delete failed / \u0646\u0627\u06a9\u0627\u0645",true)});return}
  if(act==="edit"){var pp=item.querySelector("p");if(!pp)return;
    if(item.querySelector(".sq-gb-box"))return;
    var box=document.createElement("div");box.className="sq-gb-box";box.style.cssText="display:flex;gap:6px;margin-top:6px";
    var ta=document.createElement("textarea");ta.value=pp.textContent;ta.style.cssText="flex:1;background:#161014;border:1px solid #2a2128;border-radius:8px;color:#eee;font:13px system-ui;padding:7px 9px;min-height:52px";
    var sv=document.createElement("button");sv.type="button";sv.textContent="Save";sv.style.cssText="background:#2a2128;border:none;border-radius:8px;color:#e9b14e;font:12px system-ui;padding:0 10px;cursor:pointer";
    box.appendChild(ta);box.appendChild(sv);pp.style.display="none";item.appendChild(box);ta.focus();
    sv.addEventListener("click",function(){var v=ta.value.trim();if(!v)return;
      api({action:"edit",id:id,message:v,token:a.token}).then(function(r){if(!r.ok)throw 0;pp.textContent=v;pp.style.display="";box.remove();var st=item.querySelector(".gb-head strong");if(st&&!st.textContent.match(/ \(edited\)$/))st.textContent+=" (edited)";var e2=cache.data.find(function(x){return x.id===id});if(e2)e2.message=v}).catch(function(){pp.style.display="";box.remove();toast(item,"Edit failed / \u0646\u0627\u06a9\u0627\u0645",true)})});
    return}
  if(act==="reply"){var existing=item.querySelector(".sq-gb-box");if(existing){existing.remove();return}
    var open=boxUnder(item,"Reply\u2026");if(!open)return;
    var inp=open.querySelector("input");
    var send=function(){var v=inp.value.trim();if(!v)return;open.remove();
      api({name:(a.local&&a.local.name)||"User",message:v,token:a.token,parentId:id}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(entry){var rp=item.querySelector(".sq-replies");if(!rp){rp=document.createElement("div");rp.className="sq-replies";item.appendChild(rp)}rp.appendChild(row(entry,true));cache.data.push(entry)}).catch(function(){toast(item,"Reply failed / \u0646\u0627\u06a9\u0627\u0645",true)})};
    open.querySelector("button").addEventListener("click",send);
    inp.addEventListener("keydown",function(ev){if(ev.key==="Enter"){ev.preventDefault();send()}});
    return}
},true);
})();;(function(){
if(window.__sqWa)return;window.__sqWa=1;
var SITE='https://velay.vellum.ai/01a0ed1e-8106-700e-bcf8-167ad3c73491/dist/index.html';
function show(t){var m=document.getElementById('sq-wa-msg');if(!m)return;m.textContent=t;m.style.display='block';clearTimeout(show.t);show.t=setTimeout(function(){m.style.display='none'},6000)}
function mount(){
  var sec=document.getElementById('contact');
  if(!sec||document.getElementById('sq-wa-btn'))return;
  var wrap=document.createElement('div');
  wrap.style.cssText='display:flex;flex-direction:column;align-items:center;gap:8px;margin-top:18px';
  var btn=document.createElement('button');
  btn.id='sq-wa-btn';
  btn.type='button';
  btn.style.cssText='display:inline-flex;align-items:center;gap:8px;background:#25D366;color:#04331f;border:none;border-radius:999px;padding:12px 22px;font-weight:700;font-size:14px;cursor:pointer';
  btn.innerHTML='<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm5.3 14.1c-.2.6-1.2 1.2-1.7 1.2-.4.1-1 .1-1.6-.1-.4-.1-.9-.3-1.5-.5-2.6-1.1-4.3-3.8-4.4-4-.1-.2-1.1-1.5-1.1-2.8s.7-2 .9-2.2c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.4l.9 2.1c.1.2.1.4 0 .6l-.4.6c-.1.2-.3.4-.1.7.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.6-.1l.8-1c.2-.3.4-.2.7-.1l2 .9c.3.2.5.3.6.4.1.2.1.8-.1 1.6z"/></svg>Share on WhatsApp';
  btn.onclick=function(){
    var text='Saqib ki website dekho! '+SITE;
    var w=null;
    try{w=window.open('https://wa.me/?text='+encodeURIComponent(text),'_blank')}catch(e){w=null}
    setTimeout(function(){
      try{if(w&&!w.closed){try{w.focus()}catch(e){}return}}catch(e){}
      var done=function(){show('\u2713 Link copy ho gaya \u2014 WhatsApp me paste karein')};
      var fail=function(){show('Link: '+SITE)};
      try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(SITE).then(done,fail)}else{fail()}}catch(e){fail()}
    },700);
  };
  var msg=document.createElement('div');
  msg.id='sq-wa-msg';
  msg.style.cssText='display:none;color:#2ecc71;font-size:13px;text-align:center;word-break:break-all;max-width:90%';
  wrap.appendChild(btn);wrap.appendChild(msg);
  sec.appendChild(wrap);
}
mount();
new MutationObserver(function(){mount()}).observe(document.body,{childList:true,subtree:true});
})();
;(function(){ // sq-admin panel — sirf owner ke liye
var OWNER="fizanali6267@gmail.com";
var CSS='#sq-admin-btn{position:fixed;left:14px;bottom:76px;z-index:11004;width:40px;height:40px;border-radius:50%;border:1px solid #f0c96a;background:rgba(18,8,28,.85);color:#f0c96a;font-size:16px;cursor:pointer;display:none;align-items:center;justify-content:center;box-shadow:0 3px 12px rgba(0,0,0,.45);-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}#sq-admin-ov{position:fixed;inset:0;z-index:11006;background:rgba(0,0,0,.75);display:flex;align-items:center;justify-content:center;-webkit-backdrop-filter:blur(4px);backdrop-filter:blur(4px)}#sq-admin-card{background:rgba(24,10,34,.98);border:1px solid #f0c96a;border-radius:14px;padding:20px 18px;width:min(90vw,340px);max-height:82vh;overflow-y:auto;color:#fff;box-shadow:0 10px 40px rgba(0,0,0,.6)}#sq-admin-card h3{margin:0 0 12px;font-size:16px;color:#f0c96a}.sq-ad-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}.sq-ad-box{background:#ffffff12;border:1px solid #ffffff22;border-radius:10px;padding:10px;text-align:center}.sq-ad-box b{display:block;font-size:20px;color:#f0c96a}.sq-ad-box span{font-size:11px;opacity:.7}.sq-ad-msg{font-size:13px;color:#ff6b81;text-align:center;padding:10px 0}#sq-admin-card h4{margin:0 0 6px;font-size:12px;color:#f0c96a;opacity:.9}.sq-ad-gb{font-size:12px;line-height:1.5;margin-bottom:8px;padding:8px 10px;background:#ffffff0d;border-radius:8px}.sq-ad-gb i{opacity:.6;font-style:normal;font-size:10.5px;display:block}#sq-admin-x{width:100%;padding:10px;border-radius:9px;border:none;background:#ffffff1c;color:#fff;cursor:pointer;font-size:13px;margin-top:6px;font-family:inherit}';
var st=document.createElement("style");st.id="sq-admin-style";st.textContent=CSS;document.head.appendChild(st);
var F=function(u,o){o=o||{};return window.vellum&&window.vellum.fetch?window.vellum.fetch(u,o):fetch(u,o)};
function me(){try{return JSON.parse(localStorage.getItem("portfolio-auth-local")||"null")}catch(e){return null}}
function openPanel(){
  if(document.getElementById("sq-admin-ov"))return;
  var ov=document.createElement("div");ov.id="sq-admin-ov";
  ov.innerHTML='<div id="sq-admin-card"><h3>Admin Panel<\/h3><div class="sq-ad-msg" id="sq-ad-msg">Loading...<\/div><div id="sq-ad-body"><\/div><button id="sq-admin-x">Band karo<\/button><\/div>';
  document.body.appendChild(ov);
  ov.querySelector("#sq-admin-x").addEventListener("click",function(){ov.remove()});
  ov.addEventListener("click",function(e){if(e.target===ov)ov.remove()});
  var token=null;try{token=localStorage.getItem("portfolio-auth-token")}catch(e){}
  F("/v1/x/admin",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:token})}).then(function(r){return r.json().then(function(j){return {s:r.status,j:j}})}).then(function(res){
    var m=ov.querySelector("#sq-ad-msg"),body=ov.querySelector("#sq-ad-body");
    if(!res.ok||!res.j||!res.j.ok){m.textContent=res.s===403?"Access denied \u2014 ye panel sirf owner ke liye hai.":"Data nahi mila \u2014 dobara koshish karo.";return}
    m.style.display="none";
    body.innerHTML='<div class="sq-ad-grid"><div class="sq-ad-box"><b>'+res.j.visitors+'<\/b><span>Visitors<\/span><\/div><div class="sq-ad-box"><b>'+res.j.users+'<\/b><span>Accounts<\/span><\/div><div class="sq-ad-box"><b>'+res.j.messages+'<\/b><span>Guestbook msgs<\/span><\/div><div class="sq-ad-box"><b>'+res.j.reactions+'<\/b><span>Photo reactions<\/span><\/div><\/div>'+(res.j.guestbook&&res.j.guestbook.length?'<h4>Aakhri guestbook messages<\/h4>'+res.j.guestbook.map(function(g){return '<div class="sq-ad-gb"><b>'+String(g.name).replace(/[<>&]/g,"")+'<\/b> '+String(g.message).replace(/[<>&]/g,"")+(g.createdAt?'<i>'+String(g.createdAt).slice(0,16).replace("T"," ")+'<\/i>':'')+'<\/div>'}).join(""):'<div class="sq-ad-gb">Abhi koi guestbook message nahi.<\/div>');
  }).catch(function(){var m=ov.querySelector("#sq-ad-msg");m.textContent="No connection \u2014 try again."});
}
var srvOk=false;var srvTried=0;
function serverMe(){try{var tk=localStorage.getItem("portfolio-auth-token")}catch(e){tk=null}if(!tk)return;F("/v1/x/guestbook",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"me",token:tk})}).then(function(r){return r.json()}).then(function(j){if(j&&j.ok&&j.email&&String(j.email).toLowerCase()===OWNER){srvOk=true;scan()}}).catch(function(){})}
function scan(){
  if(!srvOk&&srvTried<3&&++srvTried%1===0)serverMe();
  var u=null;try{u=JSON.parse(localStorage.getItem("portfolio-auth-local")||"null")}catch(e){u=null}
  var show=(u&&u.email&&String(u.email).toLowerCase()===OWNER)||srvOk;
  var btn=document.getElementById("sq-admin-btn");
  if(show&&!btn){
    btn=document.createElement("button");btn.id="sq-admin-btn";btn.title="Admin";btn.textContent="\uD83D\uDC51";
    btn.addEventListener("click",openPanel);
    (document.querySelector(".page")||document.body).appendChild(btn);
  }
  if(btn)btn.style.display=show?"flex":"none";
}
var t=setInterval(scan,900);scan();
})();;
;(function(){ // sq-gal-lock v2 — gallery sirf password janon ke liye
if(window.__sqGalLock)return;window.__sqGalLock=1;
var F=function(u,o){o=o||{};try{var v=window.vellum;return v&&typeof v.fetch=="function"?v.fetch(u,o):fetch(u,o)}catch(e){return fetch(u,o)}};
var unlocked=function(){try{return localStorage.getItem("sq-gal-ok")==="1"}catch(e){return false}};
var ov=null;var lastCard=-1;
var CSS='#sq-gal-lock-ov{position:fixed;inset:0;z-index:11050;background:rgba(8,3,14,.97);display:flex;align-items:center;justify-content:center;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}#sq-gal-lock-card{background:rgba(24,10,34,.98);border:1px solid #f0c96a;border-radius:14px;padding:24px 20px;width:min(88vw,320px);color:#fff;text-align:center;box-shadow:0 10px 40px rgba(0,0,0,.6)}#sq-gal-lock-card h3{margin:0 0 6px;font-size:16px;color:#f0c96a}#sq-gal-lock-card p{margin:0 0 14px;font-size:12px;opacity:.7}#sq-gal-lock-in{width:100%;box-sizing:border-box;padding:11px 12px;border-radius:9px;border:1px solid #ffffff30;background:#ffffff10;color:#fff;font-size:14px;text-align:center}#sq-gal-lock-in::placeholder{color:#ffffff60}#sq-gal-lock-btn{width:100%;margin-top:10px;padding:11px;border-radius:9px;border:none;background:#f0c96a;color:#1a0f26;font-weight:700;cursor:pointer;font-size:14px;font-family:inherit}#sq-gal-lock-err{display:none;color:#ff6b81;font-size:12.5px;margin-top:10px}';
var st=document.createElement('style');st.id='sq-gal-lock-style';st.textContent=CSS;document.head.appendChild(st);
function show(){
  if(ov&&document.body.contains(ov))return;
  ov=document.createElement('div');ov.id='sq-gal-lock-ov';
  ov.innerHTML='<div id="sq-gal-lock-card"><h3>\uD83D\uDD12 Gallery<\/h3><p>Ye gallery password se mehfooz hai<\/p><input id="sq-gal-lock-in" type="password" placeholder="Password" autocomplete="off"><button id="sq-gal-lock-btn">Unlock<\/button><div id="sq-gal-lock-err">Wrong password \u2014 \u063A\u0644\u0637 \u067E\u0627\u0633 \u0648\u0631\u0688<\/div><\/div>';
  document.body.appendChild(ov);
  var inp=ov.querySelector('#sq-gal-lock-in'),err=ov.querySelector('#sq-gal-lock-err');
  function tryUnlock(){
    F('/v1/x/gallery-lock',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pass:inp.value})}).then(function(r){return r.json().then(function(j){return{s:r.status,j:j}})}).then(function(res){
      if(res.j&&res.j.ok){try{localStorage.setItem('sq-gal-ok','1')}catch(e){}if(ov){ov.remove();ov=null}setTimeout(function(){var cards=document.querySelectorAll('.gal-card');if(lastCard>=0&&cards[lastCard])cards[lastCard].click();else if(cards[0])cards[0].click()},80)}else{err.style.display='block';inp.value='';inp.focus()}
    }).catch(function(){err.textContent='No connection \u2014 dobara koshish karo';err.style.display='block'});
  }
  ov.querySelector('#sq-gal-lock-btn').addEventListener('click',tryUnlock);
  inp.addEventListener('keydown',function(ev){if(ev.key==='Enter'){ev.preventDefault();tryUnlock()}});
  setTimeout(function(){try{inp.focus()}catch(e){}},100);
}
// 1) gallery card ke click ko capture phase me pakro — locked ho to view khula hi nahi
document.addEventListener('click',function(e){
  if(unlocked())return;
  var t=e.target;
  var card=t&&t.closest?t.closest('.gal-card'):null;
  if(card){lastCard=[].indexOf.call(document.querySelectorAll('.gal-card'),card);e.preventDefault();e.stopImmediatePropagation();show()}
},true);
// 2) backup: agar photos kisi tareeqe se render ho jayen aur lock na laga ho
new MutationObserver(function(){
  if(unlocked()){if(ov){ov.remove();ov=null}return}
  if(!ov&&document.querySelector('img[src*="photos"]'))show();
}).observe(document.body,{childList:true,subtree:true});
})();

/* sq-extras: Saqib Quiz + Photo of the Day + Secret easter egg */
;(function(){
'use strict';
function F(u,o){var v=window.vellum;var f=(v&&typeof v.fetch==='function')?v.fetch:fetch;try{return f(u,o)}catch(e){return fetch(u,o)}}
function A(p){try{var v=window.vellum;if(v&&typeof v.asset==='function')return v.asset(p)}catch(e){}return p}
function setSrc(img,p){var v=A(p);if(v&&typeof v.then==='function'){v.then(function(u){img.src=u})}else{img.src=v}}
function tok(){try{return localStorage.getItem('portfolio-auth-token')||''}catch(e){return ''}}
function localName(){try{var l=localStorage.getItem('portfolio-auth-local');if(l){var j=JSON.parse(l);return String(j.name||'')}}catch(e){}return ''}

/* ---------- PHOTO OF THE DAY ---------- */
var PHOTOS=['1000943911.jpg','1000943912.jpg','1000943913.jpg','1000943914.jpg','1000943915.jpg','1000943944.jpg','1000943946.jpg','1000943947.jpg','1000943951.jpg','1000943952.jpg','1000943954.jpg','1000943966.jpg','1000943976.jpg','1000943977.jpg'];
function potdMount(){
  var gal=document.getElementById('gallery');
  if(!gal||document.getElementById('sq-potd'))return;
  var d=new Date();
  var doy=Math.floor((Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())-Date.UTC(d.getFullYear(),0,0))/86400000);
  var f=PHOTOS[doy%PHOTOS.length];
  var card=document.createElement('div');card.id='sq-potd';
  card.style.cssText='margin:0 0 26px';
  var lbl=document.createElement('div');lbl.className='mono-label';lbl.textContent='PHOTO OF THE DAY \u00B7 '+d.toLocaleDateString();
  var img=document.createElement('img');img.alt='Photo of the day';img.loading='lazy';
  img.style.cssText='width:100%;max-height:420px;object-fit:cover;border-radius:14px;display:block;margin-top:10px;border:1px solid rgba(255,255,255,.14)';
  setSrc(img,'assets/photos/'+f);
  card.appendChild(lbl);card.appendChild(img);
  gal.insertBefore(card,gal.firstChild);
}

/* ---------- QUIZ SECTION ---------- */
var qsData=null,qi=0,answers=[],quizBusy=false;
function quizSection(){
  var contact=document.getElementById('contact');
  if(!contact)return null;
  var sec=document.createElement('section');sec.className='section';sec.id='quiz';sec.setAttribute('aria-label','Quiz');
  sec.innerHTML='<div class="section-header"><span class="mono-label">07 \u2014 Quiz / \u06A9\u0648\u0626\u0632</span></div><div id="sq-quiz-body" style="max-width:560px;margin:0 auto"></div>';
  contact.parentNode.insertBefore(sec,contact);
  return sec;
}
function qb(){var b=document.getElementById('sq-quiz-body');return b}
function el(tag,txt,css){var e=document.createElement(tag);if(txt)e.textContent=txt;if(css)e.style.cssText=css;return e}
function quizIntro(){
  var b=qb();if(!b)return;b.innerHTML='';
  var h=el('h3','Kitna jaante ho Saqib ko? \uD83E\uDD14','margin:0 0 8px;font-size:20px');
  var p=el('p','5 sawal \u2014 sahi jawab par leaderboard me naam. Answers server par hain, cheating nahi \uD83D\uDE0F','margin:0 0 18px;font-size:13px;opacity:.7');
  var btn=el('button','Start Quiz \uD83C\uDFAF',QBTN);
  btn.addEventListener('click',startQuiz);
  b.appendChild(h);b.appendChild(p);b.appendChild(btn);
}
var QBTN='padding:12px 26px;border-radius:999px;border:none;background:#f0c96a;color:#1a0f26;font-weight:700;cursor:pointer;font-size:14px;font-family:inherit';
var OPT='display:block;width:100%;margin:10px 0;padding:13px 16px;border-radius:12px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:inherit;font-size:14.5px;cursor:pointer;text-align:left;font-family:inherit;transition:background .15s';
function startQuiz(){
  if(quizBusy)return;quizBusy=true;
  var b=qb();if(!b){quizBusy=false;return}
  b.innerHTML='';
  b.appendChild(el('p','Loading\u2026','opacity:.6;font-size:13px'));
  F('/v1/x/quiz').then(function(r){return r.json()}).then(function(j){
    quizBusy=false;
    if(!j||!j.ok||!j.questions||!j.questions.length){b.innerHTML='';b.appendChild(el('p','Quiz load nahi hua \u2014 thori dair baad koshish karo','color:#ff6b81;font-size:13px'));return}
    qsData=j.questions;qi=0;answers=[];
    showQ();
  }).catch(function(){quizBusy=false;if(b){b.innerHTML='';b.appendChild(el('p','No connection \u2014 dobara koshish karo','color:#ff6b81;font-size:13px'))}});
}
function showQ(){
  var b=qb();if(!b)return;b.innerHTML='';
  var q=qsData[qi];
  b.appendChild(el('div','Q'+(qi+1)+' / '+qsData.length,'font-size:12px;opacity:.6;margin-bottom:8px;letter-spacing:.5px'));
  b.appendChild(el('p',q.q,'font-size:17px;font-weight:600;margin:0 0 14px'));
  q.options.forEach(function(op,oi){
    var ob=el('button',op,OPT);
    ob.addEventListener('click',function(){answers.push(oi);qi++;if(qi<qsData.length)showQ();else showNameSubmit()});
    b.appendChild(ob);
  });
}
function showNameSubmit(){
  var b=qb();if(!b)return;b.innerHTML='';
  b.appendChild(el('div','\uD83C\uDFAF','font-size:38px;text-align:center'));
  b.appendChild(el('p','Aakhri sawal ho gaya \u2014 naam likho aur nateeja dekho','text-align:center;font-size:13.5px;opacity:.8;margin:8px 0 16px'));
  var row=el('div','','display:flex;gap:10px');
  var inp=el('input','','flex:1;padding:11px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.06);color:inherit;font-size:14px;font-family:inherit');
  inp.placeholder='Apna naam likho';inp.maxLength=24;inp.value=localName();
  var sv=el('button','Finish \uD83C\uDFC1',QBTN);
  var err=el('div','','font-size:12.5px;margin-top:10px;color:#ff6b81;display:none');
  sv.addEventListener('click',function(){
    var nm=inp.value.trim()||'Mehman';
    sv.disabled=true;sv.textContent='Checking\u2026';
    F('/v1/x/quiz',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({answers:answers,name:nm,token:tok()})}).then(function(r){return r.json()}).then(function(j){
      if(j&&j.ok){showResult(j)}else{err.textContent='Save nahi hua \u2014 dobara koshish karo';err.style.display='block';sv.disabled=false;sv.textContent='Finish \uD83C\uDFC1'}
    }).catch(function(){err.textContent='No connection \u2014 dobara koshish karo';err.style.display='block';sv.disabled=false;sv.textContent='Finish \uD83C\uDFC1'});
  });
  row.appendChild(inp);row.appendChild(sv);
  b.appendChild(row);b.appendChild(err);
}
function showResult(j){
  var b=qb();if(!b)return;b.innerHTML='';
  var score=j.score,total=j.total;
  var msg=score===total?'Full marks! \uD83E\uDD0D Tum to asli dost ho':score>=3?'Wah! \uD83C\uDFAF':'Kuch yaad karna baki hai \uD83D\uDE05';
  b.appendChild(el('div','\uD83C\uDFAF','font-size:38px;text-align:center'));
  b.appendChild(el('div',score+' / '+total,'font-size:30px;font-weight:800;text-align:center;margin:4px 0'));
  b.appendChild(el('p',msg,'text-align:center;font-size:13.5px;opacity:.8;margin:0 0 14px'));
  var again=el('button','Dobara khelo \uD83D\uDD01','margin:0 auto 6px;display:block;padding:10px 22px;border-radius:999px;border:1px solid rgba(255,255,255,.25);background:transparent;color:inherit;font-size:13px;cursor:pointer;font-family:inherit');
  again.addEventListener('click',quizIntro);
  b.appendChild(again);
  var lt=el('div','Leaderboard \uD83C\uDFC6','font-size:13px;opacity:.7;margin:14px 0 6px');
  b.appendChild(lt);renderBoard(j.leaderboard||[]);
}
function renderBoard(list){
  var b=qb();if(!b)return;
  var old=document.getElementById('sq-quiz-board');if(old)old.remove();
  var wrap=el('div','');wrap.id='sq-quiz-board';
  wrap.style.cssText='margin-top:10px';
  if(!list.length){wrap.appendChild(el('p','Abhi koi score nahi \u2014 pehla tum bano!','font-size:12.5px;opacity:.6'));b.appendChild(wrap);return}
  list.forEach(function(s,i){
    var line=el('div','',(i===0?'background:rgba(240,201,106,.12);border:1px solid rgba(240,201,106,.35);':'')+'display:flex;justify-content:space-between;padding:8px 12px;border-radius:9px;margin:5px 0;font-size:13px');
    var l=el('span',(i+1)+'. '+String(s.name).slice(0,20));
    var r=el('span',s.score+'/'+s.total,'opacity:.75');
    line.appendChild(l);line.appendChild(r);wrap.appendChild(line);
  });
  b.appendChild(wrap);
}
function quizMount(){
  var contact=document.getElementById('contact');
  if(!contact)return;
  if(document.getElementById('quiz')){potdMount();return}
  var sec=quizSection();
  if(sec)quizIntro();
  potdMount();
}

/* ---------- SECRET EASTER EGG ---------- */
var taps=0,tapTimer=null;
document.addEventListener('click',function(e){
  var t=e.target&&e.target.closest?e.target.closest('.hero-name'):null;
  if(!t)return;
  taps++;
  if(tapTimer)clearTimeout(tapTimer);
  tapTimer=setTimeout(function(){taps=0},3000);
  if(taps>=5){taps=0;secretShow()}
},true);
function secretShow(){
  if(document.getElementById('sq-secret-ov'))return;
  var ov=document.createElement('div');ov.id='sq-secret-ov';
  ov.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(8,6,14,.94);display:flex;align-items:center;justify-content:center;padding:20px';
  ov.innerHTML='<div style="max-width:420px;width:100%;background:linear-gradient(160deg,#1d1230,#120b1e);border:1px solid rgba(240,201,106,.35);border-radius:18px;padding:26px;text-align:center;color:#fff;box-shadow:0 10px 40px rgba(0,0,0,.6)">'+
    '<div style="font-size:40px;margin-bottom:10px">\uD83E\uDD2B</div>'+
    '<h3 style="margin:0 0 12px;font-size:19px;color:#f0c96a">Secret message</h3>'+
    '<p style="margin:0 0 8px;font-size:14.5px;line-height:1.7;opacity:.9">Ye website sirf ek page nahi \u2014 ye Saqib ki duniya hai \uD83C\uDF0D</p>'+
    '<p style="margin:0 0 18px;font-size:13px;opacity:.7">Jo yahan tak aaya, wo asli dost hai \u2014 from Saqib \uD83E\uDD0D</p>'+
    '<button id="sq-secret-x" style="padding:10px 26px;border-radius:999px;border:none;background:#f0c96a;color:#1a0f26;font-weight:700;cursor:pointer;font-size:14px;font-family:inherit">Close</button></div>';
  document.body.appendChild(ov);
  ov.querySelector('#sq-secret-x').addEventListener('click',function(){ov.remove()});
  ov.addEventListener('click',function(ev){if(ev.target===ov)ov.remove()});
}

/* ---------- MOUNT + RE-MOUNT ---------- */
quizMount();
new MutationObserver(function(){quizMount()}).observe(document.body,{childList:true,subtree:true});
})();

/* sq-v2: birthday countdown + Q&A section + photo favourites */
;(function(){
'use strict';
function F(u,o){var v=window.vellum;var f=(v&&typeof v.fetch==='function')?v.fetch:fetch;try{return f(u,o)}catch(e){return fetch(u,o)}}
function tok(){try{return localStorage.getItem('portfolio-auth-token')||''}catch(e){return ''}}
function localName(){try{var l=localStorage.getItem('portfolio-auth-local');if(l){var j=JSON.parse(l);return String(j.name||'')}}catch(e){}return ''}
var CSS='#sq-bday{margin:14px auto 0;text-align:center;font-size:13.5px;letter-spacing:.4px;color:var(--gold,#d9a94e);opacity:.95}#sq-qa-list{margin:14px 0 22px}#sq-qa-list .sq-qa-item{border:1px solid var(--line,rgba(255,255,255,.12));border-radius:14px;padding:14px 16px;margin:10px 0;background:rgba(255,255,255,.03)}#sq-qa-list .sq-q{font-weight:600;font-size:14.5px;margin:0 0 6px}#sq-qa-list .sq-a{font-size:13.5px;opacity:.85;margin:0;white-space:pre-wrap}#sq-qa-list .sq-a::before{content:"Saqib: ";color:var(--gold,#d9a94e);font-weight:700}#sq-qa-list .sq-who{font-size:11px;opacity:.55;margin:6px 0 0;letter-spacing:.5px}.sq-fav-count{position:absolute;right:8px;bottom:8px;z-index:2;background:rgba(10,7,12,.72);border:1px solid rgba(240,201,106,.35);color:#f0c96a;font-size:11px;padding:3px 8px;border-radius:999px;pointer-events:none}#sq-qa-form input,#sq-qa-form textarea{width:100%;box-sizing:border-box;padding:11px 13px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.06);color:inherit;font-size:14px;font-family:inherit;margin:0 0 10px}#sq-qa-form textarea{min-height:70px;resize:vertical}#sq-qa-pending .sq-pend{border:1px solid rgba(240,201,106,.4);border-radius:12px;padding:12px 14px;margin:10px 0}#sq-qa-pending textarea{width:100%;box-sizing:border-box;padding:9px 11px;border-radius:9px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.06);color:inherit;font-size:13px;font-family:inherit;min-height:52px;margin:8px 0}';
(function(){var st=document.createElement('style');st.id='sq-v2-style';st.textContent=CSS;document.head.appendChild(st)})();

/* ---------- BIRTHDAY COUNTDOWN ---------- */
function bdayMount(){
  var hero=document.querySelector('.hero');
  if(!hero||document.getElementById('sq-bday'))return;
  var sub=hero.querySelector('.hero-sub');
  if(!sub)return;
  var now=new Date();
  var y=now.getFullYear();
  var b=new Date(y,4,27);
  var today=new Date(y,now.getMonth(),now.getDate());
  var txt;
  if(today.getTime()===b.getTime())txt='\uD83C\uDF82 Aaj mera birthday hai! \uD83E\uDD73';
  else{
    if(b<today)b=new Date(y+1,4,27);
    var days=Math.round((b-today)/86400000);
    txt='\uD83C\uDF82 Mera birthday '+days+' din baad \u2014 27 May';
  }
  var d=document.createElement('div');d.id='sq-bday';d.textContent=txt;
  sub.parentNode.insertBefore(d,sub.nextSibling);
}

/* ---------- Q&A SECTION ---------- */
function el(tag,txt,css){var e=document.createElement(tag);if(txt)e.textContent=txt;if(css)e.style.cssText=css;return e}
function btn(txt,css){var b=el('button',txt,css||'padding:11px 22px;border-radius:999px;border:none;background:#f0c96a;color:#1a0f26;font-weight:700;cursor:pointer;font-size:13.5px;font-family:inherit');return b}
function qaSection(){
  var contact=document.getElementById('contact');
  if(!contact)return null;
  var sec=document.createElement('section');sec.className='section';sec.id='qa';sec.setAttribute('aria-label','Q&A');
  sec.innerHTML='<div class="section-header"><span class="mono-label">08 \u2014 Q&A / \u0633\u0648\u0627\u0644 \u062C\u0648\u0627\u0628</span></div><div id="sq-qa-body" style="max-width:560px;margin:0 auto"></div>';
  contact.parentNode.insertBefore(sec,contact);
  return sec;
}
function qaRender(){
  var body=document.getElementById('sq-qa-body');if(!body)return;
  F('/v1/x/qa'+(tok()?'?token='+encodeURIComponent(tok()):'')).then(function(r){return r.json()}).then(function(j){
    if(!j||!j.ok)return;
    body.innerHTML='';
    var sub=el('p','Sawal poocho \u2014 Saqib jawab dega \uD83D\uDCAC','margin:0 0 16px;font-size:13px;opacity:.7');
    body.appendChild(sub);
    // answered list
    var list=el('div','');list.id='sq-qa-list';
    if(j.qa.length){
      j.qa.slice().reverse().forEach(function(item){
        var box=el('div','');box.className='sq-qa-item';
        box.appendChild(el('p','Q. '+item.question,'sq-q'));
        box.appendChild(el('p',item.answer,'sq-a'));
        box.appendChild(el('p','\u2014 '+item.name,'sq-who'));
        list.appendChild(box);
      });
    }else{
      list.appendChild(el('p','Abhi koi sawal jawab nahi hua \u2014 pehla sawal tum poocho!','font-size:12.5px;opacity:.6'));
    }
    body.appendChild(list);
    // owner: pending
    if(j.owner&&j.pending.length){
      var pw=el('div','');pw.id='sq-qa-pending';
      pw.appendChild(el('div','\uD83D\uDCDD Pending sawal ('+j.pending.length+') \u2014 sirf tum ko nazar','font-size:13px;color:#f0c96a;margin:4px 0 6px'));
      j.pending.forEach(function(item){
        var box=el('div','');box.className='sq-pend';
        box.appendChild(el('p',item.name+': '+item.question,'font-size:13.5px;font-weight:600;margin:0'));
        var ta=el('textarea');ta.placeholder='Apna jawab likho\u2026';
        var ab=btn('Answer \u2713');
        ab.addEventListener('click',function(){
          var a=ta.value.trim();if(!a)return;
          F('/v1/x/qa',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'answer',token:tok(),id:item.id,answer:a})}).then(function(r){return r.json()}).then(function(res){
            if(res&&res.ok)qaRender();
          }).catch(function(){});
        });
        box.appendChild(ta);box.appendChild(ab);pw.appendChild(box);
      });
      body.appendChild(pw);
    }
    // ask form
    var form=el('div','');form.id='sq-qa-form';
    form.appendChild(el('div','Sawal poocho \uD83D\uDE4B','font-size:13px;opacity:.7;margin:16px 0 8px'));
    var ni=el('input');ni.placeholder='Tumhara naam';ni.maxLength=24;ni.value=localName();
    var qi=el('textarea');qi.placeholder='Apna sawal likho\u2026';qi.maxLength=300;
    var sb=btn('Ask \uD83E\uDD3F');
    var msg=el('div','','font-size:12.5px;margin-top:8px;color:#7ddb8a;display:none');
    sb.addEventListener('click',function(){
      var q=qi.value.trim();if(!q){msg.textContent='Pehle sawal likho';msg.style.color='#ff6b81';msg.style.display='block';return}
      sb.disabled=true;sb.textContent='Sending\u2026';
      F('/v1/x/qa',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:ni.value.trim(),question:q})}).then(function(r){return r.json()}).then(function(res){
        sb.disabled=false;sb.textContent='Ask \uD83E\uDD3F';
        if(res&&res.ok){qi.value='';msg.textContent='\u2713 Sawal bhej diya \u2014 Saqib jawab dega to yahan dikhega';msg.style.color='#7ddb8a';msg.style.display='block';setTimeout(function(){msg.style.display='none'},5000)}
        else{msg.textContent='Bheja nahi gaya \u2014 dobara koshish karo';msg.style.color='#ff6b81';msg.style.display='block'}
      }).catch(function(){sb.disabled=false;sb.textContent='Ask \uD83E\uDD3F';msg.textContent='No connection';msg.style.color='#ff6b81';msg.style.display='block'});
    });
    form.appendChild(ni);form.appendChild(qi);form.appendChild(sb);form.appendChild(msg);
    body.appendChild(form);
  }).catch(function(){});
}
function qaMount(){
  var contact=document.getElementById('contact');
  if(!contact)return;
  if(document.getElementById('qa'))return;
  var sec=qaSection();
  if(sec)qaRender();
}

/* ---------- PHOTO FAVOURITES (heart counts) ---------- */
var favCounts=null,lastPull=0;
function favPull(){
  return F('/v1/x/photo-reactions').then(function(r){return r.json()}).then(function(j){
    favCounts=j||{};lastPull=Date.now();return favCounts;
  }).catch(function(){favCounts={};return favCounts});
}
function favDecorate(){
  var tiles=document.querySelectorAll('.tile-photo');
  if(!tiles.length)return;
  var none=!document.querySelector('.sq-fav-count');
  if(favCounts===null||(none&&Date.now()-lastPull>2000)){favPull().then(function(){favDecorate()});return}
  if(favCounts===null)return;
  tiles.forEach(function(t){
    if(t.querySelector('.sq-fav-count'))return;
    var img=t.querySelector('img.tile-img');
    if(!img||!img.src)return;
    var m=img.src.match(/photos\/([^\/?#]+\.jpg)/);
    if(!m)return;
    var key='assets/photos/'+m[1];
    var c=(favCounts[key]&&favCounts[key].love)||0;
    var b=el('span','\u2764\uFE0F '+c);b.className='sq-fav-count';
    var inner=t.querySelector('.tile-inner')||t;
    if(getComputedStyle(inner).position==='static')inner.style.position='relative';
    inner.appendChild(b);
  });
}

/* ---------- MOUNT ---------- */
function mountAll(){bdayMount();qaMount();favDecorate()}
favPull().then(function(){mountAll()});
new MutationObserver(function(){mountAll()}).observe(document.body,{childList:true,subtree:true});
})();

/* sq-v3: CV download + contact form + guestbook reactions + auto theme */
;(function(){
'use strict';
function F(u,o){var v=window.vellum;var f=(v&&typeof v.fetch==='function')?v.fetch:fetch;try{return f(u,o)}catch(e){return fetch(u,o)}}
function A(p){var v=window.vellum;var r=v&&typeof v.asset==='function'?v.asset(p):p;if(r&&typeof r.then==='function')return r;return Promise.resolve(r)}
function tok(){try{return localStorage.getItem('portfolio-auth-token')||''}catch(e){return ''}}
function localName(){try{var l=localStorage.getItem('portfolio-auth-local');if(l){var j=JSON.parse(l);return String(j.name||'')}}catch(e){}return ''}
function localEmail(){try{var l=localStorage.getItem('portfolio-auth-local');if(l){var j=JSON.parse(l);return String(j.email||'')}}catch(e){}return ''}
function el(tag,txt,css){var e=document.createElement(tag);if(txt)e.textContent=txt;if(css)e.style.cssText=css;return e}
var GOLD='#f0c96a';
var CSS='#sq-cv-btn{display:inline-flex;align-items:center;gap:7px;padding:11px 20px;border-radius:999px;border:1px solid rgba(240,201,106,.5);background:rgba(240,201,106,.1);color:#f0c96a;font-weight:700;cursor:pointer;font-size:13.5px;font-family:inherit}#sq-contact-form{margin:26px 0 0}#sq-contact-form input,#sq-contact-form textarea{width:100%;box-sizing:border-box;padding:11px 13px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.06);color:inherit;font-size:14px;font-family:inherit;margin:0 0 10px}#sq-contact-form textarea{min-height:80px;resize:vertical}.sq-react-bar{display:flex;gap:6px;margin-top:8px}.sq-react-btn{padding:3px 9px;border-radius:999px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.05);font-size:12px;cursor:pointer;color:inherit;font-family:inherit}.sq-react-btn.sq-mine{border-color:rgba(240,201,106,.6);background:rgba(240,201,106,.12)}';
(function(){var st=document.createElement('style');st.id='sq-v3-style';st.textContent=CSS;document.head.appendChild(st)})();

/* ---------- AUTO THEME (raat dark, din light — jab manual set na ho) ---------- */
function autoTheme(){
  var manual=false;
  try{manual=localStorage.getItem('portfolio-theme')!==null}catch(e){}
  if(manual)return;
  var h=new Date().getHours();
  var day=h>=6&&h<19;
  document.documentElement.classList.toggle('theme-light',day);
}
autoTheme();
setInterval(autoTheme,600000);

/* ---------- CV DOWNLOAD (contact me, WhatsApp ke sath) ---------- */
function cvMount(){
  var contact=document.getElementById('contact');
  if(!contact||document.getElementById('sq-cv-btn'))return;
  var wa=document.getElementById('sq-wa-btn');
  var b=el('button','\u{1F4C4} Download CV');b.id='sq-cv-btn';
  b.addEventListener('click',function(){
    A('assets/cv-saqib-iqbal.pdf').then(function(u){
      var a=document.createElement('a');a.href=u;a.download='Saqib-Iqbal-CV.pdf';
      document.body.appendChild(a);a.click();a.remove();
      var old=document.getElementById('sq-cv-msg');
      if(old)old.remove();
      var m=el('div','\u2713 CV download ho raha hai','font-size:12.5px;margin-top:8px;color:#7ddb8a');m.id='sq-cv-msg';
      b.parentNode.insertBefore(m,b.nextSibling);
      setTimeout(function(){if(m.parentNode)m.remove()},4000);
    }).catch(function(){});
  });
  if(wa&&wa.parentNode){wa.parentNode.insertBefore(b,wa.nextSibling);wa.style.marginRight='10px'}
  else{contact.appendChild(b)}
}

/* ---------- CONTACT FORM (visitor messages) ---------- */
function cfMount(){
  var contact=document.getElementById('contact');
  if(!contact||document.getElementById('sq-contact-form'))return;
  var form=el('div','');form.id='sq-contact-form';
  form.appendChild(el('div','Ya seedha message chhod do \u270D\uFE0F','font-size:13px;opacity:.7;margin:22px 0 8px'));
  var ni=el('input');ni.placeholder='Naam';ni.maxLength=24;ni.value=localName();
  var ei=el('input');ei.placeholder='Email (optional)';ei.maxLength=80;
  var mi=el('textarea');mi.placeholder='Apna message likho\u2026';mi.maxLength=1000;
  var sb=el('button','Send \u27A4','padding:11px 22px;border-radius:999px;border:none;background:#f0c96a;color:#1a0f26;font-weight:700;cursor:pointer;font-size:13.5px;font-family:inherit');
  var msg=el('div','','font-size:12.5px;margin-top:8px;color:#7ddb8a;display:none');
  sb.addEventListener('click',function(){
    var m=mi.value.trim();
    if(!m){msg.textContent='Pehle message likho';msg.style.color='#ff6b81';msg.style.display='block';return}
    sb.disabled=true;sb.textContent='Sending\u2026';
    F('/v1/x/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:ni.value.trim(),email:ei.value.trim(),message:m})}).then(function(r){return r.json()}).then(function(j){
      sb.disabled=false;sb.textContent='Send \u27A4';
      if(j&&j.ok){mi.value='';msg.textContent='\u2713 Message pahunch gaya \u2014 Saqib ko nazar aayega';msg.style.color='#7ddb8a';msg.style.display='block';setTimeout(function(){msg.style.display='none'},5000)}
      else{msg.textContent='Bheja nahi gaya \u2014 dobara koshish karo';msg.style.color='#ff6b81';msg.style.display='block'}
    }).catch(function(){sb.disabled=false;sb.textContent='Send \u27A4';msg.textContent='No connection';msg.style.color='#ff6b81';msg.style.display='block'});
  });
  form.appendChild(ni);form.appendChild(ei);form.appendChild(mi);form.appendChild(sb);form.appendChild(msg);
  contact.appendChild(form);
}

/* ---------- GUESTBOOK EMOJI REACTIONS ---------- */
var EMO={love:'\u2764\uFE0F',fire:'\uD83D\uDD25',laugh:'\uD83D\uDE02'};
function reactDecorate(){
  var items=document.querySelectorAll('.gb-item');
  if(!items.length)return;
  items.forEach(function(it){
    if(it.closest('.sq-replies')||it.querySelector('.sq-react-bar')||it.closest('.sq-gb-actions'))return;
    var ab=it.querySelector('.sq-gb-actions button[data-id]');
    var id=(ab&&ab.getAttribute('data-id'))||it.getAttribute('data-id')||'';
    if(!id)return;
    var bar=el('div','');bar.className='sq-react-bar';
    var counts=window.__sqRx&&window.__sqRx[id]||null;
    ['love','fire','laugh'].forEach(function(k){
      var c=counts?counts[k]||0:0;
      var mine=counts&&counts[k+'_mine'];
      var b=el('button',EMO[k]+' '+c,'');
      b.className='sq-react-btn'+(mine?' sq-mine':'');
      b.addEventListener('click',function(ev){
        ev.preventDefault();ev.stopPropagation();
        if(!tok()){b.title='Login karke react karo';return}
        F('/v1/x/guestbook',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'react',id:id,emoji:k,token:tok()})}).then(function(r){return r.json()}).then(function(j){
          if(j&&j.ok){b.textContent=EMO[k]+' '+j[k];b.classList.toggle('sq-mine')}
        }).catch(function(){});
      });
      bar.appendChild(b);
    });
    it.appendChild(bar);
  });
}

/* crown panel me messages dikhana */
function panelHook(){
  var card=document.getElementById('sq-admin-card');
  if(!card||document.getElementById('sq-admin-msgs'))return;
  F('/v1/x/contact?token='+encodeURIComponent(tok())).then(function(r){return r.json()}).then(function(j){
    if(!j||!j.ok)return;
    var w=el('div','');w.id='sq-admin-msgs';
    w.style.cssText='margin-top:14px;border-top:1px solid rgba(255,255,255,.15);padding-top:10px';
    w.appendChild(el('div','\u2709\uFE0F Messages ('+j.msgs.length+')','font-size:12px;color:#f0c96a;margin-bottom:8px;letter-spacing:.5px'));
    if(!j.msgs.length)w.appendChild(el('div','Koi message nahi','font-size:12px;opacity:.6'));
    j.msgs.slice(0,20).forEach(function(m){
      var line=el('div','', 'font-size:12.5px;margin:6px 0;opacity:.9');
      line.textContent=m.name+(m.email?' ('+m.email+')':'')+': '+m.message;
      w.appendChild(line);
    });
    card.appendChild(w);
    try{localStorage.setItem('sq-unread','0')}catch(e){}
    F('/v1/x/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'read',token:tok()})}).catch(function(){});
  }).catch(function(){});
}

/* ---------- MOUNT ---------- */
var rxLoaded=false;
function loadRx(){
  F('/v1/x/guestbook').then(function(r){return r.json()}).then(function(list){
    var map={};
    (list||[]).forEach(function(e){
      map[e.id]=e.reactions||{};
      (e.replies||[]).forEach(function(rp){map[rp.id]=rp.reactions||{}});
    });
    window.__sqRx=map;rxLoaded=true;
    reactDecorate();
  }).catch(function(){});
}
function mountAll(){cvMount();cfMount();if(rxLoaded)reactDecorate();panelHook()}
mountAll();
loadRx();
new MutationObserver(function(){mountAll()}).observe(document.body,{childList:true,subtree:true});
})();


/* sq-v4: namaz timings + slideshow + site search + QR + owner badge + site rating */
;(function(){
'use strict';
function F(u,o){var v=window.vellum;var f=(v&&typeof v.fetch==='function')?v.fetch:fetch;try{return f(u,o)}catch(e){return fetch(u,o)}}
function A(p){var v=window.vellum;var r=v&&typeof v.asset==='function'?v.asset(p):p;if(r&&typeof r.then==='function')return r;return Promise.resolve(r)}
function tok(){try{return localStorage.getItem('portfolio-auth-token')||''}catch(e){return ''}}
function el(tag,txt,css){var e=document.createElement(tag);if(txt)e.textContent=txt;if(css)e.setAttribute('style',css);return e}
var PHOTOS=['1000943911.jpg','1000943912.jpg','1000943913.jpg','1000943914.jpg','1000943915.jpg','1000943944.jpg','1000943946.jpg','1000943947.jpg','1000943951.jpg','1000943952.jpg','1000943954.jpg','1000943966.jpg','1000943976.jpg','1000943977.jpg'];
var SITE='https://velay.vellum.ai/01a0ed1e-8106-700e-bcf8-167ad3c73491';
var CSS='#sq-fab{position:fixed;right:14px;bottom:14px;z-index:9500;width:44px;height:44px;border-radius:50%;border:1px solid rgba(240,201,106,.5);background:rgba(10,7,14,.85);color:#f0c96a;font-size:19px;cursor:pointer;box-shadow:0 4px 18px rgba(0,0,0,.5)}#sq-search-ov{position:fixed;inset:0;z-index:11010;background:rgba(5,3,8,.9);display:flex;align-items:flex-start;justify-content:center;padding:60px 16px}#sq-search-card{width:100%;max-width:420px;background:#0e0a13;border:1px solid rgba(240,201,106,.35);border-radius:14px;padding:16px;max-height:70vh;overflow:auto}#sq-search-card input{width:100%;box-sizing:border-box;padding:10px 12px;border-radius:9px;border:1px solid rgba(255,255,255,.25);background:rgba(255,255,255,.07);color:inherit;font-size:14px;font-family:inherit;margin-bottom:10px}.sq-sres{padding:8px 10px;border-radius:8px;cursor:pointer;font-size:13.5px;color:inherit}.sq-sres:hover{background:rgba(240,201,106,.14)}#sq-slide-ov{position:fixed;inset:0;z-index:11012;background:rgba(2,1,4,.96);display:flex;align-items:center;justify-content:center;flex-direction:column}#sq-slide-ov img{max-width:94vw;max-height:78vh;border-radius:10px;object-fit:contain}#sq-qr-ov{position:fixed;inset:0;z-index:11011;background:rgba(5,3,8,.9);display:flex;align-items:center;justify-content:center}#sq-qr-card{background:#fff;border-radius:14px;padding:18px;text-align:center;max-width:280px}.sq-star{font-size:26px;cursor:pointer;color:rgba(255,255,255,.35);background:none;border:none;padding:0 2px}.sq-star.sq-on{color:#f0c96a}#sq-namaz{margin-top:18px;padding:13px 15px;border:1px solid rgba(240,201,106,.35);border-radius:12px;font-size:13px}#sq-namaz .sq-nz-row{display:flex;justify-content:space-between;padding:2.5px 0}#sq-namaz .sq-nz-next{color:#f0c96a;font-weight:700}.sq-badge{position:absolute;top:-6px;right:-6px;min-width:18px;height:18px;border-radius:9px;background:#e5484d;color:#fff;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;padding:0 5px;z-index:11005}';
(function(){var st=document.getElementById('sq-v4-style');if(!st){st=document.createElement('style');st.id='sq-v4-style';st.textContent=CSS;document.head.appendChild(st)}})();

/* ---------- 1. NAMAZ TIMINGS ---------- */
var NZ=['Fajr','Dhuhr','Asr','Maghrib','Isha'];
var CITY='Lahore';
function namazMount(){
  var bio=document.getElementById('bio');
  if(!bio||document.getElementById('sq-namaz'))return;
  var box=el('div','');box.id='sq-namaz';
  var head=el('div','\u{1F54C} Namaaz times \u2014 '+CITY,'font-weight:700;color:#f0c96a;margin-bottom:6px;font-size:13.5px');
  var body=el('div','Load ho raha hai\u2026','opacity:.7');
  box.appendChild(head);box.appendChild(body);bio.appendChild(box);
  function render(t){
    body.textContent='';
    var now=new Date(),cur=now.getHours()*60+now.getMinutes();
    var next=null,nextMin=1e9;
    NZ.forEach(function(n){
      var v=t[n];
      if(typeof v!=='number')return;
      var mins=Math.round(v*60),h24=Math.floor(mins/60)%24,mm=mins%60;
      var ap=h24>=12?'PM':'AM',h12=h24%12||12;
      var row=el('div','');row.className='sq-nz-row';
      row.appendChild(el('span',n));
      row.appendChild(el('span',h12+':'+('0'+mm).slice(-2)+' '+ap));
      body.appendChild(row);
      if(mins>cur&&mins<nextMin){nextMin=mins;next=n}
    });
    if(next){var n=el('div','Agli: '+next,'margin-top:5px');n.className='sq-nz-next';body.appendChild(n)}
  }
  /* offline calculation — suraj ki position se, koi network nahi (aladhan par match, \u00b12 min) */
  var CITYPOS={Lahore:[31.5204,74.3587],Karachi:[24.8607,67.0011],Islamabad:[33.6844,73.0479],Faisalabad:[31.4187,73.0791],Multan:[30.1575,71.5249],Peshawar:[34.0151,71.5249]};
  var pos=CITYPOS[CITY]||CITYPOS.Lahore;
  function calcTimes(){
    var now=new Date(),lat=pos[0],lng=pos[1],tz=-now.getTimezoneOffset()/60;
    function jdt(y,m,d){if(m<=2){y-=1;m+=12}var A=Math.floor(y/100),B=2-A+Math.floor(A/4);return Math.floor(365.25*(y+4716))+Math.floor(30.6001*(m+1))+d+B-1524.5}
    var jd=jdt(now.getFullYear(),now.getMonth()+1,now.getDate())-lng/(15*24);
    var D=jd-2451545.0;
    var g=fixA(357.529+0.98560028*D),q=fixA(280.459+0.98564736*D);
    var L=fixA(q+1.915*Math.sin(rad(g))+0.020*Math.sin(rad(2*g)));
    var e=23.439-0.00000036*D;
    var RA=deg(Math.atan2(Math.cos(rad(e))*Math.sin(rad(L)),Math.cos(rad(L))))/15;
    var dec=deg(Math.asin(Math.sin(rad(e))*Math.sin(rad(L)))),eqt=q/15-fixH(RA);
    var noon=12-eqt;
    function elevT(a){return deg(Math.acos((Math.sin(rad(a))-Math.sin(rad(dec))*Math.sin(rad(lat)))/(Math.cos(rad(dec))*Math.cos(rad(lat)))))/15}
    var adj=tz-lng/15;
    var asrA=deg(Math.atan(1/(1+Math.tan(rad(Math.abs(lat-dec))))));
    return {Fajr:noon-elevT(-18)+adj,Dhuhr:noon+adj,Asr:noon+elevT(asrA)+adj,Maghrib:noon+elevT(-0.833)+adj,Isha:noon+elevT(-18)+adj};
  }
  function fixA(a){a=a-360*Math.floor(a/360);return a<0?a+360:a}
  function fixH(h){h=h-24*Math.floor(h/24);return h<0?h+24:h}
  function rad(d){return d*Math.PI/180}function deg(r){return r*180/Math.PI}
  render(calcTimes());
}

/* ---------- 2. PHOTO SLIDESHOW ---------- */
var slideTimer=null,slideOv=null,slideIdx=0;
function slideStop(){if(slideTimer){clearInterval(slideTimer);slideTimer=null}if(slideOv){slideOv.remove();slideOv=null}}
function slideShow(){
  if(!localStorage.getItem('sq-gal-ok')){var g=document.getElementById('gallery');if(g)g.scrollIntoView({block:'center'});return}
  slideStop();
  slideOv=el('div','');slideOv.id='sq-slide-ov';
  var img=el('img');img.alt='slideshow';
  var lbl=el('div','','margin-top:10px;font-size:13px;color:#f0c96a');
  var stop=el('button','\u25A0 Stop','margin-top:10px;padding:8px 20px;border-radius:999px;border:1px solid rgba(240,201,106,.5);background:rgba(240,201,106,.12);color:#f0c96a;font-size:13px;cursor:pointer;font-family:inherit');
  stop.addEventListener('click',function(e){e.stopPropagation();slideStop()});
  slideOv.appendChild(img);slideOv.appendChild(lbl);slideOv.appendChild(stop);
  function set(i){
    slideIdx=(i+PHOTOS.length)%PHOTOS.length;
    lbl.textContent=(slideIdx+1)+' / '+PHOTOS.length;
    A('assets/photos/'+PHOTOS[slideIdx]).then(function(u){img.src=u}).catch(function(){img.src='assets/photos/'+PHOTOS[slideIdx]});
  }
  slideOv.addEventListener('click',function(e){if(e.target===slideOv)slideStop()});
  document.body.appendChild(slideOv);
  set(slideIdx);
  slideTimer=setInterval(function(){set(slideIdx+1)},3000);
}
function slideMount(){
  var gal=document.getElementById('gallery');
  if(!gal||document.getElementById('sq-slide-btn'))return;
  var b=el('button','\u25B6 Slideshow','margin-top:12px;padding:9px 18px;border-radius:999px;border:1px solid rgba(240,201,106,.5);background:rgba(240,201,106,.1);color:#f0c96a;font-weight:700;font-size:12.5px;cursor:pointer;font-family:inherit');
  b.id='sq-slide-btn';
  b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();slideShow()});
  gal.appendChild(b);
}

/* ---------- 3. SITE SEARCH ---------- */
var SECTIONS=[['bio','Bio \u2014 Saqib ka taaruf'],['achievements','Achievements \u2014 kitaabat aur marks'],['quote','Quote \u2014 Walk alone, stay silent'],['music','Music \u2014 naat'],['gallery','Gallery \u2014 photos (password ke baad)'],['guestbook','Guestbook \u2014 messages'],['quiz','Quiz \u2014 Saqib ka quiz'],['qa','Q&A \u2014 sawal jawab'],['contact','Contact \u2014 rabta, CV, QR']];
function searchOpen(){
  var old=document.getElementById('sq-search-ov');if(old)old.remove();
  var ov=el('div','');ov.id='sq-search-ov';
  var card=el('div','');card.id='sq-search-card';
  var inp=el('input');inp.placeholder='Kya dhoondhna hai?';
  var res=el('div','');
  card.appendChild(inp);card.appendChild(res);ov.appendChild(card);
  ov.addEventListener('click',function(e){if(e.target===ov)ov.remove()});
  document.body.appendChild(ov);
  function render(q){
    res.textContent='';
    q=q.trim().toLowerCase();
    if(!q)return;
    var hits=0;
    SECTIONS.forEach(function(s){
      if(s[1].toLowerCase().indexOf(q)===-1&&s[0].indexOf(q)===-1)return;
      hits++;
      var d=el('div',s[1]);d.className='sq-sres';
      d.addEventListener('click',function(){var t=document.getElementById(s[0]);if(t)t.scrollIntoView({block:'center'});ov.remove()});
      res.appendChild(d);
    });
    var pk=q==='photo'||q==='photos'||q==='tasweer'||q==='pic'||q==='image';
    PHOTOS.forEach(function(f,i){
      if(!pk)return;
      hits++;
      var d=el('div','\u{1F4BC} Photo '+(i+1)+' \u2014 '+f);d.className='sq-sres';
      d.addEventListener('click',function(){var t=document.getElementById('gallery');if(t){t.scrollIntoView({block:'center'});slideIdx=i;setTimeout(function(){if(localStorage.getItem('sq-gal-ok'))slideShow()},400)}ov.remove()});
      res.appendChild(d);
    });
    F('/v1/x/guestbook').then(function(r){return r.json()}).then(function(list){
      (list||[]).forEach(function(e){
        if(String(e.message||'').toLowerCase().indexOf(q)===-1)return;
        hits++;
        var d=el('div','\u270D\uFE0F '+(e.name||'?')+': '+String(e.message).slice(0,60));d.className='sq-sres';
        d.addEventListener('click',function(){var t=document.getElementById('guestbook');if(t)t.scrollIntoView({block:'center'});ov.remove()});
        res.appendChild(d);
      });
      if(!hits&&res.textContent==='')res.appendChild(el('div','Kuch nahi mila','opacity:.6;font-size:13px;padding:8px'));
    }).catch(function(){if(!hits)res.appendChild(el('div','Kuch nahi mila','opacity:.6;font-size:13px;padding:8px'))});
  }
  inp.addEventListener('input',function(){render(inp.value)});
  inp.focus();
  setTimeout(function(){render(inp.value)},0);
}
function searchMount(){
  if(document.getElementById('sq-fab'))return;
  var b=el('button','\u{1F50D}');b.id='sq-fab';
  b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();searchOpen()});
  document.body.appendChild(b);
}

/* ---------- 4. QR CODE ---------- */
function qrMount(){
  var contact=document.getElementById('contact');
  if(!contact||document.getElementById('sq-qr-btn'))return;
  var b=el('button','\u{1F4F2} QR Code','margin-left:10px;display:inline-flex;align-items:center;padding:11px 20px;border-radius:999px;border:1px solid rgba(240,201,106,.5);background:rgba(240,201,106,.1);color:#f0c96a;font-weight:700;cursor:pointer;font-size:13.5px;font-family:inherit');
  b.id='sq-qr-btn';
  b.addEventListener('click',function(e){
    e.preventDefault();e.stopPropagation();
    var url=window.location.href&&window.location.href.indexOf('http')===0?window.location.href:SITE;
    var old=document.getElementById('sq-qr-ov');if(old)old.remove();
    var ov=el('div','');ov.id='sq-qr-ov';
    var card=el('div','');card.id='sq-qr-card';
    var img=el('img');img.alt='QR';img.setAttribute('style','width:210px;height:210px');
    img.src='https://api.qrserver.com/v1/create-qr-code/?size=210x210&data='+encodeURIComponent(url);
    var t=el('div','Site ka QR \u2014 scan karo','margin-top:10px;font-size:13px;color:#111;font-weight:700');
    var u=el('div',url,'margin-top:4px;font-size:10.5px;color:#333;word-break:break-all');
    card.appendChild(img);card.appendChild(t);card.appendChild(u);
    ov.appendChild(card);document.body.appendChild(ov);
    ov.addEventListener('click',function(){ov.remove()});
  });
  var cv=document.getElementById('sq-cv-btn');
  if(cv&&cv.parentNode)cv.parentNode.insertBefore(b,cv.nextSibling);
  else contact.appendChild(b);
}

/* ---------- 5. OWNER BADGE (naye messages) ---------- */
function badgeMount(){
  var btn=document.querySelector('#sq-admin-btn');
  if(!btn)return;
  if(!btn.style||btn.style.position!=='absolute'){
    var cs=window.getComputedStyle(btn);
    if(cs.position==='static'){btn.style.position='relative'}
  }
  var email='';try{var l=localStorage.getItem('portfolio-auth-local');if(l)email=String(JSON.parse(l).email||'')}catch(e){}
  if(email!=='fizanali6267@gmail.com')return;
  var cached=0;try{cached=+localStorage.getItem('sq-unread')||0}catch(e){}
  /* sirf tab DOM chhedo jab state badli ho — warna mutation loop ban jata hai */
  var cur=btn.querySelector('.sq-badge');
  if(cached>0&&!cur){btn.style.position=btn.style.position||'relative';var sp0=el('span',String(cached));sp0.className='sq-badge';btn.appendChild(sp0)}
  else if(cached>0&&cur){if(cur.textContent!==String(cached))cur.textContent=String(cached)}
  else if(cur)cur.remove();
  var last=0;try{last=+localStorage.getItem('sq-unread-at')||0}catch(e){}
  if(Date.now()-last<30000)return;
  try{localStorage.setItem('sq-unread-at',String(Date.now()))}catch(e){}
  F('/v1/x/contact?token='+encodeURIComponent(tok())).then(function(r){return r.json()}).then(function(j){
    if(!j||!j.ok)return;
    var n=(j.msgs||[]).filter(function(m){return !m.read}).length;
    try{localStorage.setItem('sq-unread',String(n))}catch(e){}
    var c2=btn.querySelector('.sq-badge');
    if(n>0&&!c2){btn.style.position=btn.style.position||'relative';var sp=el('span',String(n));sp.className='sq-badge';btn.appendChild(sp)}
    else if(n>0&&c2){if(c2.textContent!==String(n))c2.textContent=String(n)}
    else if(c2)c2.remove();
  }).catch(function(){});
}

/* ---------- 6. SITE RATING ---------- */
function ratingMount(){
  var gb=document.getElementById('guestbook');
  if(!gb||document.getElementById('sq-rating'))return;
  var box=el('div','');box.id='sq-rating';
  box.setAttribute('style','margin:0 0 16px;padding:12px 14px;border:1px solid rgba(240,201,106,.35);border-radius:12px');
  var lbl=el('div','Is site ko rate karo:','font-size:13px;margin-bottom:6px');
  var row=el('div','');row.setAttribute('style','display:flex;align-items:center;gap:2px');
  var avgLine=el('div','','font-size:12.5px;opacity:.75;margin-top:6px');
  box.appendChild(lbl);box.appendChild(row);box.appendChild(avgLine);gb.insertBefore(box,gb.firstChild);
  var cur=0;
  function paint(n,mine){row.textContent='';for(var i=1;i<=5;i++){(function(v){
    var s=el('button',v<=n?'\u2605':'\u2606');s.className='sq-star'+(v<=n?' sq-on':'');
    s.addEventListener('click',function(e){
      e.preventDefault();e.stopPropagation();
      cur=v;
      if(!tok()){avgLine.textContent='Rate karne ke liye pehle login karo';return}
      F('/v1/x/ratings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({stars:v,token:tok()})}).then(function(r){return r.json()}).then(function(j){
        if(j&&j.ok){paint(j.mine,true);avgLine.textContent='\u2605 '+j.avg+' \u2014 '+j.count+' vote'+(j.count>1?'s':'')}
        else if(j&&j.error==='auth required')avgLine.textContent='Rate karne ke liye pehle login karo';
      }).catch(function(){});
    });
    row.appendChild(s);
  })(i)}}paint(0);
  function refresh(){
    F('/v1/x/ratings?token='+encodeURIComponent(tok())).then(function(r){return r.json()}).then(function(j){
      if(!j||!j.ok)return;
      if(j.mine){cur=j.mine;paint(j.mine,true)}
      avgLine.textContent=vals(j);
    }).catch(function(){});
  }
  function vals(j){return '\u2605 '+j.avg+' \u2014 '+j.count+' vote'+(j.count>1?'s':'')+'\u2014 aapka: '+(j.mine||'-')}
  refresh();
}

/* ---------- MOUNT ---------- */
function mountAll(){[namazMount,slideMount,searchMount,qrMount,badgeMount,ratingMount].forEach(function(fn){try{fn()}catch(e){console.log('[sq-v4]',fn.name,String(e))}})}
mountAll();
new MutationObserver(function(){mountAll()}).observe(document.body,{childList:true,subtree:true});
})();
