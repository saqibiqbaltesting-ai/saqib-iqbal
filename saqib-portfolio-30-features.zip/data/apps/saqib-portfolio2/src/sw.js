// Saqib Portfolio — offline service worker (master copy: src/sw.js, copied to dist/ after every refresh)
var CACHE = "sq-portfolio-v2";
self.addEventListener("install", function (e) {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(function (c) { return c.add("./index.html"); }));
});
// NOTE: yahan caches.delete kabhi na karna — is environment me activate par
// worker redundant ho jata hai. Purana cache naam badalna ho to CACHE var bump karo.
self.addEventListener("activate", function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener("fetch", function (e) {
  var req = e.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.pathname.indexOf("/dist/") === -1 && url.pathname.indexOf("/asset/") === -1) return;
  if (req.mode === "navigate") {
    e.respondWith(
      fetch(req).then(function (r) {
        var copy = r.clone(); caches.open(CACHE).then(function (c) { c.put("./index.html", copy); });
        return r;
      }).catch(function () {
        return caches.match("./index.html").then(function (r) { return r || Response.error(); });
      })
    );
    return;
  }
  var bare = url.pathname.split("/").pop();
  e.respondWith(
    caches.match(req).then(function (hit) {
      if (hit) {
        // stale-while-revalidate: cached foran, naya version background me
        fetch(req).then(function (r) {
          if (r.ok) { var copy = r.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); }
        }).catch(function () {});
        return hit;
      }
      return fetch(req).then(function (r) {
        if (r.ok) { var copy = r.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); }
        return r;
      }).catch(function () {
        // offline fallback: query ke baghair cached dhoondo
        return caches.open(CACHE).then(function (c) {
          return c.keys().then(function (keys) {
            var k = keys.find(function (k) { return k.url.split("/").pop() === bare; });
            return k ? c.match(k) : Response.error();
          });
        });
      });
    })
  );
});
